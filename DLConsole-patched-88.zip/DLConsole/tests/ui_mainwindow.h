/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.13
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout_2;
    QStackedWidget *stackedWidget;
    QWidget *page;
    QVBoxLayout *verticalLayout;
    QTabWidget *tabWidget;
    QWidget *page_2;
    QVBoxLayout *verticalLayout_2;
    QLabel *commandlabel;
    QHBoxLayout *horizontalLayout_2;
    QTextEdit *textEdit;
    QPushButton *pbConvert;
    QTextEdit *teToString;
    QFrame *rightFrame;
    QGridLayout *gridLayout;
    QPushButton *pbClearTabLogs;
    QPushButton *pbSaveBtn;
    QFrame *logCountFrame;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLabel *logCountLb;
    QPushButton *pbclearAllLogs;
    QSpacerItem *verticalSpacer;
    QCheckBox *cbDatetime;
    QPushButton *pbCheckBuffer;
    QCheckBox *cbScrollLock;
    QPushButton *pbDetach;
    QLabel *userMsglb;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(965, 682);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout_2 = new QGridLayout(centralwidget);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        stackedWidget = new QStackedWidget(centralwidget);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        page = new QWidget();
        page->setObjectName(QString::fromUtf8("page"));
        verticalLayout = new QVBoxLayout(page);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        tabWidget = new QTabWidget(page);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));

        verticalLayout->addWidget(tabWidget);

        stackedWidget->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QString::fromUtf8("page_2"));
        verticalLayout_2 = new QVBoxLayout(page_2);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        commandlabel = new QLabel(page_2);
        commandlabel->setObjectName(QString::fromUtf8("commandlabel"));

        verticalLayout_2->addWidget(commandlabel);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        textEdit = new QTextEdit(page_2);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));

        horizontalLayout_2->addWidget(textEdit);


        verticalLayout_2->addLayout(horizontalLayout_2);

        pbConvert = new QPushButton(page_2);
        pbConvert->setObjectName(QString::fromUtf8("pbConvert"));

        verticalLayout_2->addWidget(pbConvert);

        teToString = new QTextEdit(page_2);
        teToString->setObjectName(QString::fromUtf8("teToString"));

        verticalLayout_2->addWidget(teToString);

        stackedWidget->addWidget(page_2);

        gridLayout_2->addWidget(stackedWidget, 0, 1, 1, 1);

        rightFrame = new QFrame(centralwidget);
        rightFrame->setObjectName(QString::fromUtf8("rightFrame"));
        rightFrame->setStyleSheet(QString::fromUtf8(""));
        gridLayout = new QGridLayout(rightFrame);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setVerticalSpacing(15);
        gridLayout->setContentsMargins(-1, 25, 3, 3);
        pbClearTabLogs = new QPushButton(rightFrame);
        pbClearTabLogs->setObjectName(QString::fromUtf8("pbClearTabLogs"));

        gridLayout->addWidget(pbClearTabLogs, 3, 0, 1, 1);

        pbSaveBtn = new QPushButton(rightFrame);
        pbSaveBtn->setObjectName(QString::fromUtf8("pbSaveBtn"));

        gridLayout->addWidget(pbSaveBtn, 2, 0, 1, 1);

        logCountFrame = new QFrame(rightFrame);
        logCountFrame->setObjectName(QString::fromUtf8("logCountFrame"));
        horizontalLayout = new QHBoxLayout(logCountFrame);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label_2 = new QLabel(logCountFrame);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        logCountLb = new QLabel(logCountFrame);
        logCountLb->setObjectName(QString::fromUtf8("logCountLb"));

        horizontalLayout->addWidget(logCountLb);


        gridLayout->addWidget(logCountFrame, 9, 0, 1, 1);

        pbclearAllLogs = new QPushButton(rightFrame);
        pbclearAllLogs->setObjectName(QString::fromUtf8("pbclearAllLogs"));

        gridLayout->addWidget(pbclearAllLogs, 4, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 8, 0, 1, 1);

        cbDatetime = new QCheckBox(rightFrame);
        cbDatetime->setObjectName(QString::fromUtf8("cbDatetime"));

        gridLayout->addWidget(cbDatetime, 0, 0, 1, 1);

        pbCheckBuffer = new QPushButton(rightFrame);
        pbCheckBuffer->setObjectName(QString::fromUtf8("pbCheckBuffer"));
        pbCheckBuffer->setEnabled(true);

        gridLayout->addWidget(pbCheckBuffer, 6, 0, 1, 1);

        cbScrollLock = new QCheckBox(rightFrame);
        cbScrollLock->setObjectName(QString::fromUtf8("cbScrollLock"));

        gridLayout->addWidget(cbScrollLock, 1, 0, 1, 1);

        pbDetach = new QPushButton(rightFrame);
        pbDetach->setObjectName(QString::fromUtf8("pbDetach"));

        gridLayout->addWidget(pbDetach, 5, 0, 1, 1);


        gridLayout_2->addWidget(rightFrame, 0, 2, 1, 1);

        userMsglb = new QLabel(centralwidget);
        userMsglb->setObjectName(QString::fromUtf8("userMsglb"));
        userMsglb->setStyleSheet(QString::fromUtf8("background:yellow"));

        gridLayout_2->addWidget(userMsglb, 1, 1, 1, 1);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 965, 25));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(-1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        commandlabel->setText(QCoreApplication::translate("MainWindow", "Command : tshark -i any -f \"udp port 50002\" -T fields -e data", nullptr));
        pbConvert->setText(QCoreApplication::translate("MainWindow", "Convert", nullptr));
        pbClearTabLogs->setText(QCoreApplication::translate("MainWindow", "Clear this tab", nullptr));
        pbSaveBtn->setText(QCoreApplication::translate("MainWindow", "Save log", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Messages", nullptr));
        logCountLb->setText(QCoreApplication::translate("MainWindow", "0", nullptr));
        pbclearAllLogs->setText(QCoreApplication::translate("MainWindow", "Clear all tabs", nullptr));
        cbDatetime->setText(QCoreApplication::translate("MainWindow", "Show date", nullptr));
        pbCheckBuffer->setText(QCoreApplication::translate("MainWindow", "Check buffer", nullptr));
        cbScrollLock->setText(QCoreApplication::translate("MainWindow", "Follow newest", nullptr));
        pbDetach->setText(QCoreApplication::translate("MainWindow", "Detach tab", nullptr));
        userMsglb->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
