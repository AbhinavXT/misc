#include "fieldplot.h"
#include "uicolors.h"
#include "windowgeometry.h"

#include "capturedecoder.h"
#include "logmodel.h"
#include "schema/schemadecoder.h"

#include <QCloseEvent>
#include <QApplication>
#include <QComboBox>
#include <QDateTime>
#include <QHBoxLayout>
#include <QLabel>
#include <QMouseEvent>
#include <QPainter>
#include <QPushButton>
#include <QSet>
#include <QToolTip>
#include <QVBoxLayout>

#include <cmath>

// ============================== extraction =================================

double parseFieldNumber(const QString &display, bool *ok)
{
    if (ok) *ok = false;
    const QString s = display.trimmed();
    if (s.isEmpty()) return 0.0;

    // Whole string is a number: the common case, and the only one where a
    // trailing-garbage check is worth skipping.
    bool conv = false;
    const double whole = s.toDouble(&conv);
    if (conv) { if (ok) *ok = true; return whole; }

    // Hex, as the schema renders raw and address-like fields.
    if (s.startsWith(QLatin1String("0x"), Qt::CaseInsensitive)) {
        const qint64 v = s.mid(2).toLongLong(&conv, 16);
        if (conv) { if (ok) *ok = true; return double(v); }
    }

    // Leading number with a unit or annotation after it ("42 km/h",
    // "-3.5 m", "7 (RESERVED)"). Scanned by hand rather than with a regex
    // because this runs once per row per replot.
    int i = 0;
    const int n = s.size();
    if (i < n && (s.at(i) == QLatin1Char('-') || s.at(i) == QLatin1Char('+'))) ++i;
    int digits = 0;
    while (i < n && s.at(i).isDigit()) { ++i; ++digits; }
    if (i < n && s.at(i) == QLatin1Char('.')) {
        ++i;
        while (i < n && s.at(i).isDigit()) { ++i; ++digits; }
    }
    if (digits == 0) return 0.0;

    // Require a real separator after the digits. A letter glued straight on
    // means an identifier or a token ("12ABC", and the "0x"/"0xZZ" cases
    // that fall through from the hex branch above), not a measurement — and
    // treating those as numbers would put fabricated points on the plot,
    // which is worse than reporting them as non-numeric. Units therefore
    // have to be separated by a space, as the schema renders them.
    if (i < n && !s.at(i).isSpace()
        && s.at(i) != QLatin1Char('(') && s.at(i) != QLatin1Char('%')) {
        return 0.0;
    }
    const double lead = s.left(i).toDouble(&conv);
    if (!conv) return 0.0;
    if (ok) *ok = true;
    return lead;
}

namespace {

// Decode one entry the same way the field inspector does.
//
// Going through parseLine()/describe() rather than handing payload bytes to
// the schema is not a stylistic choice: the schema selects a packet by
// `captype`, which comes from the @<type>_<loco>_<ctrl> token in the
// message TEXT. kavach.xml defines no `pkt_type==` packets, so decoding
// bytes with an empty captype matches nothing, ever. Anything that decodes
// has to start from the text.
inline QVector<FieldRow> decodeEntry(const LogEntryPtr &e)
{
    if (!e) return {};
    const CaptureLine cap = CaptureDecoder::parseLine(e->text);
    if (!cap.valid || cap.bytes.isEmpty()) return {};
    return CaptureDecoder::describe(cap);
}

}  // namespace

QStringList discoverFieldNames(const LogModel *model,
                               const Schema::Decoder &decoder,
                               int sampleRows)
{
    QStringList out;
    if (!model || !decoder.isLoaded() || sampleRows <= 0) return out;

    Q_UNUSED(decoder);
    QSet<QString> seen;
    const int n = model->count();
    int looked = 0;

    // Sample from across the model, not just the head: a tab often starts
    // with one message type and only later carries the one you care about.
    const int stride = qMax(1, n / qMax(1, sampleRows));
    for (int i = 0; i < n && looked < sampleRows; i += stride) {
        LogEntryPtr e = model->entryAt(i);
        const QVector<FieldRow> rows = decodeEntry(e);
        if (rows.isEmpty()) continue;
        ++looked;
        for (const FieldRow &r : rows) {
            const QString name = r.field.trimmed();
            if (name.isEmpty()) continue;
            if (!seen.contains(name)) { seen.insert(name); out << name; }
        }
    }
    out.sort(Qt::CaseInsensitive);
    return out;
}

FieldSeries extractFieldSeries(const LogModel *model,
                               const QString &fieldName,
                               const Schema::Decoder &decoder,
                               int maxRows)
{
    FieldSeries out;
    if (!model || fieldName.isEmpty() || !decoder.isLoaded() || maxRows <= 0) {
        return out;
    }

    Q_UNUSED(decoder);
    const int n = model->count();
    if (n <= 0) return out;

    // Even sampling rather than truncation. Plotting the first maxRows of a
    // long session and labelling it with the session's name would misstate
    // the shape entirely — the interesting part is usually at the end.
    const int stride = (n > maxRows) ? (n / maxRows) : 1;
    out.hitRowCap = (stride > 1);

    const QString wanted = fieldName.trimmed();
    bool first = true;

    for (int i = 0; i < n; i += stride) {
        LogEntryPtr e = model->entryAt(i);
        if (!e) continue;
        ++out.rowsScanned;

        const QVector<FieldRow> rows = decodeEntry(e);
        if (rows.isEmpty()) continue;
        ++out.rowsDecoded;

        for (const FieldRow &r : rows) {
            if (r.field.trimmed() != wanted) continue;
            ++out.rowsMatched;

            bool ok = false;
            const double v = parseFieldNumber(r.value, &ok);
            if (!ok) { ++out.rowsNonNumeric; break; }

            FieldSeries::Point p;
            p.epochMs = e->epochMs;
            p.value   = v;
            p.row     = i;
            out.points.append(p);

            if (first) {
                out.minValue = out.maxValue = v;
                out.minMs    = out.maxMs    = e->epochMs;
                first = false;
            } else {
                out.minValue = qMin(out.minValue, v);
                out.maxValue = qMax(out.maxValue, v);
                out.minMs    = qMin(out.minMs, e->epochMs);
                out.maxMs    = qMax(out.maxMs, e->epochMs);
            }
            break;      // first occurrence per frame
        }
    }
    return out;
}

// ============================== canvas =====================================

namespace {
// globalPos() is deprecated in Qt 6, globalPosition() absent in Qt 5.
inline QPoint eventGlobalPos(const QMouseEvent *ev)
{
#if QT_VERSION >= QT_VERSION_CHECK(6, 0, 0)
    return ev->globalPosition().toPoint();
#else
    return ev->globalPos();
#endif
}
}  // namespace

QVector<double> niceTicks(double lo, double hi, int target, bool integerOnly)
{
    QVector<double> out;
    if (target < 2) { target = 2; }
    if (!(hi >= lo)) { return out; }

    if (hi - lo <= 0.0) {
        // A flat series still deserves its one value labelled — an axis
        // with no numbers on it says nothing about what is being drawn.
        out << lo;
        return out;
    }

    const double raw  = (hi - lo) / double(target - 1);
    const double mag  = std::pow(10.0, std::floor(std::log10(raw)));
    const double norm = raw / mag;
    double step = (norm <= 1.0 ? 1.0 : norm <= 2.0 ? 2.0 : norm <= 5.0 ? 5.0 : 10.0) * mag;

    // An integer field must not be labelled in fractions of a value it
    // cannot take — and where the whole range fits in a handful of steps of
    // 1, that is the labelling the operator wants: LOCO_MODE running 1..6
    // should read 1,2,3,4,5,6, not 2,4,6 with the value 1 unlabelled.
    if (integerOnly) {
        step = 0.0;
        for (double cand : { 1.0, 2.0, 5.0, 10.0, 20.0, 50.0, 100.0, 200.0, 500.0 }) {
            if (std::floor((hi - lo) / cand) + 1 <= double(target) + 1.0) { step = cand; break; }
        }
        if (step <= 0.0) { step = qMax(1.0, std::floor((hi - lo) / double(target - 1) + 0.5)); }
    }

    const double first = std::ceil(lo / step - 1e-9) * step;
    for (double v = first; v <= hi + step * 1e-9; v += step) {
        // Snap away the accumulated error, or a 0.1 step produces
        // 0.30000000000000004 in the label.
        out << (integerOnly ? std::floor(v + 0.5) : std::round(v / step) * step);
        if (out.size() > 64) { break; }          // runaway guard
    }
    return out;
}

int tickDecimals(double step)
{
    if (step <= 0.0) { return 0; }
    if (std::fabs(step - std::floor(step)) < 1e-9) { return 0; }
    const int d = int(std::ceil(-std::log10(step))) + 1;
    return qBound(1, d, 6);
}

FieldPlotCanvas::FieldPlotCanvas(QWidget *parent)
    : QWidget(parent)
{
    setMouseTracking(true);
    setMinimumHeight(200);
}

void FieldPlotCanvas::setSeries(const FieldSeries &s)
{
    m_series = s;
    m_hover  = -1;

    // Decided once here rather than per repaint: it changes only with the
    // series, and the paint path already walks every point twice.
    m_allWhole = true;
    for (const auto &pt : m_series.points) {
        if (std::fabs(pt.value - std::floor(pt.value)) > 1e-9) { m_allWhole = false; break; }
    }
    update();
}

QRect FieldPlotCanvas::plotRect() const
{
    // Margins leave room for value labels on the left and time on the
    // bottom. Fixed rather than measured: the labels are short and a
    // measured layout would reflow as values change, which is distracting
    // while scrubbing.
    return rect().adjusted(62, 10, -12, -22);
}

void FieldPlotCanvas::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.fillRect(rect(), palette().base());

    // Everything structural is drawn from the muted colour at varying
    // alpha rather than from palette Mid. Mid is a FRAME role — #DCDEE0 on
    // the light theme — so axis numbers drawn in it were about 1.2:1
    // against the plot background and simply could not be read.
    const QColor ink   = UiColor::muted();
    const QColor frame = UiColor::frame();
    const QColor grid  = UiColor::grid();

    const QRect r = plotRect();
    p.setPen(frame);
    p.drawRect(r);

    if (m_series.isEmpty()) {
        p.setPen(ink);
        p.drawText(rect(), Qt::AlignCenter,
                   tr("No numeric samples for this field"));
        return;
    }

    const double vSpan = m_series.maxValue - m_series.minValue;
    const qint64 tSpan = m_series.maxMs - m_series.minMs;

    auto xOf = [&](qint64 ms) {
        if (tSpan <= 0) return r.left() + r.width() / 2;
        return r.left() + int(double(ms - m_series.minMs) / double(tSpan) * r.width());
    };
    auto yOf = [&](double v) {
        // A flat series draws down the middle rather than collapsing onto
        // the top edge, which is what a zero span would otherwise do.
        if (vSpan <= 0) return r.top() + r.height() / 2;
        return r.bottom() - int((v - m_series.minValue) / vSpan * r.height());
    };

    QFont small = p.font();
    small.setPointSizeF(qMax(6.0, small.pointSizeF() - 2.0));
    p.setFont(small);

    // Value axis: ticks on real values of the field, not quarters of the
    // range. See niceTicks().
    const QVector<double> ticks = niceTicks(m_series.minValue, m_series.maxValue,
                                            5, m_allWhole);
    const double step = ticks.size() > 1 ? (ticks.at(1) - ticks.at(0)) : 1.0;
    const int    dec  = m_allWhole ? 0 : tickDecimals(step);
    for (double v : ticks) {
        const int y = yOf(v);
        p.setPen(grid);
        p.drawLine(r.left() + 1, y, r.right() - 1, y);
        p.setPen(ink);
        const QString label = QString::number(v, 'f', dec);
        p.drawText(QRect(2, y - 8, r.left() - 8, 16),
                   Qt::AlignRight | Qt::AlignVCenter, label);
    }

    // Time axis: four divisions, with a gridline each so a step in the
    // trace can be read off against a time without counting pixels.
    const int kXDiv = 4;
    for (int g = 0; g <= kXDiv; ++g) {
        const int x = r.left() + g * r.width() / kXDiv;
        if (g > 0 && g < kXDiv) {
            p.setPen(grid);
            p.drawLine(x, r.top() + 1, x, r.bottom() - 1);
        }
        const qint64 ms = m_series.minMs + (tSpan * g) / kXDiv;
        const QString label = QDateTime::fromMSecsSinceEpoch(ms).toString("HH:mm:ss");
        const int w = p.fontMetrics().horizontalAdvance(label);
        int lx = x - w / 2;
        // The end labels are pulled inside the plot rather than centred on
        // it, so neither runs off the edge of the widget.
        if (g == 0)      { lx = r.left(); }
        if (g == kXDiv)  { lx = r.right() - w; }
        p.setPen(ink);
        p.drawText(lx, height() - 6, label);
    }

    // The trace. Points are joined only when consecutive in time; a series
    // is a sampled sequence, so a straight line across a long gap would
    // assert continuity we never observed.
    p.setPen(QPen(UiColor::accent(), 1.5));
    const qint64 gapMs = tSpan > 0 ? qMax<qint64>(1000, tSpan / 40) : 0;
    for (int i = 1; i < m_series.points.size(); ++i) {
        const auto &a = m_series.points.at(i - 1);
        const auto &b = m_series.points.at(i);
        if (gapMs > 0 && (b.epochMs - a.epochMs) > gapMs) continue;
        p.drawLine(xOf(a.epochMs), yOf(a.value), xOf(b.epochMs), yOf(b.value));
    }

    p.setPen(UiColor::accent());
    p.setBrush(UiColor::accent());
    const bool sparse = m_series.points.size() < 400;
    for (const auto &pt : m_series.points) {
        if (sparse) p.drawEllipse(QPoint(xOf(pt.epochMs), yOf(pt.value)), 2, 2);
        else        p.drawPoint(xOf(pt.epochMs), yOf(pt.value));
    }

    if (m_hover >= 0 && m_hover < m_series.points.size()) {
        const auto &pt = m_series.points.at(m_hover);
        const QPoint c(xOf(pt.epochMs), yOf(pt.value));
        p.setBrush(Qt::NoBrush);
        p.setPen(QPen(UiColor::error(), 2));
        p.drawEllipse(c, 4, 4);

        // The readout. Circling the point said WHICH sample is under the
        // cursor but never what it was — the value and the time were the
        // two things the plot could not tell you.
        const QString txt = QStringLiteral("%1   %2")
            .arg(QDateTime::fromMSecsSinceEpoch(pt.epochMs).toString("HH:mm:ss"))
            .arg(QString::number(pt.value, 'f', m_allWhole ? 0 : 3));
        QRect box(0, 0, p.fontMetrics().horizontalAdvance(txt) + 12, 20);
        box.moveTo(c.x() + 10, c.y() - 26);
        // Kept inside the plot, so a point near the right edge does not put
        // its own label off the widget.
        if (box.right() > r.right())  { box.moveRight(c.x() - 10); }
        if (box.top()   < r.top())    { box.moveTop(c.y() + 10); }
        if (box.left()  < r.left())   { box.moveLeft(r.left() + 2); }

        QColor fill = palette().color(QPalette::Base);
        fill.setAlpha(230);
        p.setBrush(fill);
        p.setPen(frame);
        p.drawRect(box);
        p.setPen(palette().color(QPalette::Text));
        p.drawText(box, Qt::AlignCenter, txt);
    }
}

int FieldPlotCanvas::nearestPoint(int px, int py) const
{
    if (m_series.isEmpty()) return -1;
    const QRect r = plotRect();
    const double vSpan = m_series.maxValue - m_series.minValue;
    const qint64 tSpan = m_series.maxMs - m_series.minMs;

    int best = -1;
    double bestD = 1e18;
    for (int i = 0; i < m_series.points.size(); ++i) {
        const auto &pt = m_series.points.at(i);
        const int x = (tSpan <= 0)
                          ? r.left() + r.width() / 2
                          : r.left() + int(double(pt.epochMs - m_series.minMs)
                                           / double(tSpan) * r.width());
        const int y = (vSpan <= 0)
                          ? r.top() + r.height() / 2
                          : r.bottom() - int((pt.value - m_series.minValue)
                                             / vSpan * r.height());
        const double d = double(x - px) * (x - px) + double(y - py) * (y - py);
        if (d < bestD) { bestD = d; best = i; }
    }
    return (bestD <= 400.0) ? best : -1;      // within 20px
}

void FieldPlotCanvas::mouseMoveEvent(QMouseEvent *ev)
{
    const int idx = nearestPoint(ev->pos().x(), ev->pos().y());
    if (idx != m_hover) { m_hover = idx; update(); }
    if (idx < 0) { QToolTip::hideText(); return; }

    const auto &pt = m_series.points.at(idx);
    QToolTip::showText(
        eventGlobalPos(ev),
        tr("%1\nvalue %2\n(click to jump to this message)")
            .arg(QDateTime::fromMSecsSinceEpoch(pt.epochMs)
                     .toString("yyyy-MM-dd HH:mm:ss.zzz"))
            .arg(pt.value),
        this);
}

void FieldPlotCanvas::mousePressEvent(QMouseEvent *ev)
{
    const int idx = nearestPoint(ev->pos().x(), ev->pos().y());
    if (idx < 0) return;
    const auto &pt = m_series.points.at(idx);
    emit pointActivated(pt.row, pt.epochMs);
}

// ============================== window =====================================

FieldPlotWindow::FieldPlotWindow(LogModel *model, const QString &tabKey,
                                 QWidget *parent)
    : QWidget(parent, Qt::Window)
    , m_model(model)
    , m_tabKey(tabKey)
{
    setAttribute(Qt::WA_DeleteOnClose);
    setWindowTitle(tr("Field over time — %1").arg(tabKey));
    WindowGeometry::makeResizableWindow(this);
    resize(860, 400);
    // Default above; a remembered size/position wins over it.
    WindowGeometry::restore(this, QStringLiteral("fieldPlot"));

    m_fieldBox = new QComboBox;
    m_fieldBox->setMinimumWidth(240);
    m_fieldBox->setToolTip(tr("Fields found by decoding a sample of this "
                              "tab's messages."));

    m_rescan = new QPushButton(tr("Rescan fields"));
    m_rescan->setToolTip(tr("Re-sample the tab for field names. Useful after "
                            "a schema reload, or once more traffic has "
                            "arrived."));

    auto *top = new QHBoxLayout;
    top->addWidget(new QLabel(tr("Field:")));
    top->addWidget(m_fieldBox, 1);
    top->addWidget(m_rescan);

    m_canvas = new FieldPlotCanvas;
    m_status = new StatusLine;
    m_status->setWordWrap(true);

    auto *root = new QVBoxLayout(this);
    root->addLayout(top);
    root->addWidget(m_canvas, 1);
    root->addWidget(m_status);

    connect(m_fieldBox, &QComboBox::currentTextChanged,
            this, [this](const QString &) { replot(); });
    connect(m_rescan, &QPushButton::clicked, this, &FieldPlotWindow::refreshFields);
    connect(m_canvas, &FieldPlotCanvas::pointActivated,
            this, [this](int, qint64 ms) { emit jumpRequested(m_tabKey, ms); });

    refreshFields();
}

void FieldPlotWindow::plotField(const QString &fieldName)
{
    if (!m_fieldBox || fieldName.trimmed().isEmpty()) { return; }

    const QString want = fieldName.trimmed();
    const int i = m_fieldBox->findText(want, Qt::MatchFixedString);
    if (i >= 0) {
        m_fieldBox->setCurrentIndex(i);
    } else {
        // Not in the sample. Add it and select it rather than silently
        // plotting whatever the chooser happened to be on, which would show a
        // graph of the wrong field with no sign that anything went wrong.
        m_fieldBox->addItem(want);
        m_fieldBox->setCurrentIndex(m_fieldBox->count() - 1);
    }
    replot();
}

void FieldPlotWindow::refreshFields()
{
    QApplication::setOverrideCursor(Qt::WaitCursor);
    const QString previous = m_fieldBox->currentText();
    const QStringList names = discoverFieldNames(m_model, kavachSchema());
    QApplication::restoreOverrideCursor();

    m_fieldBox->blockSignals(true);
    m_fieldBox->clear();
    m_fieldBox->addItems(names);
    const int idx = m_fieldBox->findText(previous);
    if (idx >= 0) m_fieldBox->setCurrentIndex(idx);
    m_fieldBox->blockSignals(false);

    if (names.isEmpty()) {
        m_status->state(tr("No decodable fields found in this tab. Either "
                             "no schema packet matches its traffic, or no "
                             "message carries raw bytes."));
        m_canvas->setSeries(FieldSeries());
        return;
    }
    replot();
}

void FieldPlotWindow::replot()
{
    const QString field = m_fieldBox->currentText();
    if (field.isEmpty()) return;

    QApplication::setOverrideCursor(Qt::WaitCursor);
    const FieldSeries s = extractFieldSeries(m_model, field, kavachSchema());
    QApplication::restoreOverrideCursor();

    m_canvas->setSeries(s);

    // Every discard is reported. A plot with silent gaps is worse than no
    // plot, because it looks like an absence of data rather than a decision.
    QString msg = tr("%1 point(s) from %2 decoded row(s) of %3 scanned")
                      .arg(s.points.size()).arg(s.rowsDecoded).arg(s.rowsScanned);
    if (s.rowsNonNumeric > 0) {
        msg += tr("  ·  %1 row(s) had a non-numeric value and are NOT plotted")
                   .arg(s.rowsNonNumeric);
    }
    if (s.rowsMatched == 0 && s.rowsDecoded > 0) {
        msg += tr("  ·  no decoded row contained this field");
    }
    if (s.hitRowCap) {
        msg += tr("  ·  sampled evenly across the tab (too many rows to "
                  "decode them all)");
    }
    // A discarded row is the one thing here worth a warning: the plot then
    // shows fewer points than the tab holds, which reads as missing data
    // rather than as a decision. Everything else is a caption for the canvas
    // and stays until the next plot replaces it.
    if (s.rowsNonNumeric > 0) { m_status->warn(msg); }
    else                      { m_status->state(msg); }
}

void FieldPlotWindow::closeEvent(QCloseEvent *event)
{
    // WA_DeleteOnClose: this is the last point at which the geometry still
    // exists to be read.
    WindowGeometry::save(this, QStringLiteral("fieldPlot"));
    QWidget::closeEvent(event);
}
