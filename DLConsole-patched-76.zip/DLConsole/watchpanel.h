#ifndef WATCHPANEL_H
#define WATCHPANEL_H
// =============================================================================
//  WatchPanel — the floating window that holds watches and shows what fired.
//
//  Floating for the same reason the pin board is: a watch is set up before a
//  run and read DURING one, while the operator is at the DMI and the console
//  is behind something else. A panel folded into the side of the log window is
//  a panel nobody is looking at when it fires.
// =============================================================================

#include <QWidget>

#include "watchlist.h"

class NameMap;
class QLineEdit;
class QPushButton;
class QTableWidget;
class QTimer;
class QueryLineEdit;
class StatusLine;

class WatchPanel : public QWidget
{
    Q_OBJECT

public:
    explicit WatchPanel(QWidget *parent = nullptr);

    WatchList &list() { return m_list; }

    // Offered EVERY entry, not one per batch. See WatchList for why a watch
    // may not sample.
    void observe(const LogEntryPtr &entry, const QString &sourceKey);

    void setNames(const NameMap *names) { m_names = names; }

    void restore();
    void persist() const;

signals:
    // A watch fired. The owner announces it — this panel may be behind
    // another window, which is exactly when a watch matters most.
    void watchFired(const QString &label, const QString &expr,
                    const QString &sourceKey);

    // Take the view to the frame that fired a watch.
    void revealRequested(const LogEntryPtr &entry, const QString &sourceKey);

private slots:
    void addWatch();
    void removeSelected();
    void rearmSelected();
    void refresh();

private:
    WatchList      m_list;
    const NameMap *m_names = nullptr;

    QueryLineEdit *m_expr    = nullptr;
    QLineEdit     *m_label   = nullptr;
    QPushButton   *m_addBtn  = nullptr;
    QPushButton   *m_delBtn  = nullptr;
    QPushButton   *m_armBtn  = nullptr;
    QTableWidget  *m_table   = nullptr;
    StatusLine    *m_status  = nullptr;
    QTimer        *m_tick    = nullptr;
};

#endif  // WATCHPANEL_H
