#ifndef LOCOCONFIGWINDOW_H
#define LOCOCONFIGWINDOW_H
// =============================================================================
//  LocoConfigWindow
//  -----------------------------------------------------------------------------
//  Tools ▸ Loco Configuration…  --  edit a loco's LOCO_INFO, send it to the
//  VCC, and write loco_info.bin. The GUI form of loco_config_v12.cpp.
//
//  SHAPE
//    A standalone QMainWindow, single instance, like the Firmware Flasher.
//    One saved CONFIGURATION per loco (unit ID, wheels, tachos, ...), kept
//    in loco_configs.json beside dlconsole.ini; the app bar switches
//    between them. The body is the field table (lococonfigmodel.h) with a
//    group list and a search box; the bottom bar sends.
//
//  SENDING
//    One datagram, exactly v12's: STRUCT_MESSAGE_HEADER (src 28 -> dest 2,
//    message 120, length 375) + the 370-byte body with loco_info_crc
//    computed. Sent through UdpSender, DLConsole's one transmit path, to
//    the VCC's application (normal operation, port 50001 by default).
//
//    The VCC sends NOTHING back. So the window is honest about it -- it
//    says so where the Send button is -- and makes what WAS sent easy to
//    check: before sending it lists every field that differs from the last
//    send of this configuration; after, the exact bytes go into
//    loco_config_history.jsonl, from which any past send can be re-exported
//    as loco_info.bin or loaded back.
//
//  WHERE THE LAYOUT COMES FROM
//    schema/kavach.xml <packet name="LINFO">, the same element that
//    decodes @linfo captures (see lococonfigcore.h).
// =============================================================================
#include <QMainWindow>
#include <QPointer>
#include <QTimer>

#include "lococonfigcore.h"

class LocoFieldFilter;
class LocoFieldModel;
class LocoConfigHistoryDialog;
class QComboBox;
class QFrame;
class QLabel;
class QLineEdit;
class QListWidget;
class QPushButton;
class QSpinBox;
class QTableView;
class StatusLine;
class UdpSender;

class LocoConfigWindow : public QMainWindow
{
    Q_OBJECT
public:
    // `dataDirectory`: where loco_configs.json and the send history live.
    // Empty = beside dlconsole.ini; the tests pass a temporary directory.
    explicit LocoConfigWindow(QWidget *parent = nullptr, const QString &dataDirectory = QString());
    ~LocoConfigWindow() override;

    bool isUsable() const { return m_layout.isLoaded(); }

    // The Send button without (confirm = false) or with its confirmation box.
    // Public for the tests.
    bool sendNow(bool confirm);

    // For the tests.
    LocoFieldModel *fieldModel() const { return m_model; }
    void setTarget(const QString &ip, quint16 port);
    QString configsPath() const;
    QString historyPath() const;
    QByteArray currentBody() const;
    QString sendBlocker() const;      // why Send is disabled, or empty

signals:
    void sent();

protected:
    void closeEvent(QCloseEvent *event) override;

private slots:
    void onValueEdited(const QString &key);
    void onGroupChanged();
    void onConfigChosen(int index);
    void refreshSummary();
    void saveNow();
    void newConfig();
    void duplicateConfig();
    void renameConfig();
    void deleteConfig();
    void importBin();
    void exportBin();
    void resetToDefaults();
    void openHistory();

private:
    QWidget *buildAppBar();
    QWidget *buildBody();
    QWidget *buildSendBar();
    void     restyle();
    void     loadConfig(const QString &name);
    void     reloadConfigCombo();
    void     refreshGroupCounts();
    void     applyValues(const LocoInfo::Values &values);
    void     scheduleSave();
    LocoInfo::Values lastSentValues() const;
    bool     writeBin(const QString &path, const QByteArray &body);

    // ---- data -------------------------------------------------------------------
    QString                 m_dataDirectory;
    QString                 m_loadError;
    LocoInfo::Layout        m_layout;
    LocoInfo::Presentation  m_presentation;
    LocoInfo::Values        m_defaults;
    QString                 m_defaultsSource;   // "loco_config_v12.cpp", from loco_defaults.json
    LocoInfo::ConfigStore  *m_store = nullptr;
    LocoInfo::SendHistory  *m_history = nullptr;
    LocoInfo::LocoConfig    m_config;
    QTimer                  m_saveTimer;

    // ---- widgets ----------------------------------------------------------------
    QFrame          *m_appBar = nullptr;
    QComboBox       *m_configCombo = nullptr;
    QLineEdit       *m_search = nullptr;
    QListWidget     *m_groups = nullptr;
    QTableView      *m_table = nullptr;
    LocoFieldModel  *m_model = nullptr;
    LocoFieldFilter *m_filter = nullptr;
    QLineEdit       *m_targetIp = nullptr;
    QSpinBox        *m_targetPort = nullptr;
    QLabel          *m_summary = nullptr;
    QLabel          *m_vccCrc = nullptr;
    QLabel          *m_lastSent = nullptr;
    QLabel          *m_blocker = nullptr;
    QPushButton     *m_sendButton = nullptr;
    StatusLine      *m_status = nullptr;
    UdpSender       *m_sender = nullptr;
    QList<QFrame *>  m_cards;
    QList<QLabel *>  m_sectionLabels;
    QPointer<LocoConfigHistoryDialog> m_historyDialog;
    bool             m_loadingConfig = false;
};

#endif  // LOCOCONFIGWINDOW_H
