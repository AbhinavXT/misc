#include "lococonfigwindow.h"

#include "flasherstyle.h"
#include "lococonfighistorydialog.h"
#include "lococonfigmodel.h"
#include "settings.h"
#include "statusline.h"
#include "udpsender.h"
#include "uicolors.h"
#include "uistyle.h"
#include "windowgeometry.h"

#include <QCloseEvent>
#include <QComboBox>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QFrame>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QHostAddress>
#include <QInputDialog>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QMenu>
#include <QMessageBox>
#include <QPushButton>
#include <QSpinBox>
#include <QSplitter>
#include <QTableView>
#include <QToolButton>
#include <QVBoxLayout>

namespace {

const char kConfigsFileName[] = "loco_configs.json";
const char kHistoryFileName[] = "loco_config_history.jsonl";
const char kSchemaPath[]      = ":/schema/kavach.xml";
const char kDefaultsPath[]    = ":/lococonfig/loco_defaults.json";

// The confirmation box lists at most this many changed fields in its main
// text; the full list is always in "Show Details".
const int kChangesShownInline = 12;

QString resolveDataDirectory(const QString &requested)
{
    if (!requested.isEmpty()) {
        return requested;
    }
    return QFileInfo(Settings::iniPath()).absolutePath();
}

}  // namespace

LocoConfigWindow::LocoConfigWindow(QWidget *parent, const QString &dataDirectory)
    : QMainWindow(parent)
    , m_dataDirectory(resolveDataDirectory(dataDirectory))
{
    setWindowTitle(tr("Loco Configuration"));
    WindowGeometry::makeResizableWindow(this);
    resize(1200, 800);
    WindowGeometry::restore(this, QStringLiteral("locoConfiguration"));

    // ---- the layout, its presentation, the tool's defaults -------------------------
    QString error;
    if (!m_layout.load(QLatin1String(kSchemaPath), &error)) {
        m_loadError = tr("The LOCO_INFO layout could not be read from the schema:\n%1").arg(error);
    } else if (!LocoInfo::loadDefaults(QLatin1String(kDefaultsPath), m_layout, &m_defaults, &error,
                                       &m_defaultsSource)) {
        m_loadError = error;
    } else {
        m_presentation = LocoInfo::Presentation::fromLayout(m_layout);
    }
    if (!m_loadError.isEmpty()) {
        // Nothing can be edited without a layout; say why instead of showing
        // an empty table.
        auto *message = new QLabel(m_loadError, this);
        message->setWordWrap(true);
        message->setAlignment(Qt::AlignCenter);
        message->setStyleSheet(UiColor::errorStyle());
        setCentralWidget(message);
        return;
    }
    LocoInfo::completeValues(m_layout, LocoInfo::Values(), &m_defaults);

    m_store = new LocoInfo::ConfigStore(QDir(m_dataDirectory).filePath(QLatin1String(kConfigsFileName)),
                                        &m_layout, m_defaults);
    m_history = new LocoInfo::SendHistory(QDir(m_dataDirectory).filePath(QLatin1String(kHistoryFileName)));
    m_sender = new UdpSender(this);

    // ---- widgets -----------------------------------------------------------------
    m_model = new LocoFieldModel(&m_layout, &m_presentation, this);
    m_filter = new LocoFieldFilter(this);
    m_filter->setSourceModel(m_model);

    auto *central = new QWidget(this);
    auto *centralLayout = new QVBoxLayout(central);
    centralLayout->setContentsMargins(0, 0, 0, 0);
    centralLayout->setSpacing(0);
    centralLayout->addWidget(buildAppBar());
    auto *page = new QWidget(central);
    auto *pageLayout = new QVBoxLayout(page);
    pageLayout->setContentsMargins(16, 16, 16, 12);
    pageLayout->setSpacing(12);
    pageLayout->addWidget(buildBody(), 1);
    pageLayout->addWidget(buildSendBar());
    m_status = new StatusLine(page);
    pageLayout->addWidget(m_status);
    centralLayout->addWidget(page, 1);
    setCentralWidget(central);

    // ---- saving: debounced, so typing a value does not write the file per key ----
    m_saveTimer.setSingleShot(true);
    m_saveTimer.setInterval(400);
    connect(&m_saveTimer, &QTimer::timeout, this, &LocoConfigWindow::saveNow);

    connect(m_model, &LocoFieldModel::valueEdited, this, &LocoConfigWindow::onValueEdited);
    connect(m_model, &LocoFieldModel::editRejected, this, [this](const QString &reason) {
        m_status->warn(reason);
    });
    connect(m_sender, &UdpSender::error, this, [this](const QString &what) {
        m_status->fail(tr("Send failed: %1").arg(what));
    });

    // ---- the stored configurations --------------------------------------------------
    if (!m_store->load()) {
        QMessageBox::warning(this, windowTitle(),
                             tr("The loco configurations could not be read, and a default is in use:\n\n%1\n\n"
                                "The file is left as it is until the next save.")
                                 .arg(m_store->lastError()));
    }
    if (!m_store->droppedKeys().isEmpty()) {
        m_status->warn(tr("Saved configurations had fields the schema no longer has (ignored): %1")
                           .arg(m_store->droppedKeys().join(QStringLiteral(", "))));
    }
    reloadConfigCombo();
    loadConfig(m_store->activeName());

    UiColor::onThemeChange(this, [this]() { restyle(); });
    restyle();
}

LocoConfigWindow::~LocoConfigWindow()
{
    if (m_store != nullptr && m_saveTimer.isActive()) {
        saveNow();
    }
    delete m_store;
    delete m_history;
}

QString LocoConfigWindow::configsPath() const
{
    if (m_store == nullptr) {
        return QString();
    }
    return m_store->filePath();
}

QString LocoConfigWindow::historyPath() const
{
    if (m_history == nullptr) {
        return QString();
    }
    return m_history->filePath();
}

// =============================================================================
//  Building
// =============================================================================

QWidget *LocoConfigWindow::buildAppBar()
{
    m_appBar = new QFrame(this);
    m_appBar->setObjectName(QStringLiteral("locoAppBar"));
    m_appBar->setFixedHeight(56);
    auto *barLayout = new QHBoxLayout(m_appBar);
    barLayout->setContentsMargins(18, 0, 14, 0);
    barLayout->setSpacing(12);

    auto *title = new QLabel(tr("Loco Configuration"), m_appBar);
    title->setFont(FlasherStyle::scaledFont(title->font(), 1.15, true));
    barLayout->addWidget(title);
    barLayout->addSpacing(12);

    barLayout->addWidget(new QLabel(tr("Configuration"), m_appBar));
    m_configCombo = new QComboBox(m_appBar);
    m_configCombo->setMinimumWidth(240);
    m_configCombo->setMinimumHeight(34);
    m_configCombo->setToolTip(tr("One saved configuration per loco"));
    connect(m_configCombo, QOverload<int>::of(&QComboBox::activated), this, &LocoConfigWindow::onConfigChosen);
    barLayout->addWidget(m_configCombo);

    auto *manage = new QToolButton(m_appBar);
    manage->setText(tr("Manage"));
    manage->setPopupMode(QToolButton::InstantPopup);
    auto *menu = new QMenu(manage);
    menu->addAction(tr("New from defaults…"), this, &LocoConfigWindow::newConfig);
    menu->addAction(tr("Duplicate…"), this, &LocoConfigWindow::duplicateConfig);
    menu->addAction(tr("Rename…"), this, &LocoConfigWindow::renameConfig);
    menu->addAction(tr("Delete…"), this, &LocoConfigWindow::deleteConfig);
    menu->addSeparator();
    menu->addAction(tr("Import loco_info.bin…"), this, &LocoConfigWindow::importBin);
    menu->addAction(tr("Reset all fields to defaults…"), this, &LocoConfigWindow::resetToDefaults);
    // Where "defaults" come from: the tool sync_linfo.py last read.
    if (!m_defaultsSource.isEmpty()) {
        menu->setToolTipsVisible(true);
        for (QAction *action : menu->actions()) {
            if (action->text().contains(tr("defaults"))) {
                action->setToolTip(tr("Defaults are the values in %1").arg(m_defaultsSource));
            }
        }
    }
    manage->setMenu(menu);
    barLayout->addWidget(manage);

    barLayout->addStretch(1);

    auto *historyButton = new QToolButton(m_appBar);
    historyButton->setText(tr("History"));
    historyButton->setToolTip(tr("Every configuration sent from this PC, byte for byte"));
    connect(historyButton, &QToolButton::clicked, this, &LocoConfigWindow::openHistory);
    barLayout->addWidget(historyButton);
    return m_appBar;
}

QWidget *LocoConfigWindow::buildBody()
{
    auto *splitter = new QSplitter(Qt::Horizontal, this);

    // ---- groups + search ---------------------------------------------------------
    auto *left = new QFrame(splitter);
    left->setObjectName(QStringLiteral("locoGroupsCard"));
    m_cards.append(left);
    auto *leftLayout = new QVBoxLayout(left);
    leftLayout->setContentsMargins(12, 12, 12, 12);
    leftLayout->setSpacing(8);
    m_search = new QLineEdit(left);
    m_search->setPlaceholderText(tr("Search fields…"));
    m_search->setClearButtonEnabled(true);
    m_search->setMinimumHeight(32);
    connect(m_search, &QLineEdit::textChanged, this, [this](const QString &text) {
        m_filter->setSearch(text);
    });
    leftLayout->addWidget(m_search);
    auto *groupsTitle = new QLabel(tr("Groups"), left);
    m_sectionLabels.append(groupsTitle);
    leftLayout->addWidget(groupsTitle);
    m_groups = new QListWidget(left);
    m_groups->setFrameShape(QFrame::NoFrame);
    auto addGroup = [this](const QString &key) {
        auto *item = new QListWidgetItem(key, m_groups);
        item->setData(Qt::UserRole, key);
    };
    addGroup(LocoFieldFilter::allFields());
    addGroup(LocoFieldFilter::changedFromDefault());
    addGroup(LocoFieldFilter::changedSinceSent());
    for (const LocoInfo::Presentation::Group &group : m_presentation.groups) {
        addGroup(group.title);
    }
    // "Other" only when the schema has a field the presentation does not group.
    bool hasOther = false;
    for (const LocoInfo::Field &field : m_layout.fields()) {
        if (!field.isCrc && m_presentation.groupOf(field.key) == QLatin1String("Other")) {
            hasOther = true;
        }
    }
    if (hasOther) {
        addGroup(QStringLiteral("Other"));
    }
    m_groups->setCurrentRow(0);
    connect(m_groups, &QListWidget::currentRowChanged, this, &LocoConfigWindow::onGroupChanged);
    leftLayout->addWidget(m_groups, 1);
    left->setMinimumWidth(240);
    m_groups->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    // ---- the field table ---------------------------------------------------------
    auto *right = new QFrame(splitter);
    right->setObjectName(QStringLiteral("locoTableCard"));
    m_cards.append(right);
    auto *rightLayout = new QVBoxLayout(right);
    rightLayout->setContentsMargins(0, 0, 0, 0);
    m_table = new QTableView(right);
    m_table->setModel(m_filter);
    m_table->setFrameShape(QFrame::NoFrame);
    m_table->setAlternatingRowColors(true);
    m_table->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_table->setSelectionMode(QAbstractItemView::SingleSelection);
    m_table->setEditTriggers(QAbstractItemView::DoubleClicked | QAbstractItemView::EditKeyPressed
                             | QAbstractItemView::AnyKeyPressed);
    m_table->verticalHeader()->hide();
    m_table->setWordWrap(false);
    QHeaderView *header = m_table->horizontalHeader();
    header->setSectionResizeMode(LocoFieldModel::ColumnField, QHeaderView::Stretch);
    header->setDefaultAlignment(Qt::AlignLeft | Qt::AlignVCenter);
    m_table->setColumnWidth(LocoFieldModel::ColumnValue, 170);
    m_table->setColumnWidth(LocoFieldModel::ColumnDefault, 140);
    m_table->setColumnWidth(LocoFieldModel::ColumnLastSent, 140);
    m_table->setColumnWidth(LocoFieldModel::ColumnType, 110);
    m_table->setFont(UiStyle::monoFont());
    m_table->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(m_table, &QTableView::customContextMenuRequested, this, [this](const QPoint &position) {
        const QModelIndex index = m_table->indexAt(position);
        if (!index.isValid()) {
            return;
        }
        const QString key = index.data(LocoFieldModel::KeyRole).toString();
        QMenu menu(this);
        QAction *revertDefault = menu.addAction(tr("Revert to default"));
        QAction *revertSent = menu.addAction(tr("Revert to last sent"));
        revertSent->setEnabled(m_model->hasLastSent());
        QAction *chosen = menu.exec(m_table->viewport()->mapToGlobal(position));
        if (chosen == revertDefault) {
            m_model->setValue(key, m_defaults.value(key));
            onValueEdited(key);
        } else if (chosen == revertSent && chosen != nullptr) {
            m_model->setValue(key, lastSentValues().value(key));
            onValueEdited(key);
        }
    });
    rightLayout->addWidget(m_table);

    splitter->setStretchFactor(0, 0);
    splitter->setStretchFactor(1, 1);
    splitter->setSizes({ 260, 940 });
    return splitter;
}

QWidget *LocoConfigWindow::buildSendBar()
{
    auto *bar = new QFrame(this);
    bar->setObjectName(QStringLiteral("locoSendBar"));
    m_cards.append(bar);
    auto *barLayout = new QVBoxLayout(bar);
    barLayout->setContentsMargins(18, 14, 18, 14);
    barLayout->setSpacing(8);

    auto *topRow = new QHBoxLayout();
    topRow->setSpacing(12);
    auto *sendTitle = new QLabel(tr("Send to VCC"), bar);
    m_sectionLabels.append(sendTitle);
    topRow->addWidget(sendTitle);
    topRow->addWidget(new QLabel(tr("IP"), bar));
    m_targetIp = new QLineEdit(bar);
    m_targetIp->setFont(UiStyle::monoFont());
    m_targetIp->setMinimumHeight(32);
    m_targetIp->setFixedWidth(160);
    topRow->addWidget(m_targetIp);
    topRow->addWidget(new QLabel(tr("Port"), bar));
    m_targetPort = new QSpinBox(bar);
    m_targetPort->setRange(1, 65535);
    m_targetPort->setFont(UiStyle::monoFont());
    m_targetPort->setButtonSymbols(QAbstractSpinBox::NoButtons);
    m_targetPort->setMinimumHeight(32);
    m_targetPort->setFixedWidth(80);
    topRow->addWidget(m_targetPort);
    m_summary = new QLabel(bar);
    m_summary->setFont(UiStyle::monoFont());
    m_summary->setTextInteractionFlags(Qt::TextSelectableByMouse);
    topRow->addWidget(m_summary, 1);
    barLayout->addLayout(topRow);

    auto editedTarget = [this]() {
        if (m_loadingConfig) {
            return;
        }
        m_config.targetIp = m_targetIp->text().trimmed();
        m_config.port = static_cast<quint16>(m_targetPort->value());
        scheduleSave();
        refreshSummary();
    };
    connect(m_targetIp, &QLineEdit::textChanged, this, editedTarget);
    connect(m_targetPort, QOverload<int>::of(&QSpinBox::valueChanged), this, editedTarget);

    m_vccCrc = new QLabel(bar);
    m_vccCrc->setWordWrap(true);
    barLayout->addWidget(m_vccCrc);

    auto *bottomRow = new QHBoxLayout();
    bottomRow->setSpacing(12);
    auto *noReply = new QLabel(tr("The VCC does not reply to this message. DLConsole records exactly what "
                                  "it sent; it cannot tell whether the loco applied it."), bar);
    noReply->setWordWrap(true);
    noReply->setStyleSheet(UiColor::mutedStyle());
    auto *textColumn = new QVBoxLayout();
    textColumn->addWidget(noReply);
    m_lastSent = new QLabel(bar);
    m_lastSent->setStyleSheet(UiColor::mutedStyle());
    textColumn->addWidget(m_lastSent);
    m_blocker = new QLabel(bar);
    m_blocker->setWordWrap(true);
    textColumn->addWidget(m_blocker);
    bottomRow->addLayout(textColumn, 1);

    auto *exportButton = new QPushButton(tr("Export loco_info.bin…"), bar);
    exportButton->setMinimumHeight(38);
    exportButton->setToolTip(tr("The %1-byte body, as the loco_config tool writes it, for flashing at 0x%2")
                                 .arg(m_layout.bodySize())
                                 .arg(LocoInfo::kFlashAddress, 8, 16, QLatin1Char('0')));
    connect(exportButton, &QPushButton::clicked, this, &LocoConfigWindow::exportBin);
    bottomRow->addWidget(exportButton, 0, Qt::AlignBottom);

    m_sendButton = new QPushButton(tr("Send to VCC…"), bar);
    m_sendButton->setObjectName(QStringLiteral("locoSendButton"));
    m_sendButton->setMinimumHeight(38);
    m_sendButton->setMinimumWidth(150);
    connect(m_sendButton, &QPushButton::clicked, this, [this]() { sendNow(true); });
    bottomRow->addWidget(m_sendButton, 0, Qt::AlignBottom);
    barLayout->addLayout(bottomRow);
    return bar;
}

void LocoConfigWindow::restyle()
{
    const QPalette pal = palette();
    m_appBar->setStyleSheet(
        QStringLiteral("QFrame#locoAppBar { background-color:%1; border-bottom:1px solid %2; }")
            .arg(pal.color(QPalette::AlternateBase).name(), FlasherStyle::border().name(QColor::HexArgb)));
    for (QFrame *card : m_cards) {
        card->setStyleSheet(FlasherStyle::cardSheet(card->objectName()));
    }
    for (QLabel *label : m_sectionLabels) {
        FlasherStyle::makeSectionLabel(label);
    }
    m_sendButton->setStyleSheet(
        QStringLiteral("QPushButton#locoSendButton { background-color:%1; color:%2; border:none;"
                       " border-radius:8px; padding:0 18px; font-weight:600; }"
                       "QPushButton#locoSendButton:disabled { background-color:%3; color:%4; }")
            .arg(FlasherStyle::primary().name(), pal.color(QPalette::Base).name(),
                 pal.color(QPalette::AlternateBase).name(),
                 pal.color(QPalette::Disabled, QPalette::Text).name()));
    refreshSummary();
}

// =============================================================================
//  Configurations
// =============================================================================

void LocoConfigWindow::reloadConfigCombo()
{
    const QSignalBlocker blocker(m_configCombo);
    m_configCombo->clear();
    for (const QString &name : m_store->names()) {
        m_configCombo->addItem(name, name);
    }
    m_configCombo->setCurrentIndex(m_configCombo->findData(m_store->activeName()));
}

LocoInfo::Values LocoConfigWindow::lastSentValues() const
{
    if (m_config.lastSentBody.isEmpty()) {
        return LocoInfo::Values();
    }
    const LocoInfo::Parsed parsed = LocoInfo::parseBody(m_layout, m_config.lastSentBody);
    if (!parsed.ok) {
        return LocoInfo::Values();
    }
    return parsed.values;
}

void LocoConfigWindow::loadConfig(const QString &name)
{
    m_loadingConfig = true;
    m_config = m_store->config(name);
    m_model->setConfig(m_config.values, m_defaults, lastSentValues());
    m_targetIp->setText(m_config.targetIp);
    m_targetPort->setValue(m_config.port);
    m_loadingConfig = false;
    refreshSummary();
}

void LocoConfigWindow::onConfigChosen(int index)
{
    const QString name = m_configCombo->itemData(index).toString();
    if (name.isEmpty() || name == m_config.name) {
        return;
    }
    if (m_saveTimer.isActive()) {
        saveNow();
    }
    m_store->setActiveName(name);
    m_store->save();
    loadConfig(name);
}

void LocoConfigWindow::applyValues(const LocoInfo::Values &values)
{
    m_config.values = values;
    LocoInfo::completeValues(m_layout, m_defaults, &m_config.values);
    m_model->setConfig(m_config.values, m_defaults, lastSentValues());
    scheduleSave();
    refreshSummary();
}

void LocoConfigWindow::onValueEdited(const QString &key)
{
    Q_UNUSED(key);
    m_config.values = m_model->values();
    m_filter->refresh();
    scheduleSave();
    refreshSummary();
}

void LocoConfigWindow::scheduleSave()
{
    m_saveTimer.start();
}

void LocoConfigWindow::saveNow()
{
    m_saveTimer.stop();
    m_store->upsert(m_config);
    if (!m_store->save()) {
        m_status->fail(m_store->lastError());
    }
}

void LocoConfigWindow::newConfig()
{
    bool ok = false;
    const QString name = QInputDialog::getText(this, tr("New configuration"),
                                               tr("Name (e.g. the loco number):"), QLineEdit::Normal,
                                               QString(), &ok).trimmed();
    if (!ok || name.isEmpty()) {
        return;
    }
    if (m_store->contains(name)) {
        QMessageBox::warning(this, windowTitle(), tr("There is already a configuration called \"%1\".").arg(name));
        return;
    }
    saveNow();
    LocoInfo::LocoConfig config;
    config.name = name;
    config.values = m_defaults;
    config.targetIp = m_config.targetIp;
    config.port = m_config.port;
    m_store->upsert(config);
    m_store->setActiveName(name);
    m_store->save();
    reloadConfigCombo();
    loadConfig(name);
}

void LocoConfigWindow::duplicateConfig()
{
    bool ok = false;
    const QString name = QInputDialog::getText(this, tr("Duplicate configuration"), tr("Name of the copy:"),
                                               QLineEdit::Normal, m_config.name + tr(" (copy)"), &ok).trimmed();
    if (!ok || name.isEmpty()) {
        return;
    }
    if (m_store->contains(name)) {
        QMessageBox::warning(this, windowTitle(), tr("There is already a configuration called \"%1\".").arg(name));
        return;
    }
    saveNow();
    LocoInfo::LocoConfig copy = m_config;
    copy.name = name;
    // A copy has never been sent anywhere.
    copy.lastSentBody.clear();
    copy.lastSentAt = QDateTime();
    copy.lastSentTarget.clear();
    m_store->upsert(copy);
    m_store->setActiveName(name);
    m_store->save();
    reloadConfigCombo();
    loadConfig(name);
}

void LocoConfigWindow::renameConfig()
{
    bool ok = false;
    const QString name = QInputDialog::getText(this, tr("Rename configuration"), tr("New name:"),
                                               QLineEdit::Normal, m_config.name, &ok).trimmed();
    if (!ok || name.isEmpty() || name == m_config.name) {
        return;
    }
    if (m_store->contains(name)) {
        QMessageBox::warning(this, windowTitle(), tr("There is already a configuration called \"%1\".").arg(name));
        return;
    }
    const QString previous = m_config.name;
    m_config.name = name;
    m_store->upsert(m_config, previous);
    m_store->setActiveName(name);
    saveNow();
    reloadConfigCombo();
}

void LocoConfigWindow::deleteConfig()
{
    if (m_store->names().size() <= 1) {
        QMessageBox::information(this, windowTitle(), tr("The last configuration cannot be deleted."));
        return;
    }
    const auto answer = QMessageBox::question(
        this, windowTitle(),
        tr("Delete the configuration \"%1\"?\n\nIts sends stay in the history.").arg(m_config.name),
        QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
    if (answer != QMessageBox::Yes) {
        return;
    }
    m_saveTimer.stop();
    m_store->remove(m_config.name);
    m_store->save();
    reloadConfigCombo();
    loadConfig(m_store->activeName());
}

void LocoConfigWindow::resetToDefaults()
{
    const auto answer = QMessageBox::question(
        this, windowTitle(),
        tr("Set every field of \"%1\" back to the defaults (%2)?").arg(m_config.name, m_defaultsSource),
        QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
    if (answer == QMessageBox::Yes) {
        applyValues(m_defaults);
        m_status->say(tr("All fields reset to defaults"));
    }
}

// =============================================================================
//  Files
// =============================================================================

void LocoConfigWindow::importBin()
{
    const QString path = QFileDialog::getOpenFileName(this, tr("Import loco_info.bin"), QString(),
                                                      tr("LOCO_INFO (*.bin);;All files (*)"));
    if (path.isEmpty()) {
        return;
    }
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) {
        QMessageBox::warning(this, windowTitle(), tr("Could not read %1:\n%2").arg(path, file.errorString()));
        return;
    }
    const LocoInfo::Parsed parsed = LocoInfo::parseBody(m_layout, file.readAll());
    if (!parsed.ok) {
        QMessageBox::warning(this, windowTitle(), tr("%1 is not a LOCO_INFO file:\n%2").arg(path, parsed.error));
        return;
    }
    QString question = tr("Load %1 into \"%2\"? Its current values are replaced.")
                           .arg(QFileInfo(path).fileName(), m_config.name);
    if (!parsed.crcOk) {
        question = tr("The file's loco_info_crc is %1 but its contents give %2: it was damaged or edited "
                      "by hand.\n\n").arg(LocoInfo::crcText(parsed.storedCrc), LocoInfo::crcText(parsed.computedCrc))
                   + question + tr("\n\nThe CRC is recomputed on send.");
    }
    const auto answer = QMessageBox::question(this, windowTitle(), question,
                                              QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
    if (answer == QMessageBox::Yes) {
        applyValues(parsed.values);
        m_status->ok(tr("Loaded %1").arg(QFileInfo(path).fileName()));
    }
}

bool LocoConfigWindow::writeBin(const QString &path, const QByteArray &body)
{
    QFile file(path);
    if (!file.open(QIODevice::WriteOnly)) {
        QMessageBox::warning(this, windowTitle(), tr("Could not write %1:\n%2").arg(path, file.errorString()));
        return false;
    }
    file.write(body);
    return true;
}

void LocoConfigWindow::exportBin()
{
    const QString blocker = sendBlocker();
    const QByteArray body = currentBody();
    if (body.isEmpty()) {
        QMessageBox::warning(this, windowTitle(), blocker);
        return;
    }
    const QString path = QFileDialog::getSaveFileName(this, tr("Export loco_info.bin"),
                                                      QStringLiteral("loco_info.bin"),
                                                      tr("LOCO_INFO (*.bin)"));
    if (path.isEmpty()) {
        return;
    }
    if (writeBin(path, body)) {
        m_status->ok(tr("Wrote %1 (%2 bytes, CRC %3)")
                         .arg(QFileInfo(path).fileName()).arg(body.size())
                         .arg(LocoInfo::crcText(LocoInfo::crc32(body.left(body.size() - 4)))));
    }
}

// =============================================================================
//  Summary and sending
// =============================================================================

QByteArray LocoConfigWindow::currentBody() const
{
    return LocoInfo::encodeBody(m_layout, m_config.values);
}

QString LocoConfigWindow::sendBlocker() const
{
    const QStringList problems = LocoInfo::validate(m_layout, m_config.values);
    if (!problems.isEmpty()) {
        return problems.first();
    }
    QHostAddress address;
    if (!address.setAddress(m_config.targetIp) || address.protocol() != QAbstractSocket::IPv4Protocol) {
        return tr("The VCC IP address is not a valid IPv4 address");
    }
    return QString();
}

void LocoConfigWindow::refreshSummary()
{
    if (m_summary == nullptr || m_model == nullptr) {
        return;
    }
    const QByteArray body = currentBody();
    if (!body.isEmpty()) {
        const quint32 crc = LocoInfo::crc32(body.left(body.size() - 4));
        m_summary->setText(tr("%1-byte message · src %2 → dest %3 · msg %4 · loco_info_crc %5")
                               .arg(body.size() + LocoInfo::kHeaderBytes)
                               .arg(LocoInfo::kSourceId).arg(LocoInfo::kDestId).arg(LocoInfo::kMessageId)
                               .arg(LocoInfo::crcText(crc)));
    } else {
        m_summary->setText(tr("Cannot be packed — see below"));
    }

    // vcc_crc is set by hand and has to match the VCC build on the loco, so
    // it is repeated here, where the operator is about to press Send.
    const LocoInfo::Field *vccField = m_layout.field(QStringLiteral("vcc_crc"));
    if (vccField != nullptr) {
        m_vccCrc->setText(tr("vcc_crc %1 — set by hand; it must match the VCC build on this loco")
                              .arg(LocoInfo::formatValue(*vccField, m_config.values.value(vccField->key))));
        m_vccCrc->setStyleSheet(UiColor::style(FlasherStyle::attention()));
    }

    if (m_config.lastSentBody.isEmpty()) {
        m_lastSent->setText(tr("Not sent from this configuration yet"));
    } else {
        const QStringList changed = LocoInfo::changedKeys(m_layout, lastSentValues(), m_config.values);
        QString changes = tr("no changes since");
        if (changed.size() == 1) {
            changes = tr("1 field changed since");
        } else if (changed.size() > 1) {
            changes = tr("%1 fields changed since").arg(changed.size());
        }
        m_lastSent->setText(tr("Last sent %1 to %2 · %3")
                                .arg(m_config.lastSentAt.toLocalTime().toString(QStringLiteral("yyyy-MM-dd HH:mm:ss")),
                                     m_config.lastSentTarget, changes));
    }

    const QString blocker = sendBlocker();
    m_sendButton->setEnabled(blocker.isEmpty());
    if (blocker.isEmpty()) {
        m_blocker->clear();
    } else {
        m_blocker->setText(QStringLiteral("⚠ ") + blocker);
        m_blocker->setStyleSheet(UiColor::style(FlasherStyle::attention()));
    }
    refreshGroupCounts();
}

void LocoConfigWindow::refreshGroupCounts()
{
    // Each group shows how many of its fields differ from the defaults, so
    // a hand-edit in a group the operator is not looking at stays visible.
    QHash<QString, int> changedPerGroup;
    int changedFromDefault = 0;
    int changedSinceSent = 0;
    const LocoInfo::Values sent = lastSentValues();
    for (const LocoInfo::Field &field : m_layout.fields()) {
        if (field.isCrc) {
            continue;
        }
        const QVariant value = m_config.values.value(field.key);
        if (!LocoInfo::sameValue(field, value, m_defaults.value(field.key))) {
            ++changedFromDefault;
            changedPerGroup[m_presentation.groupOf(field.key)] += 1;
        }
        if (!sent.isEmpty() && !LocoInfo::sameValue(field, value, sent.value(field.key))) {
            ++changedSinceSent;
        }
    }
    for (int row = 0; row < m_groups->count(); ++row) {
        QListWidgetItem *item = m_groups->item(row);
        const QString key = item->data(Qt::UserRole).toString();
        int count = changedPerGroup.value(key);
        if (key == LocoFieldFilter::allFields()) {
            count = 0;
        } else if (key == LocoFieldFilter::changedFromDefault()) {
            count = changedFromDefault;
        } else if (key == LocoFieldFilter::changedSinceSent()) {
            count = changedSinceSent;
        }
        if (count > 0) {
            item->setText(QStringLiteral("%1  (%2)").arg(key).arg(count));
        } else {
            item->setText(key);
        }
    }
}

void LocoConfigWindow::onGroupChanged()
{
    QListWidgetItem *item = m_groups->currentItem();
    if (item != nullptr) {
        m_filter->setGroup(item->data(Qt::UserRole).toString());
    }
}

void LocoConfigWindow::setTarget(const QString &ip, quint16 port)
{
    m_targetIp->setText(ip);
    m_targetPort->setValue(port);
}

bool LocoConfigWindow::sendNow(bool confirm)
{
    if (!isUsable()) {
        return false;
    }
    const QString blocker = sendBlocker();
    if (!blocker.isEmpty()) {
        m_status->fail(blocker);
        return false;
    }
    const QByteArray body = currentBody();
    const QString target = QStringLiteral("%1:%2").arg(m_config.targetIp).arg(m_config.port);

    if (confirm) {
        // Say exactly what is about to change on the loco, relative to the
        // last thing this configuration sent. The VCC will not confirm it, so
        // this is the operator's last look.
        QString summary;
        QStringList details;
        if (m_config.lastSentBody.isEmpty()) {
            summary = tr("This configuration has not been sent before: all %1 fields go out.")
                          .arg(m_layout.fields().size() - 1);
        } else {
            const LocoInfo::Values sent = lastSentValues();
            const QStringList changed = LocoInfo::changedKeys(m_layout, sent, m_config.values);
            for (const QString &key : changed) {
                const LocoInfo::Field *field = m_layout.field(key);
                const QString format = m_presentation.formats.value(key);
                details.append(QStringLiteral("%1: %2 → %3")
                                   .arg(key, LocoInfo::formatValue(*field, sent.value(key), format),
                                        LocoInfo::formatValue(*field, m_config.values.value(key), format)));
            }
            if (changed.isEmpty()) {
                summary = tr("Nothing has changed since the last send (%1): the same bytes go out again.")
                              .arg(m_config.lastSentAt.toLocalTime().toString(QStringLiteral("yyyy-MM-dd HH:mm")));
            } else {
                summary = tr("%n field(s) changed since the last send:", "", changed.size());
                const QStringList shown = details.mid(0, kChangesShownInline);
                summary += QLatin1Char('\n') + shown.join(QLatin1Char('\n'));
                if (details.size() > shown.size()) {
                    summary += tr("\n… and %1 more (Show Details)").arg(details.size() - shown.size());
                }
            }
        }
        QMessageBox box(QMessageBox::Question, windowTitle(),
                        tr("Send \"%1\" to the VCC at %2?").arg(m_config.name, target),
                        QMessageBox::Yes | QMessageBox::No, this);
        const LocoInfo::Field *vccField = m_layout.field(QStringLiteral("vcc_crc"));
        QString vccLine;
        if (vccField != nullptr) {
            vccLine = tr("\n\nvcc_crc %1 · loco_info_crc %2")
                          .arg(LocoInfo::formatValue(*vccField, m_config.values.value(vccField->key)),
                               LocoInfo::crcText(LocoInfo::crc32(body.left(body.size() - 4))));
        }
        box.setInformativeText(summary + vccLine + tr("\n\nThe VCC does not reply; nothing will confirm it arrived."));
        if (!details.isEmpty()) {
            box.setDetailedText(details.join(QLatin1Char('\n')));
        }
        box.setDefaultButton(QMessageBox::No);
        if (box.exec() != QMessageBox::Yes) {
            return false;
        }
    }

    if (!m_sender->sendOnce(LocoInfo::message(body), m_config.targetIp, m_config.port)) {
        // UdpSender has already reported why through error().
        return false;
    }

    // Record it: in the configuration (for "changed since last send") and in
    // the append-only history (for the audit trail and re-export).
    const QDateTime now = QDateTime::currentDateTimeUtc();
    m_config.lastSentBody = body;
    m_config.lastSentAt = now;
    m_config.lastSentTarget = target;
    saveNow();

    LocoInfo::SendRecord record;
    record.when = now;
    record.operatorName = LocoInfo::currentOperatorName();
    record.configName = m_config.name;
    record.target = target;
    record.crc = LocoInfo::crc32(body.left(body.size() - 4));
    record.vccCrc = static_cast<quint32>(m_config.values.value(QStringLiteral("vcc_crc")).toLongLong());
    record.body = body;
    const bool recorded = m_history->append(record);

    m_model->setConfig(m_config.values, m_defaults, lastSentValues());
    m_filter->refresh();
    refreshSummary();
    if (m_historyDialog) {
        m_historyDialog->reload();
    }
    if (recorded) {
        m_status->ok(tr("Sent %1 bytes to %2 at %3 — no reply is expected")
                         .arg(body.size() + LocoInfo::kHeaderBytes).arg(target)
                         .arg(now.toLocalTime().toString(QStringLiteral("HH:mm:ss"))));
    } else {
        m_status->fail(tr("Sent, but NOT recorded in the history: %1").arg(m_history->lastError()));
    }
    emit sent();
    return true;
}

// =============================================================================
//  History and closing
// =============================================================================

void LocoConfigWindow::openHistory()
{
    if (!m_historyDialog) {
        m_historyDialog = new LocoConfigHistoryDialog(m_history->filePath(), &m_layout, this);
        m_historyDialog->setAttribute(Qt::WA_DeleteOnClose);
        connect(m_historyDialog, &LocoConfigHistoryDialog::loadRequested, this,
                [this](const QByteArray &body, const QString &description) {
                    const LocoInfo::Parsed parsed = LocoInfo::parseBody(m_layout, body);
                    if (!parsed.ok) {
                        return;
                    }
                    const auto answer = QMessageBox::question(
                        this, windowTitle(),
                        tr("Load the values sent %1 into \"%2\"? Its current values are replaced.")
                            .arg(description, m_config.name),
                        QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
                    if (answer == QMessageBox::Yes) {
                        applyValues(parsed.values);
                        m_status->ok(tr("Loaded the values sent %1").arg(description));
                    }
                });
    } else {
        m_historyDialog->reload();
    }
    m_historyDialog->show();
    m_historyDialog->raise();
    m_historyDialog->activateWindow();
}

void LocoConfigWindow::closeEvent(QCloseEvent *event)
{
    if (m_store != nullptr && m_saveTimer.isActive()) {
        saveNow();
    }
    WindowGeometry::save(this, QStringLiteral("locoConfiguration"));
    QMainWindow::closeEvent(event);
}
