#ifndef LOCOCONSOLEWINDOW_H
#define LOCOCONSOLEWINDOW_H

// =============================================================================
//  LocoConsoleWindow
//  -----------------------------------------------------------------------------
//  A separate top-level window showing the live loco capture stream
//  (ui_capture.c), which arrives as LogEntry::text via the shared
//  MessageDispatcher. One tab per packet type, each a Field|Value table built
//  by CaptureDecoder::describe() for the latest frame of that type, plus a
//  "Link" overview tab (per-type rate / last-seen / seq / CRC). A loco/ctrl
//  selector picks which source the tabs reflect.
//
//  Find (Ctrl+F, F3 / Shift+F3): a TableFindBar under the tabs searches the
//  current tab's fields by name -- the way to get to one member of a
//  170-row struct like LINFO. The tables are rebuilt on every refresh, so
//  the bar is re-applied after each one (see tablefindbar.h).
//
//  Recording (multi-source):
//    The Record button opens a selection dialog listing every seen loco/ctrl
//    key. Each selected source is streamed to its OWN .cap file (base path
//    chosen once, a "_<loco>_<ctrl>" suffix added per source). Files are
//    opened lazily on the first matching line. Keeping one key per file means
//    every produced capture replays correctly in ReplayWindow, whose load()
//    does not filter by key.
// =============================================================================

#include <QMainWindow>
#include <QHash>
#include <QMap>
#include <QSet>
#include <QVector>

#include "capturedecoder.h"
#include "logentry.h"

class MessageDispatcher;
class QComboBox;
class QLabel;
class QPushButton;
class QTableWidget;
class QTabWidget;
class QTimer;
class TableFindBar;
class QFile;
class QTextStream;

class LocoConsoleWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit LocoConsoleWindow(MessageDispatcher *dispatcher, QWidget *parent = nullptr);
    ~LocoConsoleWindow() override;

protected:
    // Remember size/position for the next opening.
    void closeEvent(QCloseEvent *event) override;

private slots:
    void onEntryAppended(QString tabKey, LogEntryPtr entry);
    void onSelectionChanged(int index);
    void onRefreshTick();
    void onToggleRecord();
    void onOpenReplay();
    void onTabChanged(int index);

public:
    // For the tests: the find bar and the per-type table for a tab label.
    TableFindBar *findBar() const { return m_find; }
    QTableWidget *tableForLabel(const QString &label) const;
    QTabWidget   *tabs() const { return m_tabs; }

private:

private:
    struct LinkStat {
        quint64 count      = 0;
        quint64 prevCount  = 0;
        double  rate       = 0.0;
        qint64  lastSeenMs = 0;
        quint32 lastSeq    = 0;
        quint64 crcOkCount = 0;
        quint64 crcFail    = 0;
    };

    struct LocoState {
        int       locoId = -1;
        int       ctrlId = -1;
        QDateTime rtc;

        QMap<int, LinkStat>    link;     // (int)CapType -> stats
        QMap<int, CaptureLine> latest;   // (int)CapType -> latest full frame

        bool    seqInit = false;
        quint32 lastSeq = 0;
        quint64 seqGaps = 0;
        quint64 total   = 0;
    };

    // One open output for a single recorded source.
    struct RecordSink {
        QFile       *file   = nullptr;
        QTextStream *stream = nullptr;
    };

    void buildUi();
    void addTypeTab(CapType t);
    void ingest(const CaptureLine &c, qint64 nowMs);
    void refreshHeader(const LocoState &st, qint64 nowMs);
    void refreshLink  (const LocoState &st, qint64 nowMs);
    void refreshTypeTables(const LocoState &st);
    static QString ageText(qint64 ageMs);

    // ---- multi-source recording -------------------------------------
    // Returns false if the user cancelled. On success, outKeys holds the
    // explicitly chosen source keys and outAutoNew whether sources that
    // appear later should also be captured.
    bool    promptRecordSelection(QSet<QString> &outKeys, bool &outAutoNew);
    void    startRecording(const QSet<QString> &keys, bool autoNew);
    void    stopRecording();
    void    routeRecord(const QString &key, const QString &rawLine);
    QString sinkPathFor(const QString &key) const;
    void    updateRecordButton();
    static QString replayDirPath();    // ensure + return the absolute replay/ folder

    MessageDispatcher *m_dispatcher = nullptr;

    QHash<QString, LocoState> m_states;
    QString                   m_selectedKey;
    bool                      m_dirty = false;

    QComboBox    *m_selector  = nullptr;
    QLabel       *m_lblRtc    = nullptr;
    QLabel       *m_lblRate   = nullptr;
    QLabel       *m_lblCrc    = nullptr;
    QLabel       *m_lblSeq    = nullptr;
    QTabWidget   *m_tabs      = nullptr;
    QTableWidget *m_linkTable = nullptr;
    QMap<int, QTableWidget*>  m_typeTables;   // (int)CapType -> field table
    QTimer       *m_refresh   = nullptr;
    TableFindBar *m_find      = nullptr;

    // Colour tags follow the loco here too. A tag is stored per TAB key (the
    // UDP header's source id / kavach id); the selector lists the capture
    // line's own loco / ctrl ids. They are not assumed to be the same
    // numbers: each capture key maps to the tab its lines arrived on.
    QHash<QString, QString> m_tabKeyFor;
    void refreshTagDisplay();

    QPushButton  *m_btnRecord = nullptr;

    // Recording state. m_recSinks maps a source key -> its open .cap file.
    // A key present with a null stream means "open failed, don't retry".
    bool                      m_recording  = false;
    bool                      m_recAutoNew = false;   // capture sources seen after start
    QSet<QString>             m_recWanted;            // explicitly selected keys
    QString                   m_recDir;               // absolute replay/ folder for this session
    QString                   m_recStamp;             // ddMMyyyy_HHmmss, fixed at record start
    QMap<QString, RecordSink> m_recSinks;             // key -> open file/stream
};

#endif // LOCOCONSOLEWINDOW_H
