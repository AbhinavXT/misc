#ifndef FIELDPLOT_H
#define FIELDPLOT_H

// =============================================================================
//  FieldPlot
//  -----------------------------------------------------------------------------
//  Track one decoded field's value across a whole tab or session and draw it
//  against time.
//
//  WHY
//    The field inspector answers "what does this frame say?". The question
//    that follows is almost always "and what was it doing before?" — did
//    the authorised speed step down or collapse, did the link quality decay
//    or drop out, was the counter already wrong three minutes earlier. That
//    is a shape over time, and reading it out of a table one row at a time
//    is exactly the work a plot removes.
//
//  THE HONEST-VALUE PROBLEM
//    Decoded values are display strings, not numbers: "42", "42 km/h",
//    "0x2A", "ON", "RESERVED (7)". Plotting requires a number, and the
//    tempting shortcut — QString::toDouble() and drop whatever fails — is
//    wrong in a way that matters here. A field that is numeric in 90% of
//    frames and an enum label in the other 10% would silently plot as if
//    those frames did not exist, and a gap in a safety trace reads as "no
//    data" when it actually means "a value I chose not to show you".
//
//    So extraction counts every outcome — matched, non-numeric, undecodable
//    — and the window reports them. A series is only worth trusting
//    alongside the number of rows it had to discard.
//
//  COST
//    Schema-decoding every row is far more expensive than anything else in
//    the app: a full 200,000-row tab would mean 200,000 decodes. Extraction
//    takes a row cap and reports whether it hit it, and the window samples
//    from the whole span rather than truncating at the cap — a plot of the
//    first 5% of a session, presented as the session, would be worse than
//    no plot.
// =============================================================================

#include <QString>
#include <QStringList>
#include <QVector>
#include <QWidget>

#include "statusline.h"

#include "logentry.h"

class LogModel;
namespace Schema { class Decoder; }

// ---- extraction (no UI; tested directly) ---------------------------------

// Pull a number out of a decoded field's display string.
//
// Accepts: "42", "-3.5", "42 km/h", "0x2A", "  7  ". Rejects anything with
// no leading numeric part, which is the caller's signal to count it as
// non-numeric rather than as zero.
double parseFieldNumber(const QString &display, bool *ok);

struct FieldSeries {
    struct Point {
        qint64 epochMs = 0;
        double value   = 0.0;
        int    row     = -1;      // row in the source model, for jumping
    };

    QVector<Point> points;

    // Provenance of the sample. All four are reported to the operator.
    int rowsScanned    = 0;   // rows we attempted
    int rowsDecoded    = 0;   // rows the schema could decode
    int rowsMatched    = 0;   // rows that contained the field
    int rowsNonNumeric = 0;   // field present but not a number
    bool hitRowCap     = false;

    double minValue = 0.0, maxValue = 0.0;
    qint64 minMs    = 0,   maxMs    = 0;

    bool isEmpty() const { return points.isEmpty(); }
};

// Walk `model` and build a series for `fieldName` (matched on the trimmed
// field label). Samples evenly across the model when it is larger than
// `maxRows`, so the result spans the whole session rather than its start.
FieldSeries extractFieldSeries(const LogModel *model,
                               const QString &fieldName,
                               const Schema::Decoder &decoder,
                               int maxRows = 20000);

// Field labels present in the first `sampleRows` decodable rows, trimmed
// and de-duplicated, for populating the field chooser.
QStringList discoverFieldNames(const LogModel *model,
                               const Schema::Decoder &decoder,
                               int sampleRows = 200);

// Tick values for an axis spanning [lo, hi], about `target` of them, on a
// 1-2-5 step.
//
// The reason this is not just lo + span*i/4: LOCO_MODE takes the values 1,
// 2, 4 and 6, and dividing that range into quarters labelled the axis
// 2.25, 3.5, 4.75 — numbers the field cannot hold. An enum axis has to be
// labelled in the units the field is actually in, so when every sample is
// a whole number the step is forced to a whole number too.
QVector<double> niceTicks(double lo, double hi, int target, bool integerOnly);

// How many decimals a label needs for this step. 0 for an integer axis.
int tickDecimals(double step);

// ---- widgets --------------------------------------------------------------

class FieldPlotCanvas : public QWidget
{
    Q_OBJECT
public:
    explicit FieldPlotCanvas(QWidget *parent = nullptr);
    void setSeries(const FieldSeries &s);

signals:
    void pointActivated(int modelRow, qint64 epochMs);

protected:
    void paintEvent(QPaintEvent *) override;
    void mouseMoveEvent(QMouseEvent *) override;
    void mousePressEvent(QMouseEvent *) override;
    QSize sizeHint() const override { return QSize(600, 260); }

private:
    int nearestPoint(int px, int py) const;
    QRect plotRect() const;

    FieldSeries m_series;
    int  m_hover     = -1;
    bool m_allWhole  = false;   // every sample is a whole number
};

class QComboBox;
class QLabel;
class QPushButton;

class FieldPlotWindow : public QWidget
{
    Q_OBJECT
public:
    FieldPlotWindow(LogModel *model, const QString &tabKey,
                    QWidget *parent = nullptr);

    // Open straight onto a named field, for a caller who already knows which
    // one — right-clicking a field row names it, and being dropped on the
    // chooser afterwards would be asking the same question twice.
    //
    // A field the sample never saw is still selected: the chooser lists what
    // the first few hundred rows happened to carry, which is not the same as
    // what the session contains, and refusing it here would refuse fields
    // that do plot.
    void plotField(const QString &fieldName);

protected:
    // Remember size/position for the next opening.
    void closeEvent(QCloseEvent *event) override;

signals:
    void jumpRequested(const QString &tabKey, qint64 epochMs);

private slots:
    void refreshFields();
    void replot();

private:
    LogModel *m_model = nullptr;
    QString   m_tabKey;

    QComboBox       *m_fieldBox = nullptr;
    StatusLine      *m_status   = nullptr;
    QPushButton     *m_rescan   = nullptr;
    FieldPlotCanvas *m_canvas   = nullptr;
};

#endif // FIELDPLOT_H
