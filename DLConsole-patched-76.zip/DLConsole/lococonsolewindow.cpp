#include "lococonsolewindow.h"
#include "uistyle.h"
#include "uicolors.h"
#include "windowgeometry.h"
#include "messagedispatcher.h"
#include "replaywindow.h"

#include <QCloseEvent>
#include <QFile>
#include <QFileDialog>
#include <QPushButton>
#include <QTextStream>

#include <QCheckBox>
#include <QComboBox>
#include <QDateTime>
#include <QDialog>
#include <QDialogButtonBox>
#include <QDir>
#include <QFontDatabase>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QLabel>
#include <QMessageBox>
#include <QScrollArea>
#include <QTabWidget>
#include <QTableWidget>
#include <QTimer>
#include <QShortcut>

#include "tablefindbar.h"
#include "tabtags.h"
#include <QVBoxLayout>
#include <QWidget>

namespace {
const int    kRefreshMs = 250;
const qint64 kStaleMs   = 4000;
const qint64 kDeadMs    = 10000;

// Recordings land in a "replay" folder next to SAVED_LOGS/LOGS (created on
// demand, relative to the working dir like SaveData's SAVED_LOGS). Each file
// is "<stem>_<loco>_<ctrl>_<ddMMyyyy_HHmmss>.cap".
const char *kReplaySubdir = "replay";
const char *kCapStem      = "loco";

// Tab order: the four radio frames first (as requested), then DMI, then the
// NMS types, RFID, the digital IO frames, and finally the controller/logger
// self-status frames (ccsys/dlsys). All of these are decode-capable
// (describe() handles them) and shown in the replay window, so they belong
// here too.
const CapType kTabOrder[] = {
    CapType::SLRP, CapType::AAP, CapType::ARP, CapType::ArpRecv, CapType::LSRP,
    CapType::Dmi,
    CapType::NmsHlth, CapType::NmsFault, CapType::NmsRssi,
    CapType::Rfid,
    CapType::Dip1, CapType::Dip2, CapType::Dop1, CapType::Dop2,
    CapType::CcSys, CapType::DlSys, CapType::Aep, CapType::Linfo,
    CapType::AuthKeys,                      // key-set lifecycle (from LCU)
    CapType::Random,                        // session nonce pair
    CapType::UBA,                           // target + braking curve
    CapType::Speed,                         // tachometer pulses
    CapType::AnalogTop, CapType::AnalogBottom   // analog (pressure) inputs
};
const int kTabOrderCount = int(sizeof(kTabOrder) / sizeof(kTabOrder[0]));

// Link-overview row order (also includes anything else that may arrive).
const CapType kLinkOrder[] = {
    CapType::SLRP, CapType::AAP, CapType::ARP, CapType::ArpRecv, CapType::LSRP,
    CapType::NmsHlth, CapType::NmsFault, CapType::NmsRssi,
    CapType::Dlt, CapType::Dmi, CapType::Biu, CapType::Brk,
    CapType::Rfid,
    CapType::Dip1, CapType::Dip2, CapType::Dop1, CapType::Dop2,
    CapType::CcSys, CapType::DlSys, CapType::Aep, CapType::Linfo,
    CapType::AuthKeys, CapType::Random, CapType::UBA,
    CapType::Speed, CapType::AnalogTop, CapType::AnalogBottom
};
const int kLinkOrderCount = int(sizeof(kLinkOrder) / sizeof(kLinkOrder[0]));

// These were the dark-theme values, used in both themes — green on a white
// background at 2.4:1. They now follow the palette.
QColor okColor()   { return UiColor::ok(); }
QColor warnColor() { return UiColor::warning(); }
QColor failColor() { return UiColor::error(); }
QColor dimColor()  { return UiColor::muted(); }

const char *dirText(CapDir d) {
    switch (d) { case CapDir::In: return "RX"; case CapDir::Out: return "TX"; default: return "--"; }
}
} // namespace

LocoConsoleWindow::LocoConsoleWindow(MessageDispatcher *dispatcher, QWidget *parent)
    : QMainWindow(parent)
    , m_dispatcher(dispatcher)
{
    setWindowTitle(tr("Live Loco Console"));
    WindowGeometry::makeResizableWindow(this);
    setWindowFlag(Qt::Window);
    resize(840, 580);
    // Default above; a remembered size/position wins over it.
    WindowGeometry::restore(this, QStringLiteral("locoConsole"));

    buildUi();

    if (m_dispatcher) {
        connect(m_dispatcher, &MessageDispatcher::entryAppended,
                this,         &LocoConsoleWindow::onEntryAppended);
    }

    m_refresh = new QTimer(this);
    m_refresh->setInterval(kRefreshMs);
    connect(m_refresh, &QTimer::timeout, this, &LocoConsoleWindow::onRefreshTick);
    m_refresh->start();
}

LocoConsoleWindow::~LocoConsoleWindow()
{
    // Flush/close any recording files if the window is destroyed mid-record.
    for (RecordSink &s : m_recSinks) {
        if (s.stream) { s.stream->flush(); delete s.stream; s.stream = nullptr; }
        if (s.file)   { s.file->close();  delete s.file;   s.file   = nullptr; }
    }
    m_recSinks.clear();
}

void LocoConsoleWindow::addTypeTab(CapType t)
{
    QTableWidget *tbl = new QTableWidget(0, 2, m_tabs);
    tbl->setHorizontalHeaderLabels({tr("Field"), tr("Value")});
    tbl->verticalHeader()->setVisible(false);
    tbl->setEditTriggers(QAbstractItemView::NoEditTriggers);
    tbl->setSelectionBehavior(QAbstractItemView::SelectRows);
    tbl->setFont(QFontDatabase::systemFont(QFontDatabase::FixedFont));
    tbl->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    tbl->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch);
    m_tabs->addTab(tbl, QString::fromLatin1(CaptureDecoder::typeLabel(t)));
    m_typeTables.insert(int(t), tbl);
}

void LocoConsoleWindow::buildUi()
{
    QWidget *central = new QWidget(this);
    QVBoxLayout *root = new QVBoxLayout(central);
    root->setContentsMargins(10, 8, 10, 10);
    root->setSpacing(8);

    // ---- top strip ------------------------------------------------------
    QHBoxLayout *top = new QHBoxLayout();
    top->addWidget(new QLabel(tr("Loco / Ctrl:"), central));
    m_selector = new QComboBox(central);
    m_selector->setMinimumWidth(120);
    top->addWidget(m_selector);
    top->addSpacing(16);
    m_lblRtc  = new QLabel(tr("RTC --"), central);
    m_lblRate = new QLabel(tr("-- pkt/s"), central);
    m_lblCrc  = new QLabel(tr("CRC --"), central);
    m_lblSeq  = new QLabel(tr("seq --"), central);
    top->addWidget(m_lblRtc);
    top->addStretch(1);
    top->addWidget(m_lblRate);
    top->addSpacing(12);
    top->addWidget(m_lblCrc);
    top->addSpacing(12);
    top->addWidget(m_lblSeq);

    top->addSpacing(16);
    m_btnRecord = new QPushButton(tr("\u25CF Record"), central);
    m_btnRecord->setToolTip(tr("Record one or more live sources, each to its own .cap file for replay"));
    top->addWidget(m_btnRecord);
    QPushButton *btnReplay = new QPushButton(tr("Replay\u2026"), central);
    btnReplay->setToolTip(tr("Open a recorded .cap file in the replay window"));
    top->addWidget(btnReplay);
    QPushButton *btnFind = new QPushButton(tr("Find\u2026"), central);
    btnFind->setToolTip(tr("Find a field on this tab (Ctrl+F)"));
    top->addWidget(btnFind);

    root->addLayout(top);
    connect(m_selector, qOverload<int>(&QComboBox::currentIndexChanged),
            this,       &LocoConsoleWindow::onSelectionChanged);
    connect(m_btnRecord, &QPushButton::clicked, this, &LocoConsoleWindow::onToggleRecord);
    connect(btnReplay,   &QPushButton::clicked, this, &LocoConsoleWindow::onOpenReplay);

    // ---- tabs: Link overview + one per packet type ----------------------
    m_tabs = new QTabWidget(central);
    UiStyle::useTabTooltips(m_tabs);

    m_linkTable = new QTableWidget(0, 7, m_tabs);
    m_linkTable->setHorizontalHeaderLabels(
        {tr("Packet"), tr("Dir"), tr("Count"), tr("Rate/s"),
         tr("Last seen"), tr("Last seq"), tr("CRC")});
    m_linkTable->verticalHeader()->setVisible(false);
    m_linkTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_linkTable->setSelectionMode(QAbstractItemView::NoSelection);
    m_linkTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    m_tabs->addTab(m_linkTable, tr("Link"));

    for (int i = 0; i < kTabOrderCount; ++i) {
        addTypeTab(kTabOrder[i]);
    }

    root->addWidget(m_tabs);

    // ---- find bar under the tabs -----------------------------------------
    m_find = new TableFindBar(central);
    root->addWidget(m_find);
    QVector<QPair<QString, QTableWidget *>> allTables;
    for (int index = 0; index < m_tabs->count(); ++index) {
        if (auto *table = qobject_cast<QTableWidget *>(m_tabs->widget(index))) {
            allTables.append(qMakePair(m_tabs->tabText(index), table));
        }
    }
    m_find->setAllTables(allTables);
    connect(btnFind, &QPushButton::clicked, m_find, &TableFindBar::open);
    connect(m_tabs, &QTabWidget::currentChanged, this, &LocoConsoleWindow::onTabChanged);
    connect(m_find, &TableFindBar::switchToTable, this, [this](QTableWidget *table) {
        m_tabs->setCurrentWidget(table);
    });
    auto *findShortcut = new QShortcut(QKeySequence::Find, this);
    connect(findShortcut, &QShortcut::activated, m_find, &TableFindBar::open);
    auto *nextShortcut = new QShortcut(QKeySequence::FindNext, this);
    connect(nextShortcut, &QShortcut::activated, this, [this]() {
        if (m_find->isVisible()) {
            m_find->findNext();
        } else {
            m_find->open();
        }
    });
    auto *previousShortcut = new QShortcut(QKeySequence::FindPrevious, this);
    connect(previousShortcut, &QShortcut::activated, m_find, &TableFindBar::findPrevious);
    onTabChanged(m_tabs->currentIndex());
    connect(TabTags::instance(), &TabTags::changed, this, [this]() { refreshTagDisplay(); });
    UiColor::onThemeChange(this, [this]() { refreshTagDisplay(); });

    setCentralWidget(central);
}

void LocoConsoleWindow::onEntryAppended(QString tabKey, LogEntryPtr entry)
{
    if (entry.isNull()) { return; }

    const CaptureLine c = CaptureDecoder::parseLine(entry->text);
    if (!c.valid) { return; }

    if (m_recording) {                       // route to the matching per-source file
        const QString k = c.key();
        if (m_recAutoNew || m_recWanted.contains(k)) {
            routeRecord(k, entry->text);
        }
    }

    const qint64 nowMs = (entry->epochMs != 0)
                         ? entry->epochMs
                         : QDateTime::currentMSecsSinceEpoch();
    ingest(c, nowMs);

    const QString key = c.key();
    const bool newTabMapping = (m_tabKeyFor.value(key) != tabKey);
    m_tabKeyFor.insert(key, tabKey);
    if (m_selector->findText(key) < 0) {
        m_selector->addItem(key);
        if (m_selectedKey.isEmpty()) {
            m_selectedKey = key;
            m_selector->setCurrentText(key);
        }
        refreshTagDisplay();
    } else if (newTabMapping) {
        refreshTagDisplay();
    }
    if (key == m_selectedKey) { m_dirty = true; }
}

void LocoConsoleWindow::ingest(const CaptureLine &c, qint64 nowMs)
{
    LocoState &st = m_states[c.key()];
    st.locoId = c.locoId;
    st.ctrlId = c.ctrlId;
    if (c.rtc.isValid()) { st.rtc = c.rtc; }
    st.total++;

    if (st.seqInit) {
        const quint32 expected = st.lastSeq + 1u;
        if (c.seq > expected) { st.seqGaps += (c.seq - expected); }
    }
    st.lastSeq = c.seq;
    st.seqInit = true;

    LinkStat &ls = st.link[int(c.type)];
    ls.count++;
    ls.lastSeenMs = nowMs;
    ls.lastSeq    = c.seq;
    if (c.crcChecked) { if (c.crcOk) { ls.crcOkCount++; } else { ls.crcFail++; } }

    st.latest[int(c.type)] = c;          // keep the whole frame for the field tab
}

void LocoConsoleWindow::onSelectionChanged(int index)
{
    Q_UNUSED(index);
    m_selectedKey = m_selector->currentText();
    m_dirty = true;
    refreshTagDisplay();
}

void LocoConsoleWindow::refreshTagDisplay()
{
    TabTags *tags = TabTags::instance();
    for (int index = 0; index < m_selector->count(); ++index) {
        const QString tabKey = m_tabKeyFor.value(m_selector->itemText(index));
        m_selector->setItemIcon(index, tags->dotIcon(tabKey));
    }
    // Title and icon name the loco being watched, so a minimised console's
    // chip says which one it is.
    if (m_selectedKey.isEmpty()) {
        setWindowTitle(tr("Live Loco Console"));
        setWindowIcon(QIcon());
        return;
    }
    const QString tabKey = m_tabKeyFor.value(m_selectedKey);
    setWindowTitle(tr("Live Loco Console — %1").arg(tags->decoratedName(tabKey, m_selectedKey)));
    setWindowIcon(tags->dotIcon(tabKey));
}

void LocoConsoleWindow::onRefreshTick()
{
    const double dt = double(kRefreshMs) / 1000.0;
    for (LocoState &st : m_states) {
        for (LinkStat &ls : st.link) {
            const quint64 delta = ls.count - ls.prevCount;
            ls.prevCount = ls.count;
            ls.rate = double(delta) / dt;
        }
    }

    if (m_selectedKey.isEmpty() || !m_states.contains(m_selectedKey)) { return; }
    const LocoState &st = m_states[m_selectedKey];
    const qint64 nowMs = QDateTime::currentMSecsSinceEpoch();

    refreshHeader(st, nowMs);
    refreshLink(st, nowMs);              // ages tick every refresh
    if (m_dirty) {
        refreshTypeTables(st);
        m_dirty = false;
    }
    // The tables were just rebuilt: put the find's tint, hidden rows and
    // current match back (by field name; no scrolling).
    m_find->reapply();
}

void LocoConsoleWindow::onTabChanged(int index)
{
    m_find->setTable(qobject_cast<QTableWidget *>(m_tabs->widget(index)));
}

QTableWidget *LocoConsoleWindow::tableForLabel(const QString &label) const
{
    for (int index = 0; index < m_tabs->count(); ++index) {
        if (m_tabs->tabText(index) == label) {
            return qobject_cast<QTableWidget *>(m_tabs->widget(index));
        }
    }
    return nullptr;
}

QString LocoConsoleWindow::ageText(qint64 ageMs)
{
    if (ageMs < 0)    { return QStringLiteral("--"); }
    if (ageMs < 1000) { return QStringLiteral("%1 ms").arg(ageMs); }
    return QStringLiteral("%1 s").arg(ageMs / 1000.0, 0, 'f', 1);
}

void LocoConsoleWindow::refreshHeader(const LocoState &st, qint64 nowMs)
{
    m_lblRtc->setText(st.rtc.isValid()
                      ? tr("RTC %1").arg(st.rtc.toString("yyyy-MM-dd HH:mm:ss"))
                      : tr("RTC --"));

    double totalRate = 0.0;
    qint64 newestSeen = 0;
    quint64 crcOk = 0, crcFail = 0;
    for (auto it = st.link.constBegin(); it != st.link.constEnd(); ++it) {
        totalRate += it.value().rate;
        newestSeen = qMax(newestSeen, it.value().lastSeenMs);
        crcOk   += it.value().crcOkCount;
        crcFail += it.value().crcFail;
    }
    m_lblRate->setText(tr("%1 pkt/s").arg(totalRate, 0, 'f', 0));

    const quint64 crcTot = crcOk + crcFail;
    m_lblCrc->setText(crcTot ? tr("CRC %1/%2 ok").arg(crcOk).arg(crcTot) : tr("CRC --"));
    m_lblCrc->setStyleSheet(crcFail ? UiColor::errorStyle() : UiColor::okStyle());

    m_lblSeq->setText(tr("seq %1  gaps %2").arg(st.lastSeq).arg(st.seqGaps));
    m_lblSeq->setStyleSheet(st.seqGaps ? UiColor::warningStyle() : QString());

    const qint64 age = (newestSeen > 0) ? (nowMs - newestSeen) : -1;
    const QString live = (age < 0) ? tr("offline")
                       : (age > kDeadMs) ? tr("offline %1").arg(ageText(age))
                       : tr("live");
    setWindowTitle(tr("Live Loco Console  \u2014  %1  (%2)").arg(m_selectedKey, live));
}

void LocoConsoleWindow::refreshLink(const LocoState &st, qint64 nowMs)
{
    int rows = 0;
    for (int i = 0; i < kLinkOrderCount; ++i) {
        if (st.link.contains(int(kLinkOrder[i]))) { ++rows; }
    }
    m_linkTable->setRowCount(rows);

    int r = 0;
    for (int i = 0; i < kLinkOrderCount; ++i) {
        const CapType t = kLinkOrder[i];
        if (!st.link.contains(int(t))) { continue; }
        const LinkStat &ls = st.link[int(t)];
        const qint64 age = nowMs - ls.lastSeenMs;

        auto cell = [&](int col, const QString &txt) {
            QTableWidgetItem *it = new QTableWidgetItem(txt);
            m_linkTable->setItem(r, col, it);
            return it;
        };
        cell(0, QString::fromLatin1(CaptureDecoder::typeLabel(t)));
        cell(1, QString::fromLatin1(dirText(CaptureDecoder::directionFor(t))));
        cell(2, QString::number(ls.count));
        cell(3, QString::number(ls.rate, 'f', 1));
        QTableWidgetItem *seenIt = cell(4, ageText(age));
        cell(5, QString::number(ls.lastSeq));

        QString crcTxt; QColor crcCol = dimColor();
        if (ls.crcFail)        { crcTxt = tr("FAIL %1").arg(ls.crcFail); crcCol = failColor(); }
        else if (ls.crcOkCount){ crcTxt = tr("ok");                      crcCol = okColor(); }
        else                   { crcTxt = tr("--"); }
        cell(6, crcTxt)->setForeground(crcCol);

        if (age > kDeadMs)       { seenIt->setForeground(failColor()); }
        else if (age > kStaleMs) { seenIt->setForeground(warnColor()); }
        ++r;
    }
}

void LocoConsoleWindow::refreshTypeTables(const LocoState &st)
{
    for (auto it = m_typeTables.begin(); it != m_typeTables.end(); ++it) {
        const int     t   = it.key();
        QTableWidget *tbl = it.value();

        if (!st.latest.contains(t)) {
            tbl->setRowCount(1);
            tbl->setItem(0, 0, new QTableWidgetItem(tr("(no data yet)")));
            tbl->setItem(0, 1, new QTableWidgetItem(QString()));
            continue;
        }

        const QVector<FieldRow> rows = CaptureDecoder::describe(st.latest[t]);
        tbl->setRowCount(rows.size());
        for (int r = 0; r < rows.size(); ++r) {
            tbl->setItem(r, 0, new QTableWidgetItem(rows.at(r).field));
            QTableWidgetItem *v = new QTableWidgetItem(rows.at(r).value);
            if (rows.at(r).field == QLatin1String("CRC")) {
                if (rows.at(r).value == QLatin1String("FAIL")) { v->setForeground(failColor()); }
                else if (rows.at(r).value == QLatin1String("PASS")) { v->setForeground(okColor()); }
            }
            tbl->setItem(r, 1, v);
        }
    }
}

// ============================ recording ============================

void LocoConsoleWindow::onToggleRecord()
{
    if (m_recording) { stopRecording(); return; }

    QSet<QString> keys;
    bool autoNew = false;
    if (!promptRecordSelection(keys, autoNew)) { return; }   // cancelled
    if (keys.isEmpty() && !autoNew) {                        // nothing to record
        QMessageBox::information(this, tr("Record"),
            tr("No sources selected."));
        return;
    }
    startRecording(keys, autoNew);
}

bool LocoConsoleWindow::promptRecordSelection(QSet<QString> &outKeys, bool &outAutoNew)
{
    QStringList keys;
    for (int i = 0; i < m_selector->count(); ++i) { keys << m_selector->itemText(i); }
    keys.sort();

    QDialog dlg(this);
    dlg.setWindowTitle(tr("Record sources"));
    QVBoxLayout *lay = new QVBoxLayout(&dlg);

    lay->addWidget(new QLabel(
        tr("Choose which loco / controller streams to record.\n"
           "Each selected source is written to its own .cap file."), &dlg));

    QCheckBox *cbAll = new QCheckBox(tr("Select all current sources"), &dlg);
    lay->addWidget(cbAll);

    QScrollArea *scroll = new QScrollArea(&dlg);
    scroll->setWidgetResizable(true);
    scroll->setMinimumHeight(160);
    QWidget *list = new QWidget(scroll);
    QVBoxLayout *listLay = new QVBoxLayout(list);
    listLay->setContentsMargins(8, 4, 8, 4);

    QVector<QCheckBox*> boxes;
    for (const QString &k : keys) {
        QCheckBox *cb = new QCheckBox(k, list);
        if (k == m_selectedKey) { cb->setChecked(true); }
        listLay->addWidget(cb);
        boxes.push_back(cb);
    }
    listLay->addStretch(1);
    scroll->setWidget(list);
    lay->addWidget(scroll);

    if (keys.isEmpty()) {
        QLabel *none = new QLabel(
            tr("(no sources seen yet \u2014 enable the option below to capture "
               "whatever arrives)"), &dlg);
        none->setStyleSheet(UiColor::mutedStyle());
        none->setWordWrap(true);
        lay->addWidget(none);
    }

    QCheckBox *cbAuto = new QCheckBox(
        tr("Also capture sources that appear after recording starts"), &dlg);
    lay->addWidget(cbAuto);

    connect(cbAll, &QCheckBox::toggled, &dlg, [&boxes](bool on){
        for (QCheckBox *cb : boxes) { cb->setChecked(on); }
    });

    QDialogButtonBox *bb = new QDialogButtonBox(
        QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dlg);
    lay->addWidget(bb);
    connect(bb, &QDialogButtonBox::accepted, &dlg, &QDialog::accept);
    connect(bb, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);

    if (dlg.exec() != QDialog::Accepted) { return false; }

    outKeys.clear();
    for (QCheckBox *cb : boxes) {
        if (cb->isChecked()) { outKeys.insert(cb->text()); }
    }
    outAutoNew = cbAuto->isChecked();
    return true;
}

void LocoConsoleWindow::startRecording(const QSet<QString> &keys, bool autoNew)
{
    const QString dir = replayDirPath();
    if (dir.isEmpty()) {
        QMessageBox::warning(this, tr("Record"),
            tr("Could not create the \"%1\" folder for captures.")
                .arg(QString::fromLatin1(kReplaySubdir)));
        return;
    }

    m_recDir      = dir;
    m_recStamp    = QDateTime::currentDateTime().toString(QStringLiteral("ddMMyyyy_HHmmss"));
    m_recWanted   = keys;
    m_recAutoNew  = autoNew;
    m_recSinks.clear();
    m_recording   = true;
    updateRecordButton();
}

QString LocoConsoleWindow::replayDirPath()
{
    QDir dir(QString::fromLatin1(kReplaySubdir));
    if (!dir.exists() && !dir.mkpath(QStringLiteral("."))) {
        return QString();
    }
    return dir.absolutePath();
}

void LocoConsoleWindow::routeRecord(const QString &key, const QString &rawLine)
{
    auto it = m_recSinks.find(key);
    if (it == m_recSinks.end()) {
        // Lazily open a file for this source on first sight.
        RecordSink s;
        s.file = new QFile(sinkPathFor(key));
        if (s.file->open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) {
            s.stream = new QTextStream(s.file);
            it = m_recSinks.insert(key, s);
            updateRecordButton();            // active-file count changed
        } else {
            delete s.file;                   // open failed
            s.file = nullptr;
            it = m_recSinks.insert(key, s);  // null sink: suppress retry every line
        }
    }
    if (it.value().stream) {
        *it.value().stream << rawLine.trimmed() << '\n';
    }
}

QString LocoConsoleWindow::sinkPathFor(const QString &key) const
{
    QString safe;
    safe.reserve(key.size());
    for (const QChar ch : key) {
        safe += (ch.isLetterOrNumber() || ch == QLatin1Char('_')) ? ch : QLatin1Char('_');
    }
    // <replay>/<stem>_<loco_ctrl>_<ddMMyyyy_HHmmss>.cap — stamp fixed per
    // session, so files never clobber a previous recording.
    return m_recDir + QLatin1Char('/')
           + QString::fromLatin1(kCapStem)
           + QLatin1Char('_') + safe
           + QLatin1Char('_') + m_recStamp
           + QStringLiteral(".cap");
}

void LocoConsoleWindow::stopRecording()
{
    QStringList written;
    for (auto it = m_recSinks.begin(); it != m_recSinks.end(); ++it) {
        RecordSink &s = it.value();
        if (s.stream) { s.stream->flush(); delete s.stream; s.stream = nullptr; }
        if (s.file) {
            written << s.file->fileName();
            s.file->close();
            delete s.file;
            s.file = nullptr;
        }
    }
    m_recSinks.clear();
    m_recWanted.clear();
    m_recAutoNew = false;
    m_recording  = false;
    updateRecordButton();

    if (!written.isEmpty()) {
        written.sort();
        QMessageBox::information(this, tr("Recording saved"),
            tr("Saved %1 capture file(s):\n%2")
                .arg(written.size()).arg(written.join(QLatin1Char('\n'))));
    }
}

void LocoConsoleWindow::updateRecordButton()
{
    if (!m_recording) {
        m_btnRecord->setText(tr("\u25CF Record"));
        m_btnRecord->setStyleSheet(QString());
        return;
    }
    int active = 0;
    for (const RecordSink &s : m_recSinks) {
        if (s.stream) { ++active; }
    }
    m_btnRecord->setText(tr("\u25A0 Stop (%1)").arg(active));
    m_btnRecord->setStyleSheet(UiColor::errorStyle() + QStringLiteral(" font-weight:bold;"));
}

void LocoConsoleWindow::onOpenReplay()
{
    const QStringList paths = QFileDialog::getOpenFileNames(
        this, tr("Open capture(s) for replay \u2014 select several to compare sources"),
        replayDirPath(), tr("Capture files (*.cap);;All files (*)"));
    if (paths.isEmpty()) { return; }
    ReplayWindow *w = new ReplayWindow(paths, nullptr);
    w->setAttribute(Qt::WA_DeleteOnClose);
    w->show();
}

void LocoConsoleWindow::closeEvent(QCloseEvent *event)
{
    // These windows are WA_DeleteOnClose, so this is the last
    // point at which the geometry still exists to be read.
    WindowGeometry::save(this, QStringLiteral("locoConsole"));
    QMainWindow::closeEvent(event);
}
