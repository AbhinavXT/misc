// Opens the real MainWindow and exercises the View menu the way a user
// would: this is the check that would have caught the empty Panels submenu
// and the orphaned UTC action.
#include "mainwindow.h"
#include "settings.h"
#include <QApplication>
#include <QShortcut>
#include <QAbstractButton>
#include <QSettings>

#include "tablefindbar.h"
#include "theme.h"
#include "tabpopoutwindow.h"
#include "tabtags.h"
#include "minimizeddock.h"
#include <QDockWidget>
#include <QMenuBar>
#include <QTabWidget>
#include <QHash>
#include <functional>
#include <QMenu>
#include <QTimer>
#include <cstdio>

static QMenu* findMenu(QMenuBar *bar, const QString &title) {
    for (QAction *a : bar->actions())
        if (a->menu() && a->text().remove('&').startsWith(title)) return a->menu();
    return nullptr;
}
static QAction* findAction(QMenu *m, const QString &title) {
    for (QAction *a : m->actions())
        if (a->text().remove('&').startsWith(title)) return a;
    return nullptr;
}

int fails = 0;
#define CHECK(c,m) do{ if(!(c)){ printf("FAIL: %s\n",m); ++fails;} else printf("ok  : %s\n",m);}while(0)

int main(int argc, char **argv) {
    QApplication app(argc, argv);
    // Seed a workspace so construction takes the restore path. Saved and put
    // back afterwards: this audit borrows the real ini.
    const QStringList savedTabs   = Settings::workspaceTabs();
    const QString     savedActive = Settings::workspaceActiveTab();
    const QChar sep(0x1F);
    Settings::setWorkspaceTabs({ QStringList{ "21_1", "L1_V1", "1" }.join(sep),
                                 QStringList{ "81_1", "81_1",  "1" }.join(sep) });
    Settings::setWorkspaceActiveTab(QStringLiteral("21_1"));

    // A pop-out that was open when the console last closed: it must come
    // back by itself once its tab exists (here: restored from the workspace).
    QSettings borrowedIni(Settings::iniPath(), QSettings::IniFormat);
    const QVariant savedPopouts = borrowedIni.value(QStringLiteral("ui/popouts"));
    borrowedIni.setValue(QStringLiteral("ui/popouts"), QStringList{ QStringLiteral("21_1") });
    borrowedIni.sync();
    const TabTag savedTag = TabTags::instance()->tag(QStringLiteral("21_1"));
    TabTags::instance()->setTag(QStringLiteral("21_1"), TabTag());

    MainWindow w;
    w.show();
    for (int i = 0; i < 10; ++i) { QApplication::processEvents(); }

    QMenuBar *bar = w.menuBar();
    QMenu *view = findMenu(bar, "View");
    CHECK(view, "View menu exists");
    if (!view) return 1;

    QAction *utc = findAction(view, "Show times in UTC");
    CHECK(utc, "View > Show times in UTC is present");
    CHECK(utc && utc->isCheckable(), "and is checkable");

    QAction *panelsAct = findAction(view, "Panels");
    CHECK(panelsAct && panelsAct->menu(), "View > Panels is a submenu");

    QMenu *panels = panelsAct ? panelsAct->menu() : nullptr;
    if (panels) {
        emit panels->aboutToShow();      // what opening it does
        int toggles = 0;
        QStringList names;
        for (QAction *a : panels->actions()) {
            if (a->isSeparator()) continue;
            names << a->text().remove('&');
            if (a->isCheckable()) ++toggles;
        }
        printf("      panels: %s\n", qPrintable(names.join(" | ")));
        CHECK(toggles >= 5, "Panels lists every dock as a toggle (was empty)");
        CHECK(names.contains("Raw bytes"), "Raw bytes present");
        CHECK(names.contains("Decoded fields"), "Decoded fields present");
        CHECK(names.filter("Reset").size() == 1, "Reset panel layout present");
    }

    QAction *colsAct = findAction(view, "Columns");
    QMenu *cols = colsAct ? colsAct->menu() : nullptr;
    CHECK(cols, "View > Columns is a submenu");
    if (cols) {
        int n = 0;
        for (QAction *a : cols->actions()) if (a->isCheckable()) ++n;
        CHECK(n == 5, "five column toggles");
        // Toggling must change state and NOT be a one-shot.
        QAction *src = findAction(cols, "Source");
        if (src) {
            const bool before = src->isChecked();
            src->trigger();
            CHECK(src->isChecked() != before, "toggling a column flips it");
            src->trigger();
            CHECK(src->isChecked() == before, "and toggles back");
        }
    }

    // ---- the reorganised menus -------------------------------------------
    // Tools is six groups now, not seventeen entries. Each action still has
    // to be reachable, and it has to be in the group its name implies —
    // "Transmit" is only worth having if everything that sends is inside it.
    // ---- a saved workspace must not take the window down -------------------
    //
    // restoreWorkspace() was called thirty lines too early in the
    // constructor — before the dispatcher it asks for models — and every
    // start after a session with tabs open segfaulted. It survived testing
    // because a console that has never seen traffic saves an EMPTY
    // workspace and restores nothing, so the crash needed a real session to
    // happen first.
    //
    // This audit builds a real MainWindow, so seeding a workspace before it
    // is constructed is enough to reproduce that. Reaching this line at all
    // means the window came up.
    CHECK(!Settings::workspaceTabs().isEmpty(),
          "the window was constructed with a saved workspace in place");

    // Not just "it did not crash": the tabs have to actually come back. With
    // the call in the wrong place the guard fires and the window comes up
    // with nothing restored, which looks fine until you notice your tabs are
    // gone — so the count is what is checked.
    {
        auto *tabs = w.findChild<QTabWidget *>(QStringLiteral("tabWidget"));
        CHECK(tabs, "the tab widget is there");
        CHECK(tabs && tabs->count() == 2,
              "both saved tabs were restored");
    }

    QMenu *tools = findMenu(bar, "Tools");
    CHECK(tools, "Tools menu exists");

    auto sub = [](QMenu *m, const char *name) -> QMenu * {
        QAction *a = m ? findAction(m, QString::fromLatin1(name)) : nullptr;
        return a ? a->menu() : nullptr;
    };

    QMenu *monitor  = sub(tools, "Monitor");
    QMenu *inspect  = sub(tools, "Inspect");
    QMenu *transmit = sub(tools, "Transmit");
    QMenu *schema   = sub(tools, "Schema");
    QMenu *testcase = sub(tools, "Test cases");
    CHECK(monitor,  "Tools > Monitor");
    CHECK(inspect,  "Tools > Inspect");
    CHECK(transmit, "Tools > Transmit");
    CHECK(schema,   "Tools > Schema");
    CHECK(testcase, "Tools > Test cases");

    CHECK(monitor && findAction(monitor, "Live Loco Console"), "Monitor > Live Loco Console");

    // View > Theme: every theme, exactly one ticked, and the toggle.
    {
        QMenu *themeMenu = nullptr;
        if (view) {
            for (QAction *action : view->actions()) {
                if (action->menu() && action->text().remove(QLatin1Char('&')) == QStringLiteral("Theme")) {
                    themeMenu = action->menu();
                }
            }
        }
        CHECK(themeMenu != nullptr, "View > Theme exists");
        int themes = 0;
        int ticked = 0;
        bool hasToggle = false;
        if (themeMenu) {
            for (QAction *action : themeMenu->actions()) {
                if (action->isCheckable()) {
                    ++themes;
                    if (action->isChecked()) {
                        ++ticked;
                    }
                }
                if (action->text().remove(QLatin1Char('&')).contains(QStringLiteral("Toggle Dark/Light"))) {
                    hasToggle = true;
                }
            }
        }
        CHECK(themes == ThemeUtil::all().size(), "View > Theme lists every theme");
        CHECK(ticked == 1, "exactly one theme is ticked");
        CHECK(hasToggle, "and Toggle Dark/Light is there");
    }

    // The Live Loco Console has Find: a TableFindBar under its tabs and
    // Ctrl+F bound in the window.
    {
        QAction *console = monitor ? findAction(monitor, "Live Loco Console") : nullptr;
        if (console) {
            console->trigger();
            QWidget *window = nullptr;
            for (QWidget *top : QApplication::topLevelWidgets()) {
                if (top->windowTitle() == QStringLiteral("Live Loco Console") && top->isVisible()) {
                    window = top;
                }
            }
            CHECK(window != nullptr, "Live Loco Console opens");
            bool hasBar = false;
            bool hasCtrlF = false;
            if (window) {
                hasBar = window->findChild<TableFindBar *>() != nullptr;
                for (QShortcut *shortcut : window->findChildren<QShortcut *>()) {
                    if (shortcut->key() == QKeySequence(QKeySequence::Find)) {
                        hasCtrlF = true;
                    }
                }
                window->close();
            }
            CHECK(hasBar, "the Live Loco Console has a find bar");
            CHECK(hasCtrlF, "and Ctrl+F opens it");
        }
    }
    CHECK(monitor && findAction(monitor, "Active Fault Panel"), "Monitor > Active Fault Panel");
    CHECK(monitor && findAction(monitor, "Plot field"), "Monitor > Plot field over time");
    CHECK(monitor && findAction(monitor, "Compare tabs"), "Monitor > Compare tabs");

    CHECK(inspect && findAction(inspect, "Decode Workbench"), "Inspect > Decode Workbench");
    CHECK(inspect && findAction(inspect, "Selected row"), "Inspect > Selected row -> Workbench");
    CHECK(inspect && findAction(inspect, "Frame Diff"), "Inspect > Frame Diff");
    CHECK(inspect && findAction(inspect, "Packet Sequence"), "Inspect > Packet Sequence");

    CHECK(transmit && findAction(transmit, "Packet Maker"), "Transmit > Packet Maker");
    CHECK(transmit && findAction(transmit, "Field Sweep"), "Transmit > Field Sweep");
    CHECK(transmit && findAction(transmit, "Selected row"), "Transmit > Selected row -> Packet Maker");
    // The point of the group: nothing that sends may sit outside it.
    CHECK(!findAction(tools, "Packet Maker") && !findAction(tools, "Field Sweep"),
          "no transmitting tool is left loose in Tools");

    CHECK(schema && findAction(schema, "Reload schema"), "Schema > Reload schema");
    CHECK(schema && findAction(schema, "Use external schema"), "Schema > Use external schema file");
    CHECK(schema && findAction(schema, "Revert to built-in"), "Schema > Revert to built-in");
    CHECK(schema && findAction(schema, "Round-trip Validator"), "Schema > Round-trip Validator");

    CHECK(testcase && findAction(testcase, "Load test cases"), "Test cases > Load");
    CHECK(testcase && findAction(testcase, "Save observation report"), "Test cases > Save report");
    CHECK(testcase && findAction(testcase, "Reset run"), "Test cases > Reset run");

    CHECK(tools && findAction(tools, "Session Key"), "Tools > Session Key stays top level");

    // The Firmware Flasher: top level in Tools as the handoff asked, and on a
    // shortcut of its own. Ctrl+Shift+F (the handoff's suggestion) belongs to
    // Monitor > Active Fault Panel; the uniqueness walk below would catch a
    // clash, this pins the intended binding.
    {
        QAction *flasher = tools ? findAction(tools, "Firmware Flasher") : nullptr;
        CHECK(flasher, "Tools > Firmware Flasher is top level");
        CHECK(flasher && flasher->shortcut() == QKeySequence("Ctrl+Alt+F"),
              "Firmware Flasher is on Ctrl+Alt+F");
        CHECK(!transmit || !findAction(transmit, "Firmware Flasher"),
              "and is not duplicated inside Transmit");
        QAction *fault = monitor ? findAction(monitor, "Active Fault Panel") : nullptr;
        CHECK(fault && fault->shortcut() == QKeySequence("Ctrl+Shift+F"),
              "Active Fault Panel keeps Ctrl+Shift+F");
        if (flasher) {
            flasher->trigger();
            QWidget *opened = nullptr;
            for (QWidget *top : QApplication::topLevelWidgets()) {
                if (top->windowTitle() == QStringLiteral("Firmware Flasher") && top->isVisible()) {
                    opened = top;
                }
            }
            CHECK(opened != nullptr, "triggering it opens the Firmware Flasher window");
            flasher->trigger();
            int count = 0;
            for (QWidget *top : QApplication::topLevelWidgets()) {
                if (top->windowTitle() == QStringLiteral("Firmware Flasher")) {
                    ++count;
                }
            }
            CHECK(count == 1, "and triggering it again raises the same window, not a second one");
            if (opened) {
                opened->close();
            }
        }
    }

    // Loco Configuration: top level in Tools beside the flasher, its own
    // shortcut, and one window however often it is triggered.
    {
        QAction *loco = tools ? findAction(tools, "Loco Configuration") : nullptr;
        CHECK(loco, "Tools > Loco Configuration is top level");
        CHECK(loco && loco->shortcut() == QKeySequence("Ctrl+Alt+L"),
              "Loco Configuration is on Ctrl+Alt+L");
        CHECK(!transmit || !findAction(transmit, "Loco Configuration"),
              "and is not duplicated inside Transmit");
        if (loco) {
            loco->trigger();
            loco->trigger();
            int count = 0;
            QWidget *opened = nullptr;
            for (QWidget *top : QApplication::topLevelWidgets()) {
                if (top->windowTitle() == QStringLiteral("Loco Configuration")) {
                    ++count;
                    if (top->isVisible()) {
                        opened = top;
                    }
                }
            }
            CHECK(opened != nullptr, "triggering it opens the Loco Configuration window");
            CHECK(count == 1, "and triggering it again raises the same window");
            if (opened) {
                opened->close();
            }
        }
    }

    QMenu *file = findMenu(bar, "File");
    CHECK(file && findAction(file, "Open recorded session"), "File > Open recorded session");
    CHECK(file && findAction(file, "Stream session"),
          "File > Stream session as live (moved out of Tools)");

    QMenu *edit = findMenu(bar, "Edit");
    CHECK(edit && findAction(edit, "Search recorded sessions"),
          "Edit > Search recorded sessions");
    CHECK(edit && findAction(edit, "Copy selected rows"), "Edit > Copy selected rows");
    QMenu *bookmarks = sub(edit, "Bookmarks");
    CHECK(bookmarks, "Edit > Bookmarks is a submenu");
    CHECK(bookmarks && findAction(bookmarks, "Toggle bookmark"), "Bookmarks > Toggle");
    CHECK(bookmarks && findAction(bookmarks, "Next bookmark"), "Bookmarks > Next");
    CHECK(bookmarks && findAction(bookmarks, "Previous bookmark"), "Bookmarks > Previous");

    // ---- shortcuts are unique --------------------------------------------
    // Ctrl+Shift+R was bound to both "Reload schema" and "Stream session as
    // live". Qt answers an ambiguous shortcut by firing NEITHER and warning
    // on stderr, so both were unreachable from the keyboard and nothing
    // said so. This walks every action in the bar and fails on a repeat.
    {
        QHash<QString, QString> seen;      // shortcut -> first path that claimed it
        QStringList clashes;
        std::function<void(QMenu *, const QString &)> walk =
            [&](QMenu *m, const QString &prefix) {
                if (!m) return;
                emit m->aboutToShow();     // lazily-built submenus (Panels)
                for (QAction *a : m->actions()) {
                    if (a->isSeparator()) continue;
                    const QString label = a->text().remove('&');
                    const QString path  = prefix.isEmpty() ? label
                                                           : prefix + " > " + label;
                    if (a->menu()) { walk(a->menu(), path); continue; }
                    const QString sc = a->shortcut().toString();
                    if (sc.isEmpty()) continue;
                    if (seen.contains(sc))
                        clashes << QString("%1 on both '%2' and '%3'")
                                       .arg(sc, seen.value(sc), path);
                    else
                        seen.insert(sc, path);
                }
            };
        for (QAction *top : bar->actions())
            if (top->menu()) walk(top->menu(), top->text().remove('&'));

        for (const QString &c : clashes) printf("      clash: %s\n", qPrintable(c));
        CHECK(clashes.isEmpty(), "no shortcut is claimed by two actions");

        // ---- the pinned-fields panel ------------------------------------
        //
        // Checked here rather than in dltests because MainWindow is not in
        // that binary, and every one of these is a property of how the window
        // sets the dock up.
        {
            QDockWidget *pin = w.findChild<QDockWidget *>(
                QStringLiteral("PinnedFieldsDock"));
            CHECK(pin != nullptr, "the pinned-fields panel exists");
            if (pin) {
                CHECK(pin->isFloating(),
                      "and floats by default — a value watched while a run is "
                      "driven from the DMI must not be folded into the side of "
                      "the window whose log is being scrolled");
                CHECK(!pin->isVisible(),
                      "but is not shown unasked: an empty one is not worth a "
                      "window");
                CHECK(pin->features() & QDockWidget::DockWidgetMovable,
                      "it can still be docked, so floating is a default and "
                      "not a decision made for the operator");
                CHECK(!pin->windowTitle().isEmpty(),
                      "and carries a title, which a floating window needs and "
                      "a docked one can do without");
            }
        }

        // ---- the watches panel ------------------------------------------
        {
            QDockWidget *watch = w.findChild<QDockWidget *>(
                QStringLiteral("WatchesDock"));
            CHECK(watch != nullptr, "the watches panel exists");
            if (watch) {
                CHECK(watch->isFloating(),
                      "and floats — a watch is read while the operator is at "
                      "the DMI, not while reading the log");
                CHECK(!watch->isVisible(),
                      "and is not shown unasked; it is raised when something "
                      "fires, which is the only time it demands attention");
            }
        }
        printf("      %d distinct shortcuts bound\n", seen.size());
    }

    // ---- everything is still one flat search away -------------------------
    // Grouping only costs nothing if the palette still finds it, so this
    // counts what harvestCommands() would reach.
    {
        int leaves = 0;
        std::function<void(QMenu *)> count = [&](QMenu *m) {
            if (!m) return;
            emit m->aboutToShow();
            for (QAction *a : m->actions()) {
                if (a->isSeparator() || a->text().isEmpty()) continue;
                if (a->menu()) count(a->menu()); else ++leaves;
            }
        };
        for (QAction *top : bar->actions()) if (top->menu()) count(top->menu());
        printf("      %d commands reachable from the palette\n", leaves);
        CHECK(leaves >= 40, "the palette still reaches every command");
    }

    // ---- pop-out windows, colour tags, text size, presentation ------------------
    {
        auto popoutsOpen = [&w]() {
            QList<TabPopoutWindow *> open;
            for (TabPopoutWindow *window : w.findChildren<TabPopoutWindow *>()) {
                if (window->isVisible()) {
                    open.append(window);
                }
            }
            return open;
        };
        auto savedPopoutKeys = []() {
            QSettings ini(Settings::iniPath(), QSettings::IniFormat);
            return ini.value(QStringLiteral("ui/popouts")).toStringList();
        };

        QList<TabPopoutWindow *> open = popoutsOpen();
        CHECK(open.size() == 1 && open.first()->key() == QStringLiteral("21_1"),
              "a pop-out open at the last shutdown comes back on start");

        // Tag the tab: dot and label on the tab, and on its pop-out.
        auto *tabs = w.findChild<QTabWidget *>(QStringLiteral("tabWidget"));
        TabTags::instance()->setColor(QStringLiteral("21_1"), 1);
        TabTags::instance()->setLabel(QStringLiteral("21_1"), QStringLiteral("Brake test"));
        int tabIndex = -1;
        for (int i = 0; tabs && i < tabs->count(); ++i) {
            if (tabs->tabText(i).startsWith(QStringLiteral("L1_V1"))) {
                tabIndex = i;
            }
        }
        CHECK(tabIndex >= 0 && !tabs->tabIcon(tabIndex).isNull(), "a colour tag puts a dot on the tab");
        CHECK(tabIndex >= 0 && tabs->tabText(tabIndex) == QStringLiteral("L1_V1 · Brake test"),
              "and its label after the tab's name");
        CHECK(!open.isEmpty() && open.first()->windowTitle() == QStringLiteral("L1_V1 · Brake test"),
              "the pop-out carries the tab's own name and label");
        CHECK(!open.isEmpty() && open.first()->windowTitle().contains(QStringLiteral("Brake test"))
                  && !open.first()->windowIcon().isNull(),
              "the tag follows the loco into its pop-out window");

        // Closed by the operator: not reopened next time.
        if (!open.isEmpty()) {
            open.first()->close();
            for (int i = 0; i < 5; ++i) { QApplication::processEvents(); }
        }
        CHECK(!savedPopoutKeys().contains(QStringLiteral("21_1")), "a pop-out the operator closed is forgotten");

        // The Detach button pops the current tab out (once: again just raises it).
        if (tabs && tabIndex >= 0) {
            tabs->setCurrentIndex(tabIndex);
        }
        QAbstractButton *detach = w.findChild<QAbstractButton *>(QStringLiteral("pbDetach"));
        CHECK(detach != nullptr, "the Detach button is there");
        if (detach) {
            detach->click();
            detach->click();
            for (int i = 0; i < 5; ++i) { QApplication::processEvents(); }
        }
        CHECK(popoutsOpen().size() == 1, "Detach pops the tab out, and a second press does not open a second copy");
        CHECK(savedPopoutKeys().contains(QStringLiteral("21_1")), "an open pop-out is remembered for the next start");
        for (TabPopoutWindow *window : popoutsOpen()) {
            CHECK(MinimizedDock::isToolWindow(window), "the pop-out is a tool window (minimise chips)");
            window->close();
        }
        for (int i = 0; i < 5; ++i) { QApplication::processEvents(); }

        // View > Text size and View > Full screen / presentation.
        QMenu *zoomMenu = nullptr;
        QAction *present = nullptr;
        if (view) {
            for (QAction *action : view->actions()) {
                const QString text = action->text().remove(QLatin1Char('&'));
                if (action->menu() && text == QStringLiteral("Text size")) {
                    zoomMenu = action->menu();
                }
                if (text.startsWith(QStringLiteral("Full screen"))) {
                    present = action;
                }
            }
        }
        CHECK(zoomMenu != nullptr, "View > Text size exists");
        bool larger = false;
        bool smaller = false;
        bool resetZoom = false;
        bool appWide = true;
        if (zoomMenu) {
            for (QAction *action : zoomMenu->actions()) {
                if (action->shortcuts().contains(QKeySequence(QStringLiteral("Ctrl++")))
                    && action->shortcuts().contains(QKeySequence(QStringLiteral("Ctrl+=")))) {
                    larger = true;
                }
                if (action->shortcut() == QKeySequence(QStringLiteral("Ctrl+-"))) {
                    smaller = true;
                }
                if (action->shortcut() == QKeySequence(QStringLiteral("Ctrl+0"))) {
                    resetZoom = true;
                }
                if (!action->shortcut().isEmpty() && action->shortcutContext() != Qt::ApplicationShortcut) {
                    appWide = false;
                }
            }
        }
        CHECK(larger && smaller && resetZoom, "Larger (Ctrl++ / Ctrl+=), Smaller (Ctrl+-), Reset (Ctrl+0)");
        CHECK(appWide, "and they work from every window, not only the main one");
        CHECK(present && present->shortcut() == QKeySequence(QStringLiteral("F11"))
                  && present->shortcutContext() == Qt::ApplicationShortcut,
              "View > Full screen / presentation on F11, from any window");

        TabTags::instance()->setTag(QStringLiteral("21_1"), savedTag);
    }

        Settings::setWorkspaceTabs(savedTabs);
    Settings::setWorkspaceActiveTab(savedActive);
    {
        QSettings ini(Settings::iniPath(), QSettings::IniFormat);
        if (savedPopouts.isValid()) {
            ini.setValue(QStringLiteral("ui/popouts"), savedPopouts);
        } else {
            ini.remove(QStringLiteral("ui/popouts"));
        }
    }

    printf("\n%s\n", fails ? "MENU AUDIT FAILED" : "menu audit passed");
    return fails ? 1 : 0;
}
