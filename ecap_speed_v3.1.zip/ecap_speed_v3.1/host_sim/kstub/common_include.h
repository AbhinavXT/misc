/* host stub of Kavach globals, only to compile-check the glue */
#pragma once
#include <stdio.h>
#include <stdint.h>
#include <kernel/dpl/SystemP.h>
#define SPEED_SAMPLING_TIME 0.1
#define MPS_TO_KMPH 3.6
#define NOMINAL_DIR 1
#define REVERSE_DIR 2
#define EQEP_PRINTF printf
#define MISC_PRINTF printf
typedef struct { uint16_t tacho_output_pulse_per_rev1, tacho_output_pulse_per_rev2; uint32_t loco_wheel_dia1, loco_wheel_dia2; } LOCO_INFO;
typedef struct { int speed_sensor1_health, speed_sensor2_health; } LOCO_HEALTH;
typedef struct { double speed_sensor1_1, speed_sensor1_2, speed_sensor2_1, speed_sensor2_2; int sensor_direction; LOCO_HEALTH loco_health; } LOCO_PARAMS;
typedef struct { int is_speed_sensor_fail, is_pg1_pulse_zero, is_pg2_pulse_zero; } LMTC;
typedef struct { int is_both_speed_sensor_fail; } DLC;
extern LOCO_INFO loco_info; extern LOCO_PARAMS loco_params; extern LMTC loco_mode_transition_conditions; extern DLC data_logger_conditions;
void CalculateTrainSpeedEQEP(double p1, double p2);
