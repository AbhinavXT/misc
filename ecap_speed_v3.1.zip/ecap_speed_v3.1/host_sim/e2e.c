/*
 * Host simulation of speed_sensor_ecap.c (v2 or v3).
 *   - simulated ECAP registers (CAP1..4, flags, modulo counter, interrupt)
 *   - synthetic quadrature PG signals from a speed profile
 *   - optional glitches, edge jitter, duty cycle mismatch, blocked interrupts
 *   - main loop: Tick (v3), Service, Evaluate every window
 * Build with -DV3 for the v3 driver.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <kernel/dpl/HwiP.h>
#include <kernel/dpl/SystemP.h>
#include <drivers/ecap.h>
#include "speed_sensor_ecap.h"
#include "speed_decision.h"

/* ---------------- ECAP hardware model ---------------- */
typedef struct {
    uint32_t cap[4]; uint16_t flags; uint16_t en; uint8_t mod;
    int running; uint32_t held; uint64_t offset; int intflag;
    void (*cb)(void*); void *args; int irq_pending; uint64_t irq_time;
} HW;
static HW hw[4];
static uint64_t now;
static int cpu_masked;
static long irq_count;
static HW *H(uint32_t b){ return &hw[(b>>12)-1]; }
static uint32_t ctr(HW *h){ return h->running ? (uint32_t)(now - h->offset) : h->held; }
static void raise_irq(HW *h){ if(!h->irq_pending){ h->irq_pending=1; h->irq_time=now; } }
static void try_int(HW *h){ if(!h->intflag && (h->flags & h->en)){ h->intflag=1; raise_irq(h);} }
void HW_WR_REG32(uint32_t a, uint32_t v){ HW*h=H(a); h->held=v; if(h->running) h->offset=now-v; }
uint16_t ECAP_getInterruptSource(uint32_t b){ return H(b)->flags; }
uint32_t ECAP_getEventTimeStamp(uint32_t b, ECAP_Events e){ return H(b)->cap[e]; }
void ECAP_clearInterrupt(uint32_t b, uint16_t f){ H(b)->flags &= ~f; }
void ECAP_clearGlobalInterrupt(uint32_t b){ HW*h=H(b); h->intflag=0; try_int(h); }
uint16_t ECAP_getModuloCounterStatus(uint32_t b){ return H(b)->mod; }
uint32_t ECAP_getTimeBaseCounter(uint32_t b){ return ctr(H(b)); }
void ECAP_disableInterrupt(uint32_t b, uint16_t f){ H(b)->en &= ~f; }
void ECAP_enableInterrupt(uint32_t b, uint16_t f){ HW*h=H(b); h->en |= f; try_int(h); }
void ECAP_disableTimeStampCapture(uint32_t b){(void)b;}
void ECAP_enableTimeStampCapture(uint32_t b){(void)b;}
void ECAP_stopCounter(uint32_t b){ HW*h=H(b); h->held=ctr(h); h->running=0; }
void ECAP_startCounter(uint32_t b){ HW*h=H(b); h->offset=now-h->held; h->running=1; }
void ECAP_resetCounters(uint32_t b){ HW*h=H(b); h->mod=0; h->flags=0; }
/* input transition on ECAP k. v2: every CAP on rising edges.
 * v3: CAP1/CAP3 rising, CAP2/CAP4 falling (an edge of the wrong polarity
 * for the next CAP is ignored by the hardware). */
static void hw_transition(int k, int rising){
    HW*h=&hw[k];
#ifdef V3
    int want_rising = ((h->mod & 1U)==0U);
#else
    int want_rising = 1;
#endif
    if(rising!=want_rising) return;
    h->cap[h->mod]=ctr(h); h->flags |= (uint16_t)(2U<<h->mod); h->mod=(h->mod+1)&3; try_int(h);
}
void HwiP_Params_init(HwiP_Params*p){ memset(p,0,sizeof *p); }
int32_t HwiP_construct(HwiP_Object*o, HwiP_Params*p){ (void)o; int k=(int)p->intNum; hw[k].cb=p->callback; hw[k].args=p->args; return SystemP_SUCCESS; }
uintptr_t HwiP_disable(void){ int o=cpu_masked; cpu_masked=1; return (uintptr_t)o; }
void HwiP_restore(uintptr_t k){ cpu_masked=(int)k; }

/* ---------------- scenario ---------------- */
#define TPS 200000000.0
#define STEP 100                       /* 0.5 us */
typedef struct { double t, kmph; } Seg;
typedef struct {
    const char *name;
    Seg prof[16]; int nprof;
    double dur_s, window_s, service_ms, tick_us;
    double dA[2], dB[2], phi[2], x0[2], scale[2];
    double p_glitch_fall[4];           /* glitch pulse right after a falling edge  */
    double p_glitch_rise[4];           /* bounce right after a rising edge          */
    double jitter_us;                  /* random delay on every real edge           */
    double isr_lat_us;
    double blk_start_s[8], blk_len_ms[8]; int nblk;
    double drop_edge_s; int drop_ch;   /* drop first real rising edge after time on channel */
    int dead_ch;
    int print_from, print_to;
    uint16_t ppr; double dia;
    int quiet;
} Scen;
static double prof_at(const Scen*s,double t){ if(t<=s->prof[0].t) return s->prof[0].kmph;
    for(int i=1;i<s->nprof;i++){ if(t<=s->prof[i].t){ double a=(t-s->prof[i-1].t)/(s->prof[i].t-s->prof[i-1].t); return s->prof[i-1].kmph+a*(s->prof[i].kmph-s->prof[i-1].kmph);} }
    return s->prof[s->nprof-1].kmph; }
static int level(double x,double start,double duty){ double f=x-start; f-=floor(f); return f<duty; }

/* per-channel queue of pending hardware transitions (for jitter/glitches) */
typedef struct { uint64_t t; int rising; } Tr;
typedef struct { Tr q[16]; int n; } Q;
static Q qch[4];
static void qpush(int k,uint64_t t,int r){ Q*q=&qch[k]; if(q->n<16){ int i=q->n++; while(i>0 && q->q[i-1].t>t){ q->q[i]=q->q[i-1]; i--; } q->q[i].t=t; q->q[i].rising=r; } }
static double urand(void){ return (double)rand()/RAND_MAX; }

typedef struct { double max_err[4]; double sum_err[4]; int nwin; long irq; long ticks; long net_err; int wrong_dir_windows; } Stats;


/* signal generator: each channel has its own frequency (km/h equivalent).
 * B of a PG follows A with 25 % phase when both have the same speed. */
typedef struct { double t; double kmph[4]; } Step;     /* order RH-a RH-b LH-a LH-b */
static void e2e(const char *id, const Step *steps, int nsteps, double dur_s, double window_s)
{
    memset(hw,0,sizeof hw); now=1000; cpu_masked=0; srand(7);
    SPEED_ECAP_PG_HW_CONFIG cfg[2] = {
        {0x1000,0x2000,ECAP_INPUT_INPUTXBAR0,ECAP_INPUT_INPUTXBAR1,0,1,false},
        {0x3000,0x4000,ECAP_INPUT_INPUTXBAR2,ECAP_INPUT_INPUTXBAR3,2,3,false}};
    SpeedEcap_Init(cfg,2);
    SPEED_ECAP_PG_RESULT r[2];
    SpeedEcap_Evaluate(0,30,0.95,&r[0]); SpeedEcap_Evaluate(1,30,0.95,&r[1]);
    SPEED_DEC_CONFIG dc={3.0,5.0}; SpeedDecision_Init(&dc); SPEED_DEC_OUTPUT o;
    double x[4]={0.1,0.1-0.25,0.47,0.47-0.25}; int lv[4]; for(int k=0;k<4;k++){ double f=x[k]-floor(x[k]); lv[k]=f<0.5; }
    uint64_t end=(uint64_t)(dur_s*TPS)+1000, next_tick=1000, next_srv=1000, next_win=1000+(uint64_t)(window_s*TPS);
    double tpm=30/(M_PI*0.95); int win=0;
    int ev_fail=0, ev_sf=0, ev_undet=0, ev_slip=0, ev_sr=0; double t_fail=-1,t_sf=-1,t_slip=-1,t_sr=-1,t_undet=-1; int slip_state=0, slip_pg=0;
    uint8_t failed=0; double last_speed=0; int last_case=0; int det=1;
    for(; now<end; now+=STEP){
        double t=(now-1000)/TPS; const Step *st=&steps[0];
        for(int i=0;i<nsteps;i++) if(t>=steps[i].t) st=&steps[i];
        for(int k=0;k<4;k++){ x[k]+= st->kmph[k]/3.6*tpm*(STEP/TPS);
            double f=x[k]-floor(x[k]); int nl=f<0.5; if(nl!=lv[k]){ lv[k]=nl; hw_transition(k,nl);} }
        for(int k=0;k<4;k++) if(hw[k].irq_pending){ hw[k].irq_pending=0; hw[k].cb(hw[k].args); }
        if(now>=next_tick){ next_tick+=200000; SpeedEcap_Tick(); }
        if(now>=next_srv){ next_srv+=200000; SpeedEcap_Service(); }
        if(now>=next_win){ next_win+=(uint64_t)(window_s*TPS);
            SpeedEcap_Evaluate(0,30,0.95,&r[0]); SpeedEcap_Evaluate(1,30,0.95,&r[1]);
            SPEED_DEC_INPUT in; in.dt_s=window_s;
            in.channel_kmph[0]=r[0].channel_a.speed_mps*3.6; in.channel_kmph[1]=r[0].channel_b.speed_mps*3.6;
            in.channel_kmph[2]=r[1].channel_a.speed_mps*3.6; in.channel_kmph[3]=r[1].channel_b.speed_mps*3.6;
            for(int k=0;k<4;k++) in.channel_usable[k]=true;
            SpeedDecision_Update(&in,&o);
            if(o.new_failed_channel_mask){ ev_fail++; if(t_fail<0) t_fail=t; }
            if(o.system_failure_event){ ev_sf++; t_sf=t; }
            if(o.slip_slide_undetectable_event){ ev_undet++; if(t_undet<0) t_undet=t; }
            if(o.slip_detected_event){ ev_slip++; if(t_slip<0) t_slip=t; slip_state=o.slip_state; slip_pg=o.slipping_pg; }
            if(o.sr_request_event){ ev_sr++; if(t_sr<0) t_sr=t; }
            failed=o.failed_channel_mask; last_speed=o.train_speed_kmph; last_case=o.decision_case; det=o.slip_slide_detectable;
            win++; }
    }
    const char*cn[]={"a","b","c","c2","d"};
    printf("%-6s speed %6.2f case %-2s failed 0x%x (%d ev, first %.1fs) SF %d (%.1fs) undetectable-ev %d (%.1fs) slip-ev %d %s pg%d (%.1fs) SR-ev %d (%.1fs) detectable %d\n",
        id,last_speed,cn[last_case],failed,ev_fail,t_fail,ev_sf,t_sf,ev_undet,t_undet,ev_slip,slip_state==1?"SLIP":slip_state==2?"SLIDE":"-",slip_pg,t_slip,ev_sr,t_sr,det);
}
#define S(t,a,b,c,d) {t,{a,b,c,d}}
int main(void){
    puts("End-to-end: generator signals -> ECAP v3 (sim) -> speed_decision (timeouts 3 s / 5 s), 0.1 s windows.");
    puts("Generator starts all channels at 0, steps to the table values at 1 s. Order in S(): RH-a RH-b LH-a LH-b\n");
    { Step s1[]={S(0,0,0,0,0),S(1,80,80,80,80)}; e2e("33.1",s1,2,8,0.1); }
    { Step s[]={S(0,0,0,0,0),S(1,100,99,100,100)}; e2e("33.2",s,2,8,0.1); }
    { Step s[]={S(0,0,0,0,0),S(1,112,113,113,112)}; e2e("33.3",s,2,8,0.1); }
    { Step s[]={S(0,0,0,0,0),S(1,115,115,98,115)}; e2e("33.4",s,2,8,0.1); }
    { Step s[]={S(0,0,0,0,0),S(1,112,125,125,125)}; e2e("33.5",s,2,8,0.1); }
    { Step s[]={S(0,0,0,0,0),S(1,160,150,125,125)}; e2e("33.6",s,2,8,0.1); }
    { Step s[]={S(0,0,0,0,0),S(1,100,100,100,100)}; e2e("33.7",s,2,8,0.1); }
    { Step s[]={S(0,0,0,0,0),S(1,50,50,50,50)}; e2e("33.8",s,2,8,0.1); }
    { Step s[]={S(0,0,0,0,0),S(1,100,100,100,100),S(4,102,102,100,100)}; e2e("33.9",s,3,8,0.1); }
    { Step s[]={S(0,0,0,0,0),S(1,50,50,50,50),S(4,50,50,53,53)}; e2e("33.10",s,3,8,0.1); }
    { Step s[]={S(0,0,0,0,0),S(1,50,50,50,50),S(4,50,50,53,53)}; e2e("33.11",s,3,12,0.1); }
    { Step s[]={S(0,0,0,0,0),S(1,50,50,50,50),S(4,50,50,47,47)}; e2e("33.12",s,3,8,0.1); }
    { Step s[]={S(0,0,0,0,0),S(1,50,50,50,50),S(4,50,50,47,47)}; e2e("33.13",s,3,12,0.1); }
    { Step s[]={S(0,0,0,0,0),S(1,100,100,100,100),S(4,105,100,100,100)}; e2e("33.14",s,3,10,0.1); }
    { Step s[]={S(0,0,0,0,0),S(1,50,50,50,50),S(4,50,52,53,53)}; e2e("33.15",s,3,10,0.1); }
    { Step s[]={S(0,0,0,0,0),S(1,65,65,65,65),S(4,67,67,67,67),S(5,72,72,72,72),S(6,77,77,77,77),S(7,82,82,82,82),S(8,87,87,87,87),S(9,92,92,92,92),S(10,97,97,97,97)}; e2e("33.16",s,9,11,0.1); }
    return 0;
}
