/*
 * Host simulation of speed_sensor_ecap.c (v2 or v3).
 *   - simulated ECAP registers (CAP1..4, flags, modulo counter, interrupt)
 *   - synthetic quadrature PG signals from a speed profile
 *   - optional glitches, edge jitter, duty cycle mismatch, blocked interrupts
 *   - main loop: Tick (v3), Service, Evaluate every window
 * Build with -DV3 for the v3 driver.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <kernel/dpl/HwiP.h>
#include <kernel/dpl/SystemP.h>
#include <drivers/ecap.h>
#include "speed_sensor_ecap.h"
#include "speed_decision.h"
#include "speed_sensor_user.h"
#include "common_include.h"

/* ---------------- ECAP hardware model ---------------- */
typedef struct {
    uint32_t cap[4]; uint16_t flags; uint16_t en; uint8_t mod;
    int running; uint32_t held; uint64_t offset; int intflag;
    void (*cb)(void*); void *args; int irq_pending; uint64_t irq_time;
} HW;
static HW hw[4];
static uint64_t now;
static int cpu_masked;
static long irq_count;
static HW *H(uint32_t b){ return &hw[(b>>12)-1]; }
static uint32_t ctr(HW *h){ return h->running ? (uint32_t)(now - h->offset) : h->held; }
static void raise_irq(HW *h){ if(!h->irq_pending){ h->irq_pending=1; h->irq_time=now; } }
static void try_int(HW *h){ if(!h->intflag && (h->flags & h->en)){ h->intflag=1; raise_irq(h);} }
void HW_WR_REG32(uint32_t a, uint32_t v){ HW*h=H(a); h->held=v; if(h->running) h->offset=now-v; }
uint16_t ECAP_getInterruptSource(uint32_t b){ return H(b)->flags; }
uint32_t ECAP_getEventTimeStamp(uint32_t b, ECAP_Events e){ return H(b)->cap[e]; }
void ECAP_clearInterrupt(uint32_t b, uint16_t f){ H(b)->flags &= ~f; }
void ECAP_clearGlobalInterrupt(uint32_t b){ HW*h=H(b); h->intflag=0; try_int(h); }
uint16_t ECAP_getModuloCounterStatus(uint32_t b){ return H(b)->mod; }
uint32_t ECAP_getTimeBaseCounter(uint32_t b){ return ctr(H(b)); }
void ECAP_disableInterrupt(uint32_t b, uint16_t f){ H(b)->en &= ~f; }
void ECAP_enableInterrupt(uint32_t b, uint16_t f){ HW*h=H(b); h->en |= f; try_int(h); }
void ECAP_disableTimeStampCapture(uint32_t b){(void)b;}
void ECAP_enableTimeStampCapture(uint32_t b){(void)b;}
void ECAP_stopCounter(uint32_t b){ HW*h=H(b); h->held=ctr(h); h->running=0; }
void ECAP_startCounter(uint32_t b){ HW*h=H(b); h->offset=now-h->held; h->running=1; }
void ECAP_resetCounters(uint32_t b){ HW*h=H(b); h->mod=0; h->flags=0; }
/* input transition on ECAP k. v2: every CAP on rising edges.
 * v3: CAP1/CAP3 rising, CAP2/CAP4 falling (an edge of the wrong polarity
 * for the next CAP is ignored by the hardware). */
static void hw_transition(int k, int rising){
    HW*h=&hw[k];
#ifdef V3
    int want_rising = ((h->mod & 1U)==0U);
#else
    int want_rising = 1;
#endif
    if(rising!=want_rising) return;
    h->cap[h->mod]=ctr(h); h->flags |= (uint16_t)(2U<<h->mod); h->mod=(h->mod+1)&3; try_int(h);
}
void HwiP_Params_init(HwiP_Params*p){ memset(p,0,sizeof *p); }
int32_t HwiP_construct(HwiP_Object*o, HwiP_Params*p){ (void)o; int k=(int)p->intNum; hw[k].cb=p->callback; hw[k].args=p->args; return SystemP_SUCCESS; }
uintptr_t HwiP_disable(void){ int o=cpu_masked; cpu_masked=1; return (uintptr_t)o; }
void HwiP_restore(uintptr_t k){ cpu_masked=(int)k; }

/* ---------------- scenario ---------------- */
#define TPS 200000000.0
#define STEP 100                       /* 0.5 us */
typedef struct { double t, kmph; } Seg;
typedef struct {
    const char *name;
    Seg prof[16]; int nprof;
    double dur_s, window_s, service_ms, tick_us;
    double dA[2], dB[2], phi[2], x0[2], scale[2];
    double p_glitch_fall[4];           /* glitch pulse right after a falling edge  */
    double p_glitch_rise[4];           /* bounce right after a rising edge          */
    double jitter_us;                  /* random delay on every real edge           */
    double isr_lat_us;
    double blk_start_s[8], blk_len_ms[8]; int nblk;
    double drop_edge_s; int drop_ch;   /* drop first real rising edge after time on channel */
    int dead_ch;
    int print_from, print_to;
    uint16_t ppr; double dia;
    int quiet;
} Scen;
static double prof_at(const Scen*s,double t){ if(t<=s->prof[0].t) return s->prof[0].kmph;
    for(int i=1;i<s->nprof;i++){ if(t<=s->prof[i].t){ double a=(t-s->prof[i-1].t)/(s->prof[i].t-s->prof[i-1].t); return s->prof[i-1].kmph+a*(s->prof[i].kmph-s->prof[i-1].kmph);} }
    return s->prof[s->nprof-1].kmph; }
static int level(double x,double start,double duty){ double f=x-start; f-=floor(f); return f<duty; }

/* per-channel queue of pending hardware transitions (for jitter/glitches) */
typedef struct { uint64_t t; int rising; } Tr;
typedef struct { Tr q[16]; int n; } Q;
static Q qch[4];
static void qpush(int k,uint64_t t,int r){ Q*q=&qch[k]; if(q->n<16){ int i=q->n++; while(i>0 && q->q[i-1].t>t){ q->q[i]=q->q[i-1]; i--; } q->q[i].t=t; q->q[i].rising=r; } }
static double urand(void){ return (double)rand()/RAND_MAX; }

typedef struct { double max_err[4]; double sum_err[4]; int nwin; long irq; long ticks; long net_err; int wrong_dir_windows; } Stats;



LOCO_INFO loco_info={30,30,950,950}; LOCO_PARAMS loco_params; LMTC loco_mode_transition_conditions; DLC data_logger_conditions;
static double g_dist[2];
void CalculateTrainSpeedEQEP(double p1, double p2){ g_dist[0]+=p1; g_dist[1]+=p2; loco_mode_transition_conditions.is_speed_sensor_fail=0; }
typedef struct { double t; double kmph[4]; } Step;
static void glue_run(const char*id, const Step*steps,int n,double dur, int reverse)
{
    memset(hw,0,sizeof hw); now=1000; cpu_masked=0; g_dist[0]=g_dist[1]=0; memset(&loco_params,0,sizeof loco_params);
    printf("\n--- %s\n", id);
    SpeedSensor_Init();
    double x[4]={0.1,0.1-0.25,0.47,0.47-0.25}; int lv[4]; for(int k=0;k<4;k++){ double f=x[k]-floor(x[k]); lv[k]=f<0.5; }
    uint64_t end=(uint64_t)(dur*TPS)+1000, nt=1000, ns=1000, nw=1000+20000000ULL; double tpm=30/(M_PI*0.95); int win=0;
    for(; now<end; now+=STEP){
        double t=(now-1000)/TPS; const Step*st=&steps[0]; for(int i=0;i<n;i++) if(t>=steps[i].t) st=&steps[i];
        for(int k=0;k<4;k++){ x[k]+= (reverse?-1:1)*st->kmph[k]/3.6*tpm*(STEP/TPS); double f=x[k]-floor(x[k]); int nl=f<0.5; if(nl!=lv[k]){ lv[k]=nl; hw_transition(k,nl);} }
        for(int k=0;k<4;k++) if(hw[k].irq_pending){ hw[k].irq_pending=0; hw[k].cb(hw[k].args); }
        if(now>=nt){ nt+=200000; SpeedSensor_Tick(); }
        if(now>=ns){ ns+=200000; SpeedSensor_Service(); }
        if(now>=nw){ nw+=20000000ULL; CalculateWheelSpeed_ECAP(); win++;
            if(win%10==0) printf("  t=%.1f speed %.2f dir %d health %d/%d SF %d pulse0 %d/%d dist %.0f/%.0f\n", t, SpeedSensor_GetTrainSpeedKmph(), loco_params.sensor_direction,
               loco_params.loco_health.speed_sensor1_health, loco_params.loco_health.speed_sensor2_health, loco_mode_transition_conditions.is_speed_sensor_fail,
               loco_mode_transition_conditions.is_pg1_pulse_zero, loco_mode_transition_conditions.is_pg2_pulse_zero, g_dist[0], g_dist[1]); }
    }
}
#define S(t,a,b,c,d) {t,{a,b,c,d}}
int main(void){
    { Step s[]={S(0,0,0,0,0),S(1,115,115,98,115)}; glue_run("33.4 through the glue",s,2,6,0); }
    { Step s[]={S(0,0,0,0,0),S(1,30,30,30,30)}; glue_run("reverse 30 km/h through the glue",s,2,3,1); }
    return 0; }
