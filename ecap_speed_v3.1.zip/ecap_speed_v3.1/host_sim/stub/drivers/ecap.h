#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
typedef enum { ECAP_EVENT_1=0, ECAP_EVENT_2, ECAP_EVENT_3, ECAP_EVENT_4 } ECAP_Events;
typedef enum { ECAP_INPUT_INPUTXBAR0=0, ECAP_INPUT_INPUTXBAR1, ECAP_INPUT_INPUTXBAR2, ECAP_INPUT_INPUTXBAR3 } ECAP_InputCaptureSignals;
#define ECAP_ISR_SOURCE_CAPTURE_EVENT_1 (0x2U)
#define ECAP_ISR_SOURCE_CAPTURE_EVENT_2 (0x4U)
#define ECAP_ISR_SOURCE_CAPTURE_EVENT_3 (0x8U)
#define ECAP_ISR_SOURCE_CAPTURE_EVENT_4 (0x10U)
#define ECAP_ISR_SOURCE_COUNTER_OVERFLOW (0x20U)
#define ECAP_ISR_SOURCE_COUNTER_PERIOD (0x40U)
#define ECAP_ISR_SOURCE_COUNTER_COMPARE (0x80U)
#define ECAP_CONTINUOUS_CAPTURE_MODE 0
#define ECAP_EVNT_RISING_EDGE 0
#define ECAP_EVNT_FALLING_EDGE 1
#define ECAP_PULSE_WIDTH_FILTER_CYCLE15 15
#define ECAP_SYNC_IN_PULSE_SRC_DISABLE 0
#define ECAP_SYNC_OUT_DISABLED 0
#define ECAP_EMULATION_FREE_RUN 0
#define CSL_ECAP_TSCTR 0
void HW_WR_REG32(uint32_t addr, uint32_t v);
uint16_t ECAP_getInterruptSource(uint32_t b);
uint32_t ECAP_getEventTimeStamp(uint32_t b, ECAP_Events e);
void ECAP_clearInterrupt(uint32_t b, uint16_t f);
void ECAP_clearGlobalInterrupt(uint32_t b);
uint16_t ECAP_getModuloCounterStatus(uint32_t b);
uint32_t ECAP_getTimeBaseCounter(uint32_t b);
void ECAP_disableInterrupt(uint32_t b, uint16_t f);
void ECAP_enableInterrupt(uint32_t b, uint16_t f);
void ECAP_disableTimeStampCapture(uint32_t b);
void ECAP_enableTimeStampCapture(uint32_t b);
void ECAP_stopCounter(uint32_t b);
void ECAP_startCounter(uint32_t b);
void ECAP_resetCounters(uint32_t b);
static inline void ECAP_enableCaptureMode(uint32_t b){(void)b;}
static inline void ECAP_setCaptureMode(uint32_t b,int m,ECAP_Events e){(void)b;(void)m;(void)e;}
static inline void ECAP_setEventPrescaler(uint32_t b,int p){(void)b;(void)p;}
static inline void ECAP_setEventPolarity(uint32_t b,ECAP_Events e,int p){(void)b;(void)e;(void)p;}
static inline void ECAP_disableCounterResetOnEvent(uint32_t b,ECAP_Events e){(void)b;(void)e;}
static inline void ECAP_selectECAPInput(uint32_t b,ECAP_InputCaptureSignals s){(void)b;(void)s;}
static inline void ECAP_selectQualPeriod(uint32_t b,int q){(void)b;(void)q;}
static inline void ECAP_setPhaseShiftCount(uint32_t b,uint32_t c){(void)b;(void)c;}
static inline void ECAP_disableLoadCounter(uint32_t b){(void)b;}
static inline void ECAP_setSyncInPulseSource(uint32_t b,int s){(void)b;(void)s;}
static inline void ECAP_setSyncOutMode(uint32_t b,int s){(void)b;(void)s;}
static inline void ECAP_setEmulationMode(uint32_t b,int s){(void)b;(void)s;}
