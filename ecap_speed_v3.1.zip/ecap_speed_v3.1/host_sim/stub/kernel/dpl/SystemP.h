#pragma once
#define SystemP_SUCCESS ((int32_t)0)
#define SystemP_FAILURE ((int32_t)-1)
