#pragma once
#include <stdint.h>
typedef struct { int dummy; } HwiP_Object;
typedef struct { uint32_t intNum; void (*callback)(void*); void *args; uint8_t isPulse; uint8_t priority; } HwiP_Params;
void HwiP_Params_init(HwiP_Params *p);
int32_t HwiP_construct(HwiP_Object *o, HwiP_Params *p);
uintptr_t HwiP_disable(void);
void HwiP_restore(uintptr_t k);
