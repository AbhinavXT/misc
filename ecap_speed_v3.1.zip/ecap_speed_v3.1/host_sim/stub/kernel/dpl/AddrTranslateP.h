#pragma once
#include <stdint.h>
static inline void *AddrTranslateP_getLocalAddr(uint64_t a){ return (void*)(uintptr_t)a; }
