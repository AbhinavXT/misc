/*
 * Host simulation of speed_sensor_ecap.c (v2 or v3).
 *   - simulated ECAP registers (CAP1..4, flags, modulo counter, interrupt)
 *   - synthetic quadrature PG signals from a speed profile
 *   - optional glitches, edge jitter, duty cycle mismatch, blocked interrupts
 *   - main loop: Tick (v3), Service, Evaluate every window
 * Build with -DV3 for the v3 driver.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <kernel/dpl/HwiP.h>
#include <kernel/dpl/SystemP.h>
#include <drivers/ecap.h>
#include "speed_sensor_ecap.h"

/* ---------------- ECAP hardware model ---------------- */
typedef struct {
    uint32_t cap[4]; uint16_t flags; uint16_t en; uint8_t mod;
    int running; uint32_t held; uint64_t offset; int intflag;
    void (*cb)(void*); void *args; int irq_pending; uint64_t irq_time;
} HW;
static HW hw[4];
static uint64_t now;
static int cpu_masked;
static long irq_count;
static HW *H(uint32_t b){ return &hw[(b>>12)-1]; }
static uint32_t ctr(HW *h){ return h->running ? (uint32_t)(now - h->offset) : h->held; }
static void raise_irq(HW *h){ if(!h->irq_pending){ h->irq_pending=1; h->irq_time=now; } }
static void try_int(HW *h){ if(!h->intflag && (h->flags & h->en)){ h->intflag=1; raise_irq(h);} }
void HW_WR_REG32(uint32_t a, uint32_t v){ HW*h=H(a); h->held=v; if(h->running) h->offset=now-v; }
uint16_t ECAP_getInterruptSource(uint32_t b){ return H(b)->flags; }
uint32_t ECAP_getEventTimeStamp(uint32_t b, ECAP_Events e){ return H(b)->cap[e]; }
void ECAP_clearInterrupt(uint32_t b, uint16_t f){ H(b)->flags &= ~f; }
void ECAP_clearGlobalInterrupt(uint32_t b){ HW*h=H(b); h->intflag=0; try_int(h); }
uint16_t ECAP_getModuloCounterStatus(uint32_t b){ return H(b)->mod; }
uint32_t ECAP_getTimeBaseCounter(uint32_t b){ return ctr(H(b)); }
void ECAP_disableInterrupt(uint32_t b, uint16_t f){ H(b)->en &= ~f; }
void ECAP_enableInterrupt(uint32_t b, uint16_t f){ HW*h=H(b); h->en |= f; try_int(h); }
void ECAP_disableTimeStampCapture(uint32_t b){(void)b;}
void ECAP_enableTimeStampCapture(uint32_t b){(void)b;}
void ECAP_stopCounter(uint32_t b){ HW*h=H(b); h->held=ctr(h); h->running=0; }
void ECAP_startCounter(uint32_t b){ HW*h=H(b); h->offset=now-h->held; h->running=1; }
void ECAP_resetCounters(uint32_t b){ HW*h=H(b); h->mod=0; h->flags=0; }
/* input transition on ECAP k. v2: every CAP on rising edges.
 * v3: CAP1/CAP3 rising, CAP2/CAP4 falling (an edge of the wrong polarity
 * for the next CAP is ignored by the hardware). */
static void hw_transition(int k, int rising){
    HW*h=&hw[k];
#ifdef V3
    int want_rising = ((h->mod & 1U)==0U);
#else
    int want_rising = 1;
#endif
    if(rising!=want_rising) return;
    h->cap[h->mod]=ctr(h); h->flags |= (uint16_t)(2U<<h->mod); h->mod=(h->mod+1)&3; try_int(h);
}
void HwiP_Params_init(HwiP_Params*p){ memset(p,0,sizeof *p); }
int32_t HwiP_construct(HwiP_Object*o, HwiP_Params*p){ (void)o; int k=(int)p->intNum; hw[k].cb=p->callback; hw[k].args=p->args; return SystemP_SUCCESS; }
uintptr_t HwiP_disable(void){ int o=cpu_masked; cpu_masked=1; return (uintptr_t)o; }
void HwiP_restore(uintptr_t k){ cpu_masked=(int)k; }

/* ---------------- scenario ---------------- */
#define TPS 200000000.0
#define STEP 100                       /* 0.5 us */
typedef struct { double t, kmph; } Seg;
typedef struct {
    const char *name;
    Seg prof[16]; int nprof;
    double dur_s, window_s, service_ms, tick_us;
    double dA[2], dB[2], phi[2], x0[2], scale[2];
    double p_glitch_fall[4];           /* glitch pulse right after a falling edge  */
    double p_glitch_rise[4];           /* bounce right after a rising edge          */
    double jitter_us;                  /* random delay on every real edge           */
    double isr_lat_us;
    double blk_start_s[8], blk_len_ms[8]; int nblk;
    double drop_edge_s; int drop_ch;   /* drop first real rising edge after time on channel */
    int dead_ch;
    int print_from, print_to;
    uint16_t ppr; double dia;
    int quiet;
} Scen;
static double prof_at(const Scen*s,double t){ if(t<=s->prof[0].t) return s->prof[0].kmph;
    for(int i=1;i<s->nprof;i++){ if(t<=s->prof[i].t){ double a=(t-s->prof[i-1].t)/(s->prof[i].t-s->prof[i-1].t); return s->prof[i-1].kmph+a*(s->prof[i].kmph-s->prof[i-1].kmph);} }
    return s->prof[s->nprof-1].kmph; }
static int level(double x,double start,double duty){ double f=x-start; f-=floor(f); return f<duty; }

/* per-channel queue of pending hardware transitions (for jitter/glitches) */
typedef struct { uint64_t t; int rising; } Tr;
typedef struct { Tr q[16]; int n; } Q;
static Q qch[4];
static int g_capture; static double g_err[16]; static long g_gl;
static void qpush(int k,uint64_t t,int r){ Q*q=&qch[k]; if(q->n<16){ int i=q->n++; while(i>0 && q->q[i-1].t>t){ q->q[i]=q->q[i-1]; i--; } q->q[i].t=t; q->q[i].rising=r; } }
static double urand(void){ return (double)rand()/RAND_MAX; }

typedef struct { double max_err[4]; double sum_err[4]; int nwin; long irq; long ticks; long net_err; int wrong_dir_windows; } Stats;

static Stats run(const Scen *s)
{
    Stats st; memset(&st,0,sizeof st);
    memset(hw,0,sizeof hw); memset(qch,0,sizeof qch); now=1000; cpu_masked=0; irq_count=0; srand(12345);
    SPEED_ECAP_PG_HW_CONFIG cfg[2] = {
        {0x1000,0x2000,ECAP_INPUT_INPUTXBAR0,ECAP_INPUT_INPUTXBAR1,0,1,false},
        {0x3000,0x4000,ECAP_INPUT_INPUTXBAR2,ECAP_INPUT_INPUTXBAR3,2,3,false}};
    if(SpeedEcap_Init(cfg,2)!=SystemP_SUCCESS){ puts("init fail"); return st; }
    SPEED_ECAP_PG_RESULT r[2];
    SpeedEcap_Evaluate(0,s->ppr,s->dia,&r[0]); SpeedEcap_Evaluate(1,s->ppr,s->dia,&r[1]);

    double x[2]={s->x0[0],s->x0[1]}; int lv[4];
    for(int p=0;p<2;p++){ lv[2*p]=level(x[p],0,s->dA[p]); lv[2*p+1]=level(x[p],s->phi[p],s->dB[p]); }
    uint64_t end=(uint64_t)(s->dur_s*TPS)+1000, next_srv=1000, next_tick=1000, next_win=1000+(uint64_t)(s->window_s*TPS);
    int win=0, dropped=0; long real_rises[4]={0}; double pos_real[2]={0}, pos_rep[2]={0};
    double tpm = s->ppr/(M_PI*s->dia);
    double last_change_t=-10; double prev_v=prof_at(s,0);
    if(!s->quiet){ printf("\n=== %s ===\n",s->name);
#ifdef V3
    printf(" win  t(s) | PG1 A kmph  B kmph  pA  pB  net dir QE QR GL OV | PG2 A kmph  B kmph  pA  pB  net dir QE QR GL OV | true kmph\n");
#else
    printf(" win  t(s) | PG1 A kmph  B kmph  pA  pB  net dir PH GL SP OV | PG2 A kmph  B kmph  pA  pB  net dir PH GL SP OV | true kmph\n");
#endif
    }
    double win_start_pos[2]={x[0],x[1]};
    for(; now<end; now+=STEP){
        double t=(now-1000)/TPS;
        double v=prof_at(s,t);
        if(fabs(v-prev_v)>1e-9) last_change_t=t; prev_v=v;
        for(int p=0;p<2;p++){
            x[p]+= v/3.6*s->scale[p]*tpm*(STEP/TPS);
            int nl[2]={ level(x[p],0,s->dA[p]), level(x[p],s->phi[p],s->dB[p]) };
            for(int c=0;c<2;c++){ int k=2*p+c;
                if(nl[c]!=lv[k]){
                    lv[k]=nl[c];
                    if(k==s->dead_ch) continue;
                    if(nl[c]) real_rises[k]++;
                    if(nl[c] && s->drop_edge_s>0 && !dropped && k==s->drop_ch && t>=s->drop_edge_s){ dropped=1; /* drop this rising and its falling */ continue; }
                    uint64_t d = s->jitter_us>0 ? (uint64_t)(urand()*s->jitter_us*200) : 0;
                    qpush(k, now+d, nl[c]);
                    if(!nl[c] && urand()<s->p_glitch_fall[k]){ qpush(k, now+d+200, 1); qpush(k, now+d+600, 0); }
                    if( nl[c] && urand()<s->p_glitch_rise[k]){ qpush(k, now+d+200, 0); qpush(k, now+d+600, 1); }
                } } }
        /* deliver hardware transitions (skip falling edge of a dropped pulse: level tracking handles it) */
        for(int k=0;k<4;k++){ Q*q=&qch[k]; while(q->n>0 && q->q[0].t<=now){ hw_transition(k,q->q[0].rising); memmove(&q->q[0],&q->q[1],sizeof(Tr)*(q->n-1)); q->n--; } }
        int blocked=cpu_masked;
        for(int i=0;i<s->nblk;i++){ double b0=s->blk_start_s[i], b1=b0+s->blk_len_ms[i]/1000.0; if(t>=b0&&t<b1) blocked=1; }
        if(!blocked) for(int k=0;k<4;k++) if(hw[k].irq_pending && now>=hw[k].irq_time+(uint64_t)(s->isr_lat_us*200)){ hw[k].irq_pending=0; irq_count++; hw[k].cb(hw[k].args); }
#ifdef V3
        if(now>=next_tick){ if(!blocked){ next_tick+=(uint64_t)(s->tick_us*200); SpeedEcap_Tick(); st.ticks++; } }
#endif
        if(now>=next_srv){ if(!blocked){ next_srv+=(uint64_t)(s->service_ms*200000); SpeedEcap_Service(); } }
        if(now>=next_win){ next_win+=(uint64_t)(s->window_s*TPS);
            SpeedEcap_Evaluate(0,s->ppr,s->dia,&r[0]); SpeedEcap_Evaluate(1,s->ppr,s->dia,&r[1]);
            /* accuracy stats: only when speed constant for > 0.3 s and moving */
            if(t-last_change_t>0.3+s->window_s && fabs(v)>0.5 && win>=2){
                double sp[4]={r[0].channel_a.speed_mps*3.6,r[0].channel_b.speed_mps*3.6,r[1].channel_a.speed_mps*3.6,r[1].channel_b.speed_mps*3.6};
                for(int k=0;k<4;k++){ double tv=fabs(v)*s->scale[k/2]; double e=fabs(sp[k]-tv); if(e>st.max_err[k]) st.max_err[k]=e; st.sum_err[k]+=e; }
                st.nwin++;
                for(int p=0;p<2;p++){ int want = v>0?1:-1; if(r[p].direction!=want) st.wrong_dir_windows++; }
            }
            if(g_capture && win<16){ double sp4[4]={r[0].channel_a.speed_mps*3.6,r[0].channel_b.speed_mps*3.6,r[1].channel_a.speed_mps*3.6,r[1].channel_b.speed_mps*3.6};
                for(int k=0;k<4;k++){ double e=fabs(sp4[k]-fabs(v)); if(e>g_err[win]) g_err[win]=e; }
                g_gl += r[0].channel_a.glitches_in_window+r[0].channel_b.glitches_in_window+r[1].channel_a.glitches_in_window+r[1].channel_b.glitches_in_window; }
            for(int p=0;p<2;p++){ double moved=(x[p]-win_start_pos[p]); pos_real[p]+=moved; win_start_pos[p]=x[p];
                pos_rep[p]+= (double)r[p].net_pulses_in_window * (r[p].net_direction_in_window<0?-1:1); }
            if(!s->quiet && (s->print_from<0 || (win>=s->print_from && win<=s->print_to))){
                printf("%4d %5.2f |",win,t);
                for(int p=0;p<2;p++){ SPEED_ECAP_PG_RESULT*q=&r[p];
#ifdef V3
                    printf(" %8.2f %8.2f %3u %3u %4d %2d %2u %2u %2u %2u |", q->channel_a.speed_mps*3.6,q->channel_b.speed_mps*3.6,
                      q->channel_a.pulses_in_window,q->channel_b.pulses_in_window,(int)q->net_pulses_in_window*(q->net_direction_in_window<0?-1:1),
                      q->direction, q->quad_errors_in_window, q->quad_reversals_in_window,
                      q->channel_a.glitches_in_window+q->channel_b.glitches_in_window,
                      q->channel_a.overruns_in_window+q->channel_b.overruns_in_window);
#else
                    printf(" %8.2f %8.2f %3u %3u %4d %2d %2u %2u %2u %2u |", q->channel_a.speed_mps*3.6,q->channel_b.speed_mps*3.6,
                      q->channel_a.pulses_in_window,q->channel_b.pulses_in_window,(int)q->net_pulses_in_window*(q->net_direction_in_window<0?-1:1),
                      q->direction, q->phase_errors_in_window,
                      q->channel_a.glitches_in_window+q->channel_b.glitches_in_window,
                      q->channel_a.spurious_in_window+q->channel_b.spurious_in_window,
                      q->channel_a.overruns_in_window+q->channel_b.overruns_in_window);
#endif
                }
                printf(" %7.2f real %ld/%ld/%ld/%ld\n",v,real_rises[0],real_rises[1],real_rises[2],real_rises[3]);
            }
            memset(real_rises,0,sizeof real_rises); win++; }
    }
    st.irq=irq_count;
    st.net_err = lround(fabs(pos_rep[0]-pos_real[0])) > lround(fabs(pos_rep[1]-pos_real[1])) ? lround(pos_rep[0]-pos_real[0]) : lround(pos_rep[1]-pos_real[1]);
    if(!s->quiet){
        printf("  summary: ECAP interrupts %ld (%.0f/s), ticks %ld | max |speed error| A1 %.3f B1 %.3f A2 %.3f B2 %.3f km/h over %d steady windows | wrong-direction windows %d | distance error PG1 %+.1f PG2 %+.1f pulses\n",
            st.irq, st.irq/s->dur_s, st.ticks, st.max_err[0],st.max_err[1],st.max_err[2],st.max_err[3], st.nwin, st.wrong_dir_windows,
            pos_rep[0]-pos_real[0], pos_rep[1]-pos_real[1]);
    }
    return st;
}

static Scen base(const char*n){ Scen s; memset(&s,0,sizeof s); s.name=n; s.window_s=1.0; s.service_ms=1.0; s.tick_us=1000;
    for(int p=0;p<2;p++){ s.dA[p]=0.5; s.dB[p]=0.5; s.phi[p]=0.25; s.scale[p]=1.0; s.x0[p]=0.1+0.37*p; }
    s.isr_lat_us=2; s.dead_ch=-1; s.print_from=-1; s.drop_edge_s=-1; s.ppr=30; s.dia=0.95; return s; }
#define CONST(sc,v) do{ (sc).prof[0]=(Seg){0,(v)}; (sc).nprof=1; }while(0)

int main(int argc,char**argv){
    int w = argc>1 ? atoi(argv[1]) : 0;
    Scen s;
    if(w==0||w==1){ s=base("1. clean forward 100 km/h, 1 s windows"); CONST(s,100); s.dur_s=5; run(&s); }
    if(w==0||w==2){ s=base("2. 100 km/h, glitch after 5% of falling edges + 5% bounce after rising edges, 2 us jitter"); CONST(s,100); s.dur_s=5; s.jitter_us=2;
        for(int k=0;k<4;k++){ s.p_glitch_fall[k]=0.05; s.p_glitch_rise[k]=0.05; } run(&s); }
    if(w==0||w==3){ double d[][2]={{0.50,0.50},{0.55,0.45},{0.60,0.40},{0.65,0.35}};
        for(int i=0;i<4;i++){ char *nm=malloc(128); snprintf(nm,128,"3. REVERSE 30 km/h, PG1 phase 20%%, duty A %.0f%% / B %.0f%%",d[i][0]*100,d[i][1]*100);
            s=base(nm); CONST(s,-30); s.dur_s=4; s.phi[0]=0.20; s.dA[0]=d[i][0]; s.dB[0]=d[i][1]; s.print_from=1; s.print_to=3; run(&s); } }
    if(w==0||w==4){ s=base("4. 100 km/h, ONE real PG1-A pulse missing at 2.5 s, 10 ms windows"); CONST(s,100); s.dur_s=2.7; s.drop_edge_s=2.5; s.drop_ch=0; s.window_s=0.01; s.print_from=248; s.print_to=258; run(&s); }
    if(w==0||w==5){ s=base("5. wheel spin at start: 0 -> 20 km/h in 0.5 s, 0.1 s windows"); s.prof[0]=(Seg){0,0}; s.prof[1]=(Seg){1.0,0}; s.prof[2]=(Seg){1.5,20}; s.prof[3]=(Seg){3,20}; s.nprof=4; s.dur_s=2.2; s.window_s=0.1; s.x0[1]=0.62; s.print_from=10; s.print_to=18; run(&s); }
    if(w==0||w==6){ s=base("6. step 50 -> 100 km/h at 2.0 s, 0.1 s windows"); s.prof[0]=(Seg){0,50}; s.prof[1]=(Seg){2.0,50}; s.prof[2]=(Seg){2.001,100}; s.nprof=3; s.dur_s=2.6; s.window_s=0.1; s.print_from=18; s.print_to=23; run(&s); }
    if(w==0||w==7){ s=base("7. stop from 15 km/h, roll back at 2 km/h, 0.1 s windows"); s.prof[0]=(Seg){0,15}; s.prof[1]=(Seg){1.0,15}; s.prof[2]=(Seg){1.5,0}; s.prof[3]=(Seg){3.0,0}; s.prof[4]=(Seg){3.3,-2}; s.prof[5]=(Seg){6,-2}; s.nprof=6; s.dur_s=5; s.window_s=0.1; s.x0[1]=0.8; s.print_from=9; s.print_to=45; run(&s); }
    if(w==0||w==8){ puts("\n=== 8. sweep: ALL interrupts, tick and main loop blocked L ms at 2.5 s, 250 km/h ===");
        puts("   L(ms) | per channel: real-pulses / reported / overrun-flag | distance error PG1 PG2 (pulses)");
        for(double L=1; L<=30; L+=1.5){ s=base("sweep"); CONST(s,250); s.dur_s=4; s.nblk=1; s.blk_start_s[0]=2.5; s.blk_len_ms[0]=L; s.quiet=1; s.print_from=-2;
            /* capture window 2 via print: rerun printing only window 2 */
            s.quiet=0; s.print_from=2; s.print_to=2; char nm[64]; snprintf(nm,64,"   block %.1f ms",L); s.name=nm; run(&s); } }
    if(w==0||w==9){ s=base("9. 100 km/h 0.1 s windows, RH wheel 1.5% bigger (wear), glitches+jitter"); CONST(s,100); s.dur_s=4; s.window_s=0.1; s.scale[0]=1.015; s.jitter_us=2;
        for(int k=0;k<4;k++){ s.p_glitch_fall[k]=0.05; } s.print_from=20; s.print_to=24; run(&s); }
    if(w==0||w==10){ s=base("10. 120 PPR, 250 km/h, 1 ms tick (tick too slow -> ECAP IRQ auto on)"); CONST(s,250); s.ppr=120; s.dur_s=3; run(&s);
        s=base("10b. 30 PPR, 250 km/h, 1 ms tick (no ECAP IRQ)"); CONST(s,250); s.dur_s=3; run(&s); }
    if(w==0||w==12){ s=base("12. 15 km/h, stop for 25 s (longer than the 21.5 s counter wrap), restart at 15 km/h, 1 s windows");
        s.prof[0]=(Seg){0,15}; s.prof[1]=(Seg){3,15}; s.prof[2]=(Seg){3.5,0}; s.prof[3]=(Seg){28.5,0}; s.prof[4]=(Seg){28.6,15}; s.prof[5]=(Seg){40,15}; s.nprof=6; s.dur_s=33; s.x0[0]=0.3; s.print_from=26; s.print_to=32; run(&s); }
    if(w==20||w==21||w==22){ double from = (w==20)?1.0:(w==21)?3.0:0.0; char *nm=malloc(96); snprintf(nm,96,"20. step %.0f -> 250 km/h at 6 s, 1 s windows",from);
        s=base(nm); s.prof[0]=(Seg){0,from}; s.prof[1]=(Seg){6.0,from}; s.prof[2]=(Seg){6.001,250}; s.prof[3]=(Seg){20,250}; s.nprof=4; s.dur_s=12; s.x0[1]=0.62; s.print_from=4; s.print_to=11; run(&s); }
    if(w==24){ s=base("24. constant 250 km/h, glitches on 3% of falling edges, 2 us jitter"); CONST(s,250); s.dur_s=6; s.jitter_us=2; for(int k=0;k<4;k++) s.p_glitch_fall[k]=0.03; run(&s); }
    if(w==25){ s=base("25. 2 -> 250 with glitches (detail)"); s.prof[0]=(Seg){0,2}; s.prof[1]=(Seg){6.0,2}; s.prof[2]=(Seg){6.001,250}; s.prof[3]=(Seg){20,250}; s.nprof=4; s.dur_s=10; s.x0[1]=0.62; s.jitter_us=2;
            for(int k=0;k<4;k++) s.p_glitch_fall[k]=0.03; s.print_from=4; s.print_to=9; run(&s); }
    if(w==23){ double sp[]={0,0.3,0.5,1,1.5,2,2.5,3,4,5,8,10,15,20,30,50,80,100,150,200,250};
        puts("\n=== 23. step sweep (both directions), 1 s windows, glitches on 3% of falling edges, 2 us jitter ===");
        puts("  from -> to   | windows after the step: worst |speed error| of 4 channels (window+1, +2, +3) | GL total | NET error");
        for(int dirn=0; dirn<2; dirn++) for(unsigned i=0;i<sizeof sp/sizeof sp[0];i++){
            double a = dirn? 250: sp[i], b = dirn? sp[i]: 250; if(a==b) continue;
            s=base("sweep"); s.prof[0]=(Seg){0,a}; s.prof[1]=(Seg){6.0,a}; s.prof[2]=(Seg){6.001,b}; s.prof[3]=(Seg){20,b}; s.nprof=4; s.dur_s=10; s.x0[1]=0.62; s.jitter_us=2;
            for(int k=0;k<4;k++) s.p_glitch_fall[k]=0.03;
            s.quiet=1; g_capture=1; memset(g_err,0,sizeof g_err); g_gl=0; Stats st=run(&s); g_capture=0;
            printf("  %5.1f -> %5.1f | %8.3f %8.3f %8.3f | %6ld | %+ld\n", a,b,g_err[7],g_err[8],g_err[9],g_gl, st.net_err); } }
    if(w==0||w==11){ s=base("11. dead channel PG2-B at 80 km/h"); CONST(s,80); s.dead_ch=3; s.dur_s=4; run(&s); }
    return 0;
}
