/*
 * speed_sensor_ecap.c   (v3.1)
 *
 * ECAP based speed, direction and pulse counting for two quadrature PGs.
 * Full explanation: ECAP_Speed_Code_Explained_updated.md.
 *
 * -----------------------------------------------------------------------
 * DATA FLOW
 * -----------------------------------------------------------------------
 *   ECAP hardware        every rising AND falling edge -> CAP1..CAP4
 *                        (CAP1/CAP3 rising, CAP2/CAP4 falling)
 *        |
 *   SpeedEcap_Tick()     periodic (1 ms): copy flagged CAPs into a ring,
 *   [or ECAP ISR]        oldest first, detect lost events. Register reads
 *                        only, no maths.
 *        |
 *   SpeedEcap_Service()  main loop: take A and B events in time order and
 *                        feed each one to
 *                          - the quadrature decoder (position, direction)
 *                          - the channel's speed chain (glitch filter,
 *                            accepted rising edges, period)
 *        |
 *   SpeedEcap_Evaluate() once per window: M/T frequency, speed, net
 *                        pulses, quality counters.
 *
 * REQUIREMENTS
 *   - SpeedEcap_Tick() every SPEED_ECAP_TICK_PERIOD_US.
 *   - SpeedEcap_Service() and SpeedEcap_Evaluate() from the SAME task.
 *   - If ECAP interrupts are used, all four at the same (high) priority.
 */

#include <string.h>
#include <kernel/dpl/HwiP.h>
#include <kernel/dpl/SystemP.h>
#include <kernel/dpl/AddrTranslateP.h>
#include <drivers/ecap.h>
#include "speed_sensor_ecap.h"

#if (SPEED_ECAP_PROFILE == 1U)
#include <kernel/dpl/CycleCounterP.h>
#endif

/* ==========================================================================
 * PRIVATE DEFINES
 * ========================================================================== */

#define SPEED_ECAP_PI                   (3.14159265358979323846)
#define SPEED_ECAP_MPS_TO_KMPH          (3.6)

#define SPEED_ECAP_NUM_EVENTS           (4U)

#define SPEED_ECAP_CAPTURE_FLAGS        (ECAP_ISR_SOURCE_CAPTURE_EVENT_1 | \
                                         ECAP_ISR_SOURCE_CAPTURE_EVENT_2 | \
                                         ECAP_ISR_SOURCE_CAPTURE_EVENT_3 | \
                                         ECAP_ISR_SOURCE_CAPTURE_EVENT_4)

#define SPEED_ECAP_BASIC_FLAGS          (SPEED_ECAP_CAPTURE_FLAGS          | \
                                         ECAP_ISR_SOURCE_COUNTER_OVERFLOW  | \
                                         ECAP_ISR_SOURCE_COUNTER_PERIOD    | \
                                         ECAP_ISR_SOURCE_COUNTER_COMPARE)

/* Only used when the tick is too slow (high PPR). CEVT4 on both channels
 * of a PG: each channel interrupts every 4 events (2 pulse periods) and
 * every interrupt empties both channels, so a PG gets about one interrupt
 * per pulse period. Latency budget of one channel on its own: 0.5 period. */
#define SPEED_ECAP_IRQ_EVENT_MASK       (ECAP_ISR_SOURCE_CAPTURE_EVENT_4)

#define SPEED_ECAP_TICKS_PER_MS         (SPEED_ECAP_CLOCK_HZ / 1000U)
#define SPEED_ECAP_STOP_TIMEOUT_TICKS   (SPEED_ECAP_STOP_TIMEOUT_MS * SPEED_ECAP_TICKS_PER_MS)

#define SPEED_ECAP_RING_MASK            (SPEED_ECAP_RING_SIZE - 1U)

/* Ring entry flags */
#define SPEED_ECAP_EVT_RISING           (0x01U)   /* 0 = falling edge          */
#define SPEED_ECAP_EVT_BREAK            (0x02U)   /* events lost before this   */

/* In the silent-loss check: a spacing this many times smaller than the
 * largest spacing of the batch is a glitch pair, not a normal spacing. */
#define SPEED_ECAP_GLITCH_SPACING_RATIO     (8U)

/* Minimum steps in a window before the "not a quadrature pair" check. */
#define SPEED_ECAP_NOT_QUADRATURE_MIN_STEPS (8U)

#define SPEED_ECAP_CH_A                 (0U)
#define SPEED_ECAP_CH_B                 (1U)

/* Signed 32-bit time differences are valid up to 2^31 ticks = 10.74 s.
 * Everything that can age (last edge, waiting rising edge, last harvested
 * timestamp) is retired after the stop timeout, checked at least once per
 * window (<= 1 s) and on every tick. Timeout + window must stay below
 * 10.74 s, so the timeout is limited to 8 s. */
#if (SPEED_ECAP_STOP_TIMEOUT_MS > 8000U)
#error "SPEED_ECAP_STOP_TIMEOUT_MS must be <= 8000 ms (signed time differences are valid up to 10.74 s)"
#endif

/* After this many ticks without any event, the last harvested timestamp is
 * forgotten, so the loss checks never compare across a gap longer than
 * 10.74 s (a long standstill). */
#define SPEED_ECAP_IDLE_TICKS_LIMIT     ((SPEED_ECAP_STOP_TIMEOUT_MS * 1000U) / SPEED_ECAP_TICK_PERIOD_US)

#if ((SPEED_ECAP_RING_SIZE & SPEED_ECAP_RING_MASK) != 0U)
#error "SPEED_ECAP_RING_SIZE must be a power of 2"
#endif

/* ==========================================================================
 * PRIVATE TYPES
 * ========================================================================== */

struct SPEED_ECAP_PG_s;

typedef struct
{
    /* ---- set at init ---- */
    uint32_t                  ecap_base;
    ECAP_InputCaptureSignals  xbar_input;
    uint32_t                  int_num;
    uint32_t                  index;              /* SPEED_ECAP_CH_A / _B        */
    struct SPEED_ECAP_PG_s   *owner_pg;
    HwiP_Object               hwi_object;

    /* ---- HARVEST state: only with interrupts disabled ---- */
    uint8_t   next_event_index;                   /* CAPn the hardware fills next */
    bool      has_harvested_ts;
    uint32_t  last_harvested_ts;
    uint8_t   pending_mark;                       /* BREAK for the next entry     */
    uint32_t  ring_ts[SPEED_ECAP_RING_SIZE];
    uint8_t   ring_flags[SPEED_ECAP_RING_SIZE];
    uint32_t  ring_head;                          /* entries written (free run)   */
    uint32_t  lost_rise_count;                    /* rising edges lost            */
    uint32_t  lost_event_count;                   /* all edges lost               */
    uint32_t  overrun_count;                      /* loss detections              */
    uint32_t  idle_ticks;                         /* ticks with no event          */
    bool      has_check_ts;
    uint32_t  last_check_ts;                      /* ECAP time of the last harvest:
                                                     every edge before it has been
                                                     copied                        */

    /* ---- TASK state ---- */
    uint32_t  ring_tail;                          /* entries consumed (free run)  */

    /* glitch filter: a rising edge waits here until its falling edge */
    bool      pending_rise_valid;
    uint32_t  pending_rise_ts;
    bool      pending_rise_break;
    bool      chain_break;                        /* BREAK seen, not yet applied  */
    bool      prev_rise_valid;                    /* a rising edge was judged     */
    uint32_t  prev_rise_ts;                       /* ... at this time             */
    bool      last_width_rejected;                /* last judged rise was a glitch*/

    /* speed chain: accepted rising edges */
    bool      has_edge;
    bool      restart_pending;
    uint32_t  edge_count;
    uint32_t  last_edge_ts;
    uint32_t  last_period_ticks;                  /* 0 = unknown                  */
    uint32_t  run_id;
    uint32_t  glitch_count;

    /* filter limits (from PPR and diameter) */
    uint32_t  min_period_ticks;                   /* glitch limit (375 km/h)      */
    uint32_t  min_width_abs_ticks;                /* absolute minimum high time   */
    uint32_t  adaptive_max_period;                /* adaptive width above 2 km/h  */

    /* previous window */
    bool      prev_valid;
    uint32_t  prev_pulse_total;                   /* accepted + lost rises        */
    uint32_t  prev_accepted_count;
    uint32_t  prev_edge_ts;
    uint32_t  prev_run_id;
    uint32_t  prev_glitch_count;
    uint32_t  prev_overrun_count;
} SPEED_ECAP_CHANNEL;

typedef struct SPEED_ECAP_PG_s
{
    SPEED_ECAP_CHANNEL channel[2];                /* [0] = A, [1] = B             */
    bool     invert_direction;
    bool     filters_ready;
    bool     irq_enabled;
    bool     rate_fault;                          /* tick too slow, IRQ off       */

    /* ---- quadrature decoder (task) ---- */
    bool     level_known[2];
    bool     level[2];
    int32_t  position_q;                          /* quarter pulses, signed       */
    int8_t   last_step;
    uint8_t  step_streak;
    int8_t   confirmed_direction;                 /* before inversion             */
    uint32_t quad_error_count;
    uint32_t quad_reversal_count;
    uint32_t quad_step_count;                     /* all steps, both signs        */
    uint32_t break_step_count;                    /* steps not counted at a BREAK */

    /* ---- previous window ---- */
    int32_t  reported_q;                          /* quarters already reported    */
    uint32_t prev_quad_error_count;
    uint32_t prev_quad_reversal_count;
    uint32_t prev_quad_step_count;
    uint32_t prev_lost_steps;                     /* lost events A+B + break steps*/
    uint32_t prev_tick_calls;
    uint32_t prev_irq_calls;
} SPEED_ECAP_PG;

/* ==========================================================================
 * PRIVATE DATA
 * ========================================================================== */

static SPEED_ECAP_PG    gSpeedEcapPg[SPEED_ECAP_MAX_PG];
static uint32_t         gSpeedEcapNumPg = 0U;
static SPEED_ECAP_STATS gSpeedEcapStats;

static const ECAP_Events gSpeedEcapEventId[SPEED_ECAP_NUM_EVENTS] =
{
    ECAP_EVENT_1, ECAP_EVENT_2, ECAP_EVENT_3, ECAP_EVENT_4
};

static const uint16_t gSpeedEcapEventFlag[SPEED_ECAP_NUM_EVENTS] =
{
    ECAP_ISR_SOURCE_CAPTURE_EVENT_1, ECAP_ISR_SOURCE_CAPTURE_EVENT_2,
    ECAP_ISR_SOURCE_CAPTURE_EVENT_3, ECAP_ISR_SOURCE_CAPTURE_EVENT_4
};

/* CAP1 and CAP3 capture rising edges, CAP2 and CAP4 falling edges. */
#define SPEED_ECAP_INDEX_IS_RISING(i)   (((i) & 1U) == 0U)

/* ==========================================================================
 * PRIVATE FUNCTION PROTOTYPES
 * ========================================================================== */

static void     SpeedEcap_Isr(void *args);
static uint32_t SpeedEcap_Harvest(SPEED_ECAP_CHANNEL *channel);
static void     SpeedEcap_RingPush(SPEED_ECAP_CHANNEL *channel, uint32_t edge_ts, uint8_t flags);

static void     SpeedEcap_SetupChannel(SPEED_ECAP_CHANNEL *channel, SPEED_ECAP_PG *pg, uint32_t index,
                                       uint32_t ecap_base, ECAP_InputCaptureSignals xbar_input,
                                       uint32_t int_num);
static void     SpeedEcap_ConfigureModule(const SPEED_ECAP_CHANNEL *channel);
static int32_t  SpeedEcap_RegisterInterrupt(SPEED_ECAP_CHANNEL *channel);
static int32_t  SpeedEcap_StartAllCounters(void);
static void     SpeedEcap_StartHarvest(void);
static void     SpeedEcap_SetIrq(SPEED_ECAP_PG *pg, bool enable);
static uint32_t SpeedEcap_AbsDiff(uint32_t value_1, uint32_t value_2);

static void     SpeedEcap_ServicePg(SPEED_ECAP_PG *pg);
static void     SpeedEcap_UpdateFilters(SPEED_ECAP_PG *pg, uint16_t pulses_per_rev, double wheel_dia_m);
static void     SpeedEcap_ConsumeEvents(SPEED_ECAP_PG *pg, uint32_t head_a, uint32_t head_b);
static void     SpeedEcap_QuadratureStep(SPEED_ECAP_PG *pg, uint32_t ch, bool rising, bool is_break);
static void     SpeedEcap_SpeedEvent(SPEED_ECAP_CHANNEL *channel, uint32_t edge_ts, bool rising, bool is_break);
static uint32_t SpeedEcap_MinWidth(const SPEED_ECAP_CHANNEL *channel, uint32_t rise_ts);
static void     SpeedEcap_AcceptRise(SPEED_ECAP_CHANNEL *channel, uint32_t edge_ts, bool is_break);
static void     SpeedEcap_EvaluateChannel(SPEED_ECAP_CHANNEL *channel, uint32_t now_ticks,
                                          uint32_t overrun_count, uint32_t lost_rises,
                                          uint16_t pulses_per_rev, double wheel_dia_m,
                                          SPEED_ECAP_CHANNEL_RESULT *out);
static double   SpeedEcap_MeasureFrequency(const SPEED_ECAP_CHANNEL *channel, uint32_t overrun_count);
static double   SpeedEcap_ApplyDecay(double frequency_hz, uint32_t ticks_since_last_edge, uint32_t last_period_ticks);
static int8_t   SpeedEcap_ApplyInversion(int8_t direction, bool invert);

/* ==========================================================================
 * PUBLIC
 * ========================================================================== */

int32_t SpeedEcap_Init(const SPEED_ECAP_PG_HW_CONFIG hw_config[], uint32_t num_pg)
{
    int32_t  status = SystemP_SUCCESS;
    uint32_t pg_index;

    if((hw_config == NULL) || (num_pg == 0U) || (num_pg > SPEED_ECAP_MAX_PG))
    {
        status = SystemP_FAILURE;
    }

    if(status == SystemP_SUCCESS)
    {
        (void)memset(gSpeedEcapPg, 0, sizeof(gSpeedEcapPg));
        (void)memset(&gSpeedEcapStats, 0, sizeof(gSpeedEcapStats));
        gSpeedEcapNumPg = num_pg;

        for(pg_index = 0U; pg_index < num_pg; pg_index++)
        {
            SPEED_ECAP_PG *pg = &gSpeedEcapPg[pg_index];

            pg->invert_direction    = hw_config[pg_index].invert_direction;
            pg->confirmed_direction = SPEED_ECAP_DIR_UNKNOWN;

            SpeedEcap_SetupChannel(&pg->channel[SPEED_ECAP_CH_A], pg, SPEED_ECAP_CH_A,
                                   hw_config[pg_index].ecap_base_a,
                                   hw_config[pg_index].xbar_input_a,
                                   hw_config[pg_index].int_num_a);
            SpeedEcap_SetupChannel(&pg->channel[SPEED_ECAP_CH_B], pg, SPEED_ECAP_CH_B,
                                   hw_config[pg_index].ecap_base_b,
                                   hw_config[pg_index].xbar_input_b,
                                   hw_config[pg_index].int_num_b);
        }

        for(pg_index = 0U; pg_index < num_pg; pg_index++)
        {
            SpeedEcap_ConfigureModule(&gSpeedEcapPg[pg_index].channel[SPEED_ECAP_CH_A]);
            SpeedEcap_ConfigureModule(&gSpeedEcapPg[pg_index].channel[SPEED_ECAP_CH_B]);
        }

        /* The interrupts are registered so they can be switched on later
         * (IRQ_AUTO / IRQ_ALWAYS), but the ECAP does not raise them yet. */
        for(pg_index = 0U; (pg_index < num_pg) && (status == SystemP_SUCCESS); pg_index++)
        {
            status = SpeedEcap_RegisterInterrupt(&gSpeedEcapPg[pg_index].channel[SPEED_ECAP_CH_A]);

            if(status == SystemP_SUCCESS)
            {
                status = SpeedEcap_RegisterInterrupt(&gSpeedEcapPg[pg_index].channel[SPEED_ECAP_CH_B]);
            }
        }
    }

    if(status == SystemP_SUCCESS)
    {
        status = SpeedEcap_StartAllCounters();
    }

    if(status == SystemP_SUCCESS)
    {
        SpeedEcap_StartHarvest();
    }

    return status;
}

void SpeedEcap_Tick(void)
{
    uint32_t  pg_index;
    uintptr_t interrupt_key;
#if (SPEED_ECAP_PROFILE == 1U)
    uint32_t  start_cycles = CycleCounterP_getCount32();
#endif

    for(pg_index = 0U; pg_index < gSpeedEcapNumPg; pg_index++)
    {
        uint32_t ch;

        interrupt_key = HwiP_disable();

        for(ch = 0U; ch < 2U; ch++)
        {
            SPEED_ECAP_CHANNEL *channel = &gSpeedEcapPg[pg_index].channel[ch];

            if(SpeedEcap_Harvest(channel) != 0U)
            {
                channel->idle_ticks = 0U;
            }
            else if(channel->idle_ticks < SPEED_ECAP_IDLE_TICKS_LIMIT)
            {
                channel->idle_ticks++;
            }
            else
            {
                /* Long standstill: forget the last timestamp, so the next
                 * edge is not compared with one more than 10.74 s old. */
                channel->has_harvested_ts = false;
            }
        }

        HwiP_restore(interrupt_key);
    }

    gSpeedEcapStats.tick_calls++;

#if (SPEED_ECAP_PROFILE == 1U)
    {
        uint32_t used = CycleCounterP_getCount32() - start_cycles;
        if(used > gSpeedEcapStats.max_tick_cycles)
        {
            gSpeedEcapStats.max_tick_cycles = used;
        }
    }
#endif
}

void SpeedEcap_Service(void)
{
    uint32_t pg_index;

    for(pg_index = 0U; pg_index < gSpeedEcapNumPg; pg_index++)
    {
        SpeedEcap_ServicePg(&gSpeedEcapPg[pg_index]);
    }
}

void SpeedEcap_Evaluate(uint32_t pg_index,
                        uint16_t pulses_per_rev,
                        double   wheel_dia_m,
                        SPEED_ECAP_PG_RESULT *result)
{
    SPEED_ECAP_PG *pg;
    uintptr_t      interrupt_key;
    uint32_t       head_a;
    uint32_t       head_b;
    uint32_t       now_a;
    uint32_t       now_b;
    uint32_t       overruns_a;
    uint32_t       overruns_b;
    uint32_t       lost_a;
    uint32_t       lost_b;
    uint32_t       tick_calls;
    uint32_t       irq_calls;
    uint32_t       lost_events;
    int32_t        delta_q;
    int32_t        delta_pulses;

    if(result == NULL)
    {
        return;
    }

    (void)memset(result, 0, sizeof(SPEED_ECAP_PG_RESULT));
    result->direction               = SPEED_ECAP_DIR_UNKNOWN;
    result->net_direction_in_window = SPEED_ECAP_DIR_UNKNOWN;

    if(pg_index >= gSpeedEcapNumPg)
    {
        result->fault_config = true;
        return;
    }

    pg = &gSpeedEcapPg[pg_index];

    if((pulses_per_rev == 0U) || (wheel_dia_m <= 0.0))
    {
        result->fault_config = true;
    }

    SpeedEcap_UpdateFilters(pg, pulses_per_rev, wheel_dia_m);

    /* ---- short critical section: pick up everything captured so far ---- */
    interrupt_key = HwiP_disable();

    SpeedEcap_Harvest(&pg->channel[SPEED_ECAP_CH_A]);
    SpeedEcap_Harvest(&pg->channel[SPEED_ECAP_CH_B]);

    head_a     = pg->channel[SPEED_ECAP_CH_A].ring_head;
    head_b     = pg->channel[SPEED_ECAP_CH_B].ring_head;
    now_a      = ECAP_getTimeBaseCounter(pg->channel[SPEED_ECAP_CH_A].ecap_base);
    now_b      = ECAP_getTimeBaseCounter(pg->channel[SPEED_ECAP_CH_B].ecap_base);
    overruns_a = pg->channel[SPEED_ECAP_CH_A].overrun_count;
    overruns_b = pg->channel[SPEED_ECAP_CH_B].overrun_count;
    lost_a     = pg->channel[SPEED_ECAP_CH_A].lost_rise_count;
    lost_b     = pg->channel[SPEED_ECAP_CH_B].lost_rise_count;
    tick_calls = gSpeedEcapStats.tick_calls;
    irq_calls  = gSpeedEcapStats.irq_calls;
    lost_events = pg->channel[SPEED_ECAP_CH_A].lost_event_count +
                  pg->channel[SPEED_ECAP_CH_B].lost_event_count;

    HwiP_restore(interrupt_key);
    /* -------------------------------------------------------------------- */

    SpeedEcap_ConsumeEvents(pg, head_a, head_b);

    SpeedEcap_EvaluateChannel(&pg->channel[SPEED_ECAP_CH_A], now_a, overruns_a, lost_a,
                              pulses_per_rev, wheel_dia_m, &result->channel_a);
    SpeedEcap_EvaluateChannel(&pg->channel[SPEED_ECAP_CH_B], now_b, overruns_b, lost_b,
                              pulses_per_rev, wheel_dia_m, &result->channel_b);

    result->direction = SpeedEcap_ApplyInversion(pg->confirmed_direction, pg->invert_direction);

    /* Events lost in the hardware buffer (or ring) moved the wheel too, but
     * the decoder could not see them. Add them in the confirmed direction
     * (1 event = 1 quarter step). With no confirmed direction, nothing is
     * added. */
    {
        uint32_t lost_steps = lost_events + pg->break_step_count;
        uint32_t new_lost   = lost_steps - pg->prev_lost_steps;

        pg->prev_lost_steps = lost_steps;

        if(pg->confirmed_direction == SPEED_ECAP_DIR_FORWARD)
        {
            pg->position_q = (int32_t)((uint32_t)pg->position_q + new_lost);
        }
        else if(pg->confirmed_direction == SPEED_ECAP_DIR_REVERSE)
        {
            pg->position_q = (int32_t)((uint32_t)pg->position_q - new_lost);
        }
        else
        {
            ;
        }
    }

    /* Net movement in whole pulses; the quarter-pulse remainder stays in
     * position_q - reported_q for the next window. */
    delta_q      = (int32_t)((uint32_t)pg->position_q - (uint32_t)pg->reported_q);
    delta_pulses = delta_q / 4;                       /* truncates toward 0 */
    pg->reported_q = (int32_t)((uint32_t)pg->reported_q + ((uint32_t)delta_pulses * 4U));

    if(delta_pulses > 0)
    {
        result->net_pulses_in_window    = (uint32_t)delta_pulses;
        result->net_direction_in_window = SpeedEcap_ApplyInversion(SPEED_ECAP_DIR_FORWARD, pg->invert_direction);
    }
    else if(delta_pulses < 0)
    {
        result->net_pulses_in_window    = (uint32_t)(-delta_pulses);
        result->net_direction_in_window = SpeedEcap_ApplyInversion(SPEED_ECAP_DIR_REVERSE, pg->invert_direction);
    }
    else
    {
        ;
    }

    result->quad_errors_in_window    = pg->quad_error_count    - pg->prev_quad_error_count;
    result->quad_reversals_in_window = pg->quad_reversal_count - pg->prev_quad_reversal_count;
    {
        uint32_t steps = pg->quad_step_count - pg->prev_quad_step_count;

        /* A real quadrature pair steps the same way for long runs; a glitch
         * costs 2 reversals per 4+ steps, a real reversal 1. When at least
         * every second step reverses, A and B are not behaving as a
         * quadrature pair in this window (e.g. RDSO 33.4: different
         * frequencies on A and B): do not report a direction. */
        if((steps >= SPEED_ECAP_NOT_QUADRATURE_MIN_STEPS) &&
           ((result->quad_reversals_in_window * 2U) >= steps))
        {
            result->direction = SPEED_ECAP_DIR_UNKNOWN;
        }
        pg->prev_quad_step_count = pg->quad_step_count;
    }
    pg->prev_quad_error_count        = pg->quad_error_count;
    pg->prev_quad_reversal_count     = pg->quad_reversal_count;

    /* Harvest health: timestamps must have been collected since the last
     * window (by the tick, or by the ECAP interrupt). */
    if((pg->rate_fault == true) ||
       ((tick_calls == pg->prev_tick_calls) && (irq_calls == pg->prev_irq_calls) &&
        (pg->irq_enabled == false)))
    {
        result->fault_harvest = true;
    }
    pg->prev_tick_calls = tick_calls;
    pg->prev_irq_calls  = irq_calls;
    result->irq_enabled = pg->irq_enabled;
}

void SpeedEcap_GetStats(SPEED_ECAP_STATS *stats)
{
    uintptr_t interrupt_key;

    if(stats != NULL)
    {
        interrupt_key = HwiP_disable();
        *stats = gSpeedEcapStats;
        HwiP_restore(interrupt_key);
    }
}

/* ==========================================================================
 * HARVEST (interrupts disabled): copy CAP registers into the ring
 * ========================================================================== */

/* Only used when the ECAP interrupt is switched on. args = the PG: whichever
 * channel interrupted, both channels of the PG are emptied. */
static void SpeedEcap_Isr(void *args)
{
    SPEED_ECAP_PG *pg = (SPEED_ECAP_PG *)args;
#if (SPEED_ECAP_PROFILE == 1U)
    uint32_t start_cycles = CycleCounterP_getCount32();
#endif

    SpeedEcap_Harvest(&pg->channel[SPEED_ECAP_CH_A]);
    SpeedEcap_Harvest(&pg->channel[SPEED_ECAP_CH_B]);
    gSpeedEcapStats.irq_calls++;

#if (SPEED_ECAP_PROFILE == 1U)
    {
        uint32_t used = CycleCounterP_getCount32() - start_cycles;
        if(used > gSpeedEcapStats.max_irq_cycles)
        {
            gSpeedEcapStats.max_irq_cycles = used;
        }
    }
#endif
}

/*
 * 1. Read every flagged CAP register, starting at the one software expects
 *    next, then clear exactly those flags.
 * 2. Sort the (at most 4) timestamps by time. If a register was overwritten
 *    by a newer event, reading order and time order differ; sorting fixes it.
 * 3. Detect loss:
 *    a) the oldest entry is not in the CAP register we expected
 *       -> (index difference) events were overwritten;
 *    b) all 4 registers were full and the gap before the oldest entry is
 *       much larger than their spacing -> 4 (8, ...) events were lost with
 *       no other trace;
 *    c) the oldest entry is not later than the last one we read (should
 *       never happen; treated as a loss of unknown size).
 *    Any loss: count it, mark the next entry BREAK.
 * 4. Push the entries, oldest first, each tagged rising/falling from its
 *    CAP register (CAP1/CAP3 rising, CAP2/CAP4 falling).
 */
static uint32_t SpeedEcap_Harvest(SPEED_ECAP_CHANNEL *channel)
{
    uint32_t base = channel->ecap_base;
    uint16_t flags;
    uint32_t check_ts;
    uint32_t ts[SPEED_ECAP_NUM_EVENTS];
    uint8_t  idx[SPEED_ECAP_NUM_EVENTS];
    uint32_t count = 0U;
    uint32_t k;
    uint32_t j;
    uint32_t lost_events = 0U;
    uint32_t lost_rises  = 0U;
    bool     loss        = false;

    /* Read the time FIRST, then the flags: every edge captured before
     * check_ts is then either in these flags or was read earlier. So after
     * this harvest, edges can only be lost AFTER check_ts. */
    check_ts = ECAP_getTimeBaseCounter(base);
    flags    = ECAP_getInterruptSource(base) & SPEED_ECAP_CAPTURE_FLAGS;

    if(flags != 0U)
    {
        /* 1. read in expected order */
        for(k = 0U; k < SPEED_ECAP_NUM_EVENTS; k++)
        {
            uint8_t event_index = (uint8_t)((channel->next_event_index + k) & 3U);

            if((flags & gSpeedEcapEventFlag[event_index]) != 0U)
            {
                ts[count]  = ECAP_getEventTimeStamp(base, gSpeedEcapEventId[event_index]);
                idx[count] = event_index;
                count++;
            }
        }
        ECAP_clearInterrupt(base, flags);

        /* 2. insertion sort by time (wrap-safe signed difference) */
        for(k = 1U; k < count; k++)
        {
            uint32_t key_ts  = ts[k];
            uint8_t  key_idx = idx[k];

            j = k;
            while((j > 0U) && ((int32_t)(key_ts - ts[j - 1U]) < 0))
            {
                ts[j]  = ts[j - 1U];
                idx[j] = idx[j - 1U];
                j--;
            }
            ts[j]  = key_ts;
            idx[j] = key_idx;
        }

        /* 3. loss detection */
        if(channel->has_harvested_ts == true)
        {
            uint8_t expected = channel->next_event_index;

            /* a) registers between "expected" and the oldest entry were
             *    overwritten before we read them */
            lost_events = (uint32_t)((idx[0] - expected) & 3U);
            for(k = 0U; k < lost_events; k++)
            {
                if(SPEED_ECAP_INDEX_IS_RISING((expected + k) & 3U))
                {
                    lost_rises++;
                }
            }

            /* c) impossible order */
            if((int32_t)(ts[0] - channel->last_harvested_ts) <= 0)
            {
                loss = true;
            }

            /* b) All 4 registers were full: up to 4k more events may have
             *    been overwritten without any trace in the order. Compare the
             *    gap before the oldest entry with the normal spacing of
             *    edges, and pick the loss (index difference + 4k) closest to
             *    the number of spacings that fit in the gap.
             *    Normal spacing = average of the 3 spacings between the 4
             *    entries, EXCEPT when one spacing is tiny (a glitch pair, a
             *    few us, is inside the batch): then the largest spacing is
             *    used, because the average would be far too small and a
             *    normal gap would look like lost edges. */
            if(count == SPEED_ECAP_NUM_EVENTS)
            {
                /* Edges can only have been lost after the previous harvest
                 * (last_check_ts), not in the whole time since the last
                 * edge: at a sudden speed step (bench generator) the last
                 * edge may be ~100 ms old while the previous tick was 1 ms
                 * ago. */
                uint32_t gap_start    = channel->last_harvested_ts;
                uint32_t gap;
                uint32_t spacing_sum  = ts[count - 1U] - ts[0];
                uint32_t spacing_max  = 0U;
                uint32_t spacing_min  = 0xFFFFFFFFU;
                uint32_t spacing;

                if((channel->has_check_ts == true) &&
                   ((int32_t)(channel->last_check_ts - gap_start) > 0))
                {
                    gap_start = channel->last_check_ts;
                }
                gap = ((int32_t)(ts[0] - gap_start) > 0) ? (ts[0] - gap_start) : 0U;

                for(k = 1U; k < count; k++)
                {
                    uint32_t d = ts[k] - ts[k - 1U];

                    spacing_max = (d > spacing_max) ? d : spacing_max;
                    spacing_min = (d < spacing_min) ? d : spacing_min;
                }

                if(((uint64_t)spacing_min * SPEED_ECAP_GLITCH_SPACING_RATIO) < (uint64_t)spacing_max)
                {
                    spacing = spacing_max;                        /* glitch inside  */
                }
                else
                {
                    spacing = spacing_sum / (count - 1U);         /* clean: average */
                }

                if((spacing > 0U) &&
                   ((lost_events > 0U) ||
                    ((uint64_t)gap > (uint64_t)spacing * SPEED_ECAP_SILENT_LOSS_RATIO)))
                {
                    /* spacings in the gap, rounded = lost events + 1 */
                    uint32_t spacings  = (uint32_t)(((uint64_t)gap + ((uint64_t)spacing / 2U)) / (uint64_t)spacing);
                    uint32_t estimate  = (spacings > 0U) ? (spacings - 1U) : 0U;
                    uint32_t multiples = 0U;

                    if(estimate >= (lost_events + 2U))
                    {
                        multiples = (estimate - lost_events + 2U) / 4U;
                    }
                    if((lost_events == 0U) && (multiples == 0U))
                    {
                        multiples = 1U;   /* gap too large for no loss */
                    }
                    lost_events += multiples * 4U;
                    lost_rises  += multiples * 2U;
                }
            }

            if(lost_events > 0U)
            {
                loss = true;
            }
        }

        if(loss == true)
        {
            channel->overrun_count++;
            channel->lost_rise_count  += lost_rises;
            channel->lost_event_count += lost_events;
            channel->pending_mark      = SPEED_ECAP_EVT_BREAK;
        }

        /* 4. push oldest first */
        for(k = 0U; k < count; k++)
        {
            uint8_t evt_flags = 0U;

            if(SPEED_ECAP_INDEX_IS_RISING(idx[k]))
            {
                evt_flags = SPEED_ECAP_EVT_RISING;
            }
            SpeedEcap_RingPush(channel, ts[k], evt_flags);
        }

        channel->next_event_index  = (uint8_t)((idx[count - 1U] + 1U) & 3U);
        channel->last_harvested_ts = ts[count - 1U];
        channel->has_harvested_ts  = true;
        gSpeedEcapStats.events_harvested += count;
    }

    channel->last_check_ts = check_ts;
    channel->has_check_ts  = true;

    /* Re-arms the ECAP interrupt output (only matters when it is enabled). */
    ECAP_clearGlobalInterrupt(base);

    return count;
}

static void SpeedEcap_RingPush(SPEED_ECAP_CHANNEL *channel, uint32_t edge_ts, uint8_t flags)
{
    uint32_t used = channel->ring_head - channel->ring_tail;

    if(used >= SPEED_ECAP_RING_SIZE)
    {
        /* The task has not emptied the ring in time. */
        if((flags & SPEED_ECAP_EVT_RISING) != 0U)
        {
            channel->lost_rise_count++;
        }
        channel->lost_event_count++;
        channel->overrun_count++;
        channel->pending_mark = SPEED_ECAP_EVT_BREAK;
    }
    else
    {
        uint32_t slot = channel->ring_head & SPEED_ECAP_RING_MASK;

        channel->ring_ts[slot]    = edge_ts;
        channel->ring_flags[slot] = (uint8_t)(flags | channel->pending_mark);
        channel->pending_mark     = 0U;
        channel->ring_head++;
    }
}

static uint32_t SpeedEcap_AbsDiff(uint32_t value_1, uint32_t value_2)
{
    uint32_t forward_diff  = value_1 - value_2;
    uint32_t backward_diff = value_2 - value_1;

    return (forward_diff < backward_diff) ? forward_diff : backward_diff;
}

/* ==========================================================================
 * INIT HELPERS
 * ========================================================================== */

static void SpeedEcap_SetupChannel(SPEED_ECAP_CHANNEL *channel, SPEED_ECAP_PG *pg, uint32_t index,
                                   uint32_t ecap_base, ECAP_InputCaptureSignals xbar_input,
                                   uint32_t int_num)
{
    channel->ecap_base  = (uint32_t)AddrTranslateP_getLocalAddr(ecap_base);
    channel->xbar_input = xbar_input;
    channel->int_num    = int_num;
    channel->index      = index;
    channel->owner_pg   = pg;
}

/*
 * Overwrites whatever syscfg did for this ECAP.
 * Continuous capture, absolute time (no counter reset), CAP1/CAP3 on rising
 * edges and CAP2/CAP4 on falling edges. Counter stopped, interrupts off.
 */
static void SpeedEcap_ConfigureModule(const SPEED_ECAP_CHANNEL *channel)
{
    uint32_t base = channel->ecap_base;
    uint32_t event_index;

    ECAP_disableInterrupt(base, SPEED_ECAP_BASIC_FLAGS);
    ECAP_clearInterrupt(base, SPEED_ECAP_BASIC_FLAGS);
    ECAP_clearGlobalInterrupt(base);

    ECAP_disableTimeStampCapture(base);
    ECAP_stopCounter(base);

    ECAP_enableCaptureMode(base);
    ECAP_setCaptureMode(base, ECAP_CONTINUOUS_CAPTURE_MODE, ECAP_EVENT_4);
    ECAP_setEventPrescaler(base, 0U);

    for(event_index = 0U; event_index < SPEED_ECAP_NUM_EVENTS; event_index++)
    {
        if(SPEED_ECAP_INDEX_IS_RISING(event_index))
        {
            ECAP_setEventPolarity(base, gSpeedEcapEventId[event_index], ECAP_EVNT_RISING_EDGE);
        }
        else
        {
            ECAP_setEventPolarity(base, gSpeedEcapEventId[event_index], ECAP_EVNT_FALLING_EDGE);
        }
        ECAP_disableCounterResetOnEvent(base, gSpeedEcapEventId[event_index]);
    }

    ECAP_selectECAPInput(base, channel->xbar_input);

    /* Hardware pulse-width filter: ignores pulses shorter than 15 clock
     * cycles (75 ns). Longer glitches are handled in software. */
    ECAP_selectQualPeriod(base, ECAP_PULSE_WIDTH_FILTER_CYCLE15);

    ECAP_setPhaseShiftCount(base, 0U);
    ECAP_disableLoadCounter(base);
    ECAP_setSyncInPulseSource(base, ECAP_SYNC_IN_PULSE_SRC_DISABLE);
    ECAP_setSyncOutMode(base, ECAP_SYNC_OUT_DISABLED);
    ECAP_setEmulationMode(base, ECAP_EMULATION_FREE_RUN);

    ECAP_resetCounters(base);
    ECAP_enableTimeStampCapture(base);
}

static int32_t SpeedEcap_RegisterInterrupt(SPEED_ECAP_CHANNEL *channel)
{
    HwiP_Params hwi_params;

    HwiP_Params_init(&hwi_params);
    hwi_params.intNum   = channel->int_num;
    hwi_params.callback = &SpeedEcap_Isr;
    hwi_params.args     = (void *)channel->owner_pg;
    hwi_params.isPulse  = 1U;
    /* If the interrupts are ever used: give all four the same, high priority
     * in syscfg / here (hwi_params.priority). The ISR is a few register
     * reads, so a high priority costs the other interrupts nothing. */

    return HwiP_construct(&channel->hwi_object, &hwi_params);
}

static int32_t SpeedEcap_StartAllCounters(void)
{
    int32_t   status = SystemP_SUCCESS;
    uint32_t  pg_index;
    uint32_t  ch;
    uint32_t  reference_count;
    uintptr_t interrupt_key;

    interrupt_key = HwiP_disable();

    for(pg_index = 0U; pg_index < gSpeedEcapNumPg; pg_index++)
    {
        for(ch = 0U; ch < 2U; ch++)
        {
            HW_WR_REG32(gSpeedEcapPg[pg_index].channel[ch].ecap_base + CSL_ECAP_TSCTR, 0U);
        }
    }

    for(pg_index = 0U; pg_index < gSpeedEcapNumPg; pg_index++)
    {
        for(ch = 0U; ch < 2U; ch++)
        {
            ECAP_startCounter(gSpeedEcapPg[pg_index].channel[ch].ecap_base);
        }
    }

    reference_count = ECAP_getTimeBaseCounter(gSpeedEcapPg[0].channel[SPEED_ECAP_CH_A].ecap_base);

    for(pg_index = 0U; pg_index < gSpeedEcapNumPg; pg_index++)
    {
        for(ch = 0U; ch < 2U; ch++)
        {
            if(SpeedEcap_AbsDiff(ECAP_getTimeBaseCounter(gSpeedEcapPg[pg_index].channel[ch].ecap_base),
                                 reference_count) > SPEED_ECAP_MAX_START_SKEW_TICKS)
            {
                status = SystemP_FAILURE;
            }
        }
    }

    HwiP_restore(interrupt_key);

    return status;
}

/* Align software with the hardware modulo counters and clear old flags.
 * From here SpeedEcap_Tick() collects timestamps. */
static void SpeedEcap_StartHarvest(void)
{
    uint32_t  pg_index;
    uint32_t  ch;
    uintptr_t interrupt_key;

    interrupt_key = HwiP_disable();

    for(pg_index = 0U; pg_index < gSpeedEcapNumPg; pg_index++)
    {
        for(ch = 0U; ch < 2U; ch++)
        {
            SPEED_ECAP_CHANNEL *channel = &gSpeedEcapPg[pg_index].channel[ch];

            ECAP_clearInterrupt(channel->ecap_base, SPEED_ECAP_CAPTURE_FLAGS);
            ECAP_clearGlobalInterrupt(channel->ecap_base);
            channel->next_event_index = (uint8_t)ECAP_getModuloCounterStatus(channel->ecap_base);
            channel->has_harvested_ts = false;
        }
    }

    HwiP_restore(interrupt_key);
}

static void SpeedEcap_SetIrq(SPEED_ECAP_PG *pg, bool enable)
{
    uintptr_t interrupt_key;
    uint32_t  ch;

    if(pg->irq_enabled != enable)
    {
        interrupt_key = HwiP_disable();

        for(ch = 0U; ch < 2U; ch++)
        {
            if(enable == true)
            {
                ECAP_enableInterrupt(pg->channel[ch].ecap_base, SPEED_ECAP_IRQ_EVENT_MASK);
            }
            else
            {
                ECAP_disableInterrupt(pg->channel[ch].ecap_base, SPEED_ECAP_IRQ_EVENT_MASK);
            }
            ECAP_clearGlobalInterrupt(pg->channel[ch].ecap_base);
        }
        pg->irq_enabled = enable;

        HwiP_restore(interrupt_key);
    }
}

/* ==========================================================================
 * TASK SIDE
 * ========================================================================== */

static void SpeedEcap_ServicePg(SPEED_ECAP_PG *pg)
{
    uintptr_t interrupt_key;
    uint32_t  head_a;
    uint32_t  head_b;

    if(pg->filters_ready == false)
    {
        return;   /* PPR / diameter not known yet: leave events buffered */
    }

    interrupt_key = HwiP_disable();
    SpeedEcap_Harvest(&pg->channel[SPEED_ECAP_CH_A]);
    SpeedEcap_Harvest(&pg->channel[SPEED_ECAP_CH_B]);
    head_a = pg->channel[SPEED_ECAP_CH_A].ring_head;
    head_b = pg->channel[SPEED_ECAP_CH_B].ring_head;
    HwiP_restore(interrupt_key);

    SpeedEcap_ConsumeEvents(pg, head_a, head_b);
}

/*
 * Filter limits from PPR and wheel diameter, and the harvest decision:
 * is the tick fast enough, or are ECAP interrupts needed?
 */
static void SpeedEcap_UpdateFilters(SPEED_ECAP_PG *pg, uint16_t pulses_per_rev, double wheel_dia_m)
{
    uint32_t min_period_ticks    = 0U;
    uint32_t min_width_ticks     = 0U;
    uint32_t adaptive_max_period = 0U;
    bool     tick_too_slow       = false;
    bool     use_irq;
    uint32_t ch;

    if((pulses_per_rev != 0U) && (wheel_dia_m > 0.0))
    {
        double pulses_per_metre = (double)pulses_per_rev / (SPEED_ECAP_PI * wheel_dia_m);
        double max_real_hz      = (SPEED_ECAP_MAX_PLAUSIBLE_SPEED_KMPH / SPEED_ECAP_MPS_TO_KMPH) * pulses_per_metre;
        double glitch_hz        = max_real_hz * SPEED_ECAP_GLITCH_MARGIN;
        double adaptive_hz      = (SPEED_ECAP_ADAPTIVE_FILTER_MIN_KMPH / SPEED_ECAP_MPS_TO_KMPH) * pulses_per_metre;
        double buffer_time_us   = (2.0 / max_real_hz) * 1000000.0;   /* 4 events = 2 periods */

        min_period_ticks    = (uint32_t)((double)SPEED_ECAP_CLOCK_HZ / glitch_hz);
        min_width_ticks     = (uint32_t)(((uint64_t)min_period_ticks * SPEED_ECAP_MIN_PULSE_ABS_PERCENT) / 100U);
        adaptive_max_period = (uint32_t)((double)SPEED_ECAP_CLOCK_HZ / adaptive_hz);

        if(((double)SPEED_ECAP_TICK_PERIOD_US * SPEED_ECAP_HARVEST_MARGIN) >= buffer_time_us)
        {
            tick_too_slow = true;
        }
    }

    for(ch = 0U; ch < 2U; ch++)
    {
        pg->channel[ch].min_period_ticks    = min_period_ticks;
        pg->channel[ch].min_width_abs_ticks = min_width_ticks;
        pg->channel[ch].adaptive_max_period = adaptive_max_period;
    }

#if (SPEED_ECAP_IRQ_MODE == SPEED_ECAP_IRQ_ALWAYS)
    use_irq = true;
#elif (SPEED_ECAP_IRQ_MODE == SPEED_ECAP_IRQ_AUTO)
    use_irq = tick_too_slow;
#else
    use_irq = false;
#endif

    pg->rate_fault = ((tick_too_slow == true) && (use_irq == false));
    SpeedEcap_SetIrq(pg, use_irq);
    pg->filters_ready = true;
}

/*
 * Merge the A and B rings in time order (both rings are already sorted).
 * Each event goes to the quadrature decoder and to its channel's speed chain.
 */
static void SpeedEcap_ConsumeEvents(SPEED_ECAP_PG *pg, uint32_t head_a, uint32_t head_b)
{
    SPEED_ECAP_CHANNEL *channel_a = &pg->channel[SPEED_ECAP_CH_A];
    SPEED_ECAP_CHANNEL *channel_b = &pg->channel[SPEED_ECAP_CH_B];

    while((channel_a->ring_tail != head_a) || (channel_b->ring_tail != head_b))
    {
        SPEED_ECAP_CHANNEL *next_channel;
        uint32_t            slot;
        uint8_t             flags;
        bool                rising;
        bool                is_break;

        if(channel_a->ring_tail == head_a)
        {
            next_channel = channel_b;
        }
        else if(channel_b->ring_tail == head_b)
        {
            next_channel = channel_a;
        }
        else
        {
            uint32_t ts_a = channel_a->ring_ts[channel_a->ring_tail & SPEED_ECAP_RING_MASK];
            uint32_t ts_b = channel_b->ring_ts[channel_b->ring_tail & SPEED_ECAP_RING_MASK];

            next_channel = ((int32_t)(ts_a - ts_b) <= 0) ? channel_a : channel_b;
        }

        slot     = next_channel->ring_tail & SPEED_ECAP_RING_MASK;
        flags    = next_channel->ring_flags[slot];
        rising   = ((flags & SPEED_ECAP_EVT_RISING) != 0U);
        is_break = ((flags & SPEED_ECAP_EVT_BREAK) != 0U);

        SpeedEcap_QuadratureStep(pg, next_channel->index, rising, is_break);
        SpeedEcap_SpeedEvent(next_channel, next_channel->ring_ts[slot], rising, is_break);

        next_channel->ring_tail++;
    }
}

/*
 * x4 quadrature decoder. State = (level A, level B). Forward (A leads B):
 *     00 -> 10 -> 11 -> 01 -> 00        (A rises, B rises, A falls, B falls)
 * Every edge changes exactly one level; the step is +1 when it follows the
 * forward order and -1 when it follows the reverse order:
 *     edge on A:  +1 if new A != B,   -1 if new A == B
 *     edge on B:  +1 if new B == A,   -1 if new B != A
 * This does not depend on duty cycle or on the exact phase, and a glitch on
 * one channel gives -1 then +1, which cancels.
 */
static void SpeedEcap_QuadratureStep(SPEED_ECAP_PG *pg, uint32_t ch, bool rising, bool is_break)
{
    uint32_t other = 1U - ch;
    int8_t   step;

    if((is_break == true) || (pg->level_known[ch] == false))
    {
        /* Unknown what was missed: only learn the new level. The step of
         * this edge is not counted here; after a BREAK it is added back in
         * SpeedEcap_Evaluate() together with the lost events. */
        if((is_break == true) && (pg->level_known[ch] == true))
        {
            pg->break_step_count++;
        }
        pg->level_known[ch] = true;
        pg->level[ch]       = rising;
        pg->step_streak     = 0U;
        return;
    }

    if(pg->level[ch] == rising)
    {
        /* Same edge polarity twice on one channel: an edge was lost. */
        pg->quad_error_count++;
        pg->step_streak = 0U;
        return;
    }

    pg->level[ch] = rising;

    if(pg->level_known[other] == false)
    {
        return;
    }

    if(ch == SPEED_ECAP_CH_A)
    {
        step = (pg->level[SPEED_ECAP_CH_A] != pg->level[SPEED_ECAP_CH_B]) ? (int8_t)1 : (int8_t)-1;
    }
    else
    {
        step = (pg->level[SPEED_ECAP_CH_B] == pg->level[SPEED_ECAP_CH_A]) ? (int8_t)1 : (int8_t)-1;
    }

    pg->position_q = (int32_t)((uint32_t)pg->position_q + (uint32_t)(int32_t)step);
    pg->quad_step_count++;

    if(step == pg->last_step)
    {
        if(pg->step_streak < 255U)
        {
            pg->step_streak++;
        }
    }
    else
    {
        if(pg->last_step != 0)
        {
            pg->quad_reversal_count++;
        }
        pg->last_step   = step;
        pg->step_streak = 1U;
    }

    if(pg->step_streak >= SPEED_ECAP_DIR_CONFIRM_STEPS)
    {
        pg->confirmed_direction = (step > 0) ? SPEED_ECAP_DIR_FORWARD : SPEED_ECAP_DIR_REVERSE;
    }
}

/*
 * Glitch filter + speed chain for one channel.
 * A rising edge is held until its falling edge arrives. If the signal was
 * high for less than the minimum width, the pair is a glitch and both edges
 * are dropped; otherwise the rising edge is a real pulse.
 */
static void SpeedEcap_SpeedEvent(SPEED_ECAP_CHANNEL *channel, uint32_t edge_ts, bool rising, bool is_break)
{
    if(is_break == true)
    {
        channel->chain_break        = true;
        channel->pending_rise_valid = false;
        channel->prev_rise_valid    = false;
    }

    if(rising == true)
    {
        channel->pending_rise_valid = true;
        channel->pending_rise_ts    = edge_ts;
        channel->pending_rise_break = channel->chain_break;
        channel->chain_break        = false;
    }
    else if(channel->pending_rise_valid == true)
    {
        uint32_t high_ticks = edge_ts - channel->pending_rise_ts;

        if(high_ticks < SpeedEcap_MinWidth(channel, channel->pending_rise_ts))
        {
            channel->glitch_count++;
            channel->last_width_rejected = true;
            if(channel->pending_rise_break == true)
            {
                channel->chain_break = true;   /* keep the break for the next real rise */
            }
        }
        else
        {
            channel->last_width_rejected = false;
            SpeedEcap_AcceptRise(channel, channel->pending_rise_ts, channel->pending_rise_break);
        }
        channel->prev_rise_valid    = true;
        channel->prev_rise_ts       = channel->pending_rise_ts;
        channel->pending_rise_valid = false;
    }
    else
    {
        ;   /* falling edge with no rising edge before it (after a break) */
    }
}

/*
 * Minimum high time for a rising edge to count as a real pulse.
 *   Absolute part: 15 % of the period at the glitch limit (143 us at 30 PPR).
 *   Adaptive part (above 2 km/h): 10 % of a reference period, where the
 *   reference is the SHORTER of
 *     - the last accepted period, and
 *     - the time since the previous rising edge that was judged (accepted
 *       or rejected).
 * The second term makes the filter follow a sudden speed increase: after
 * a step from 3 km/h to 250 km/h the last accepted period is still ~120 ms,
 * but the rising edges now come every 1.4 ms, so the limit drops at once.
 * Safety net: directly after a rejection only the absolute part is used,
 * so the adaptive part can never reject two rising edges in a row (it can
 * never lock onto a stale reference).
 */
static uint32_t SpeedEcap_MinWidth(const SPEED_ECAP_CHANNEL *channel, uint32_t rise_ts)
{
    uint32_t width     = channel->min_width_abs_ticks;
    uint32_t reference = channel->last_period_ticks;

    if(channel->prev_rise_valid == true)
    {
        uint32_t since_prev_rise = rise_ts - channel->prev_rise_ts;

        if((since_prev_rise > 0U) && ((reference == 0U) || (since_prev_rise < reference)))
        {
            reference = since_prev_rise;
        }
    }

    if((channel->last_width_rejected == false) &&
       (reference != 0U) && (reference < channel->adaptive_max_period))
    {
        uint32_t adaptive = (uint32_t)(((uint64_t)reference * SPEED_ECAP_MIN_PULSE_PERIOD_PERCENT) / 100U);

        if(adaptive > width)
        {
            width = adaptive;
        }
    }

    return width;
}

/* A real rising edge: period, count, restart handling. */
static void SpeedEcap_AcceptRise(SPEED_ECAP_CHANNEL *channel, uint32_t edge_ts, bool is_break)
{
    bool     is_restart   = false;
    uint32_t period_ticks = 0U;

    if((channel->has_edge == false) || (channel->restart_pending == true) || (is_break == true))
    {
        is_restart = true;
    }
    else
    {
        period_ticks = edge_ts - channel->last_edge_ts;

        if(period_ticks > SPEED_ECAP_STOP_TIMEOUT_TICKS)
        {
            is_restart = true;
        }
        else if(period_ticks < channel->min_period_ticks)
        {
            channel->glitch_count++;   /* faster than any real speed */
            return;
        }
        else
        {
            ;
        }
    }

    if(is_restart == true)
    {
        channel->run_id++;
        channel->last_period_ticks = 0U;
        channel->restart_pending   = false;
    }
    else
    {
        channel->last_period_ticks = period_ticks;
    }

    channel->last_edge_ts = edge_ts;
    channel->edge_count++;
    channel->has_edge = true;
}

static void SpeedEcap_EvaluateChannel(SPEED_ECAP_CHANNEL *channel, uint32_t now_ticks,
                                      uint32_t overrun_count, uint32_t lost_rises,
                                      uint16_t pulses_per_rev, double wheel_dia_m,
                                      SPEED_ECAP_CHANNEL_RESULT *out)
{
    double   frequency_hz = 0.0;
    bool     is_stopped   = true;
    uint32_t pulse_total  = channel->edge_count + lost_rises;

    /* A rising edge still waiting for its falling edge after the stop
     * timeout (wheel stopped with the signal high) is dropped: its
     * timestamp would be too old to measure a period from. */
    if((channel->pending_rise_valid == true) &&
       ((now_ticks - channel->pending_rise_ts) > SPEED_ECAP_STOP_TIMEOUT_TICKS))
    {
        channel->pending_rise_valid = false;
        channel->chain_break        = true;
    }

    /* stopped? (no accepted edge for longer than the stop timeout) */
    if((channel->has_edge == true) && (channel->restart_pending == false))
    {
        if((now_ticks - channel->last_edge_ts) > SPEED_ECAP_STOP_TIMEOUT_TICKS)
        {
            /* stopped: the old period is no reference for anything */
            channel->restart_pending   = true;
            channel->last_period_ticks = 0U;
            channel->prev_rise_valid   = false;
        }
        else
        {
            is_stopped = false;
        }
    }

    out->pulses_in_window   = pulse_total - channel->prev_pulse_total;
    out->glitches_in_window = channel->glitch_count - channel->prev_glitch_count;
    out->overruns_in_window = overrun_count - channel->prev_overrun_count;

    if(is_stopped == false)
    {
        /* How long is the current period at least?
         *  - no newer rising edge yet: at least (now - last accepted edge)
         *  - a newer rising edge is waiting for its falling edge (so it is
         *    not accepted yet): the period that ends there is
         *    (pending - last accepted), and the one after it is at least
         *    (now - pending). */
        uint32_t open_period_ticks = now_ticks - channel->last_edge_ts;

        if((channel->pending_rise_valid == true) &&
           ((int32_t)(channel->pending_rise_ts - channel->last_edge_ts) > 0))
        {
            uint32_t to_pending   = channel->pending_rise_ts - channel->last_edge_ts;
            uint32_t from_pending = now_ticks - channel->pending_rise_ts;

            open_period_ticks = (to_pending > from_pending) ? to_pending : from_pending;
        }

        frequency_hz = SpeedEcap_MeasureFrequency(channel, overrun_count);
        frequency_hz = SpeedEcap_ApplyDecay(frequency_hz, open_period_ticks, channel->last_period_ticks);
    }

    out->frequency_hz = frequency_hz;

    if((pulses_per_rev != 0U) && (wheel_dia_m > 0.0))
    {
        out->speed_mps = (frequency_hz / (double)pulses_per_rev) * (SPEED_ECAP_PI * wheel_dia_m);
    }
    else
    {
        out->speed_mps = 0.0;
    }

    channel->prev_valid          = channel->has_edge;
    channel->prev_pulse_total    = pulse_total;
    channel->prev_accepted_count = channel->edge_count;
    channel->prev_edge_ts        = channel->last_edge_ts;
    channel->prev_run_id         = channel->run_id;
    channel->prev_glitch_count   = channel->glitch_count;
    channel->prev_overrun_count  = overrun_count;
}

/*
 * M/T method: N accepted rising edges since the last accepted edge of the
 * previous window, over the exact time between those two edges:
 *     f = N x CLOCK / (t_last - t_prev_last)
 * Only valid when nothing broke the chain in between (same run_id, no
 * overrun). Otherwise the last single period is used.
 */
static double SpeedEcap_MeasureFrequency(const SPEED_ECAP_CHANNEL *channel, uint32_t overrun_count)
{
    double   frequency_hz = 0.0;
    uint32_t new_edges    = channel->edge_count - channel->prev_accepted_count;

    if((new_edges > 0U) &&
       (channel->prev_valid == true) &&
       (channel->run_id == channel->prev_run_id) &&
       (overrun_count == channel->prev_overrun_count))
    {
        uint32_t span_ticks = channel->last_edge_ts - channel->prev_edge_ts;

        if(span_ticks > 0U)
        {
            frequency_hz = ((double)new_edges * (double)SPEED_ECAP_CLOCK_HZ) / (double)span_ticks;
        }
    }
    else if(channel->last_period_ticks > 0U)
    {
        frequency_hz = (double)SPEED_ECAP_CLOCK_HZ / (double)channel->last_period_ticks;
    }
    else
    {
        frequency_hz = 0.0;
    }

    return frequency_hz;
}

/*
 * Once the next edge is overdue (more time has passed than the last period),
 * the true frequency is at most 1 / (time since the last edge).
 */
static double SpeedEcap_ApplyDecay(double frequency_hz, uint32_t ticks_since_last_edge, uint32_t last_period_ticks)
{
    double decayed_hz = frequency_hz;

    /* "Overdue" = more than 1/8 longer than the last period, so that normal
     * edge jitter never nudges the M/T result. */
    if((frequency_hz > 0.0) && (last_period_ticks > 0U) &&
       (ticks_since_last_edge > (last_period_ticks + (last_period_ticks / 8U))))
    {
        double upper_limit_hz = (double)SPEED_ECAP_CLOCK_HZ / (double)ticks_since_last_edge;

        if(upper_limit_hz < frequency_hz)
        {
            decayed_hz = upper_limit_hz;
        }
    }

    return decayed_hz;
}

static int8_t SpeedEcap_ApplyInversion(int8_t direction, bool invert)
{
    int8_t output = direction;

    if(invert == true)
    {
        output = (int8_t)(-direction);
    }

    return output;
}
