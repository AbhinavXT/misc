#ifndef SPEED_SENSOR_USER_H
#define SPEED_SENSOR_USER_H

#include <stdint.h>
#include <stdbool.h>
#include "speed_decision.h"

/*
 * Kavach glue for the ECAP speed module (speed_sensor_ecap.c, v3).
 * Replaces the EQEP based CalculateWheelRPM_EQEP() / CalculateWheelRPM_Generic().
 *
 * Wiring (must match syscfg Input XBAR + Interrupt XBAR):
 *      PG1 channel A -> ECAP0  <- INPUT XBAR 0  -> INT XBAR 22
 *      PG1 channel B -> ECAP1  <- INPUT XBAR 1  -> INT XBAR 23
 *      PG2 channel A -> ECAP2  <- INPUT XBAR 2  -> INT XBAR 24
 *      PG2 channel B -> ECAP3  <- INPUT XBAR 3  -> INT XBAR 25
 *
 * Calls the integrator must add (see KAVACH_ECAP_Integration_Guide.md):
 *      SpeedSensor_Init()           once, after loco_info is loaded
 *      SpeedSensor_Tick()           every SPEED_ECAP_TICK_PERIOD_US (1 ms),
 *                                   from the RTI tick ISR or a ClockP callback
 *      SpeedSensor_Service()        every main-loop pass (at least every 50 ms)
 *      CalculateWheelSpeed_ECAP()   every SPEED_SAMPLING_TIME
 *   Service and CalculateWheelSpeed_ECAP must run in the same task.
 */

/* RDSO test 33 time-outs. The specification pages only say "time out";
 * TODO: replace with the values from the FRS / loco configuration. */
#define SPEED_SENSOR_SPEED_SENSE_TIMEOUT_S      (3.0)   /* PLACEHOLDER */
#define SPEED_SENSOR_SLIP_SLIDE_TIMEOUT_S       (5.0)   /* PLACEHOLDER */

/* Windows the two PGs may disagree on direction before the direction
 * mismatch hook is called (one window is normal at a reversal). */
#define SPEED_SENSOR_DIR_MISMATCH_WINDOWS       (2U)

int32_t SpeedSensor_Init(void);
void    SpeedSensor_Tick(void);
void    SpeedSensor_Service(void);
void    CalculateWheelSpeed_ECAP(void);

/* Train speed decided per RDSO test 33 (highest valid channel speed).
 * Supervise with this and send it to stationary KAVACH. */
double  SpeedSensor_GetTrainSpeedKmph(void);

/* Full decision of the last window (slip state, failed channels, ...),
 * e.g. for the DMI or the mode manager. */
const SPEED_DEC_OUTPUT *SpeedSensor_GetDecision(void);

/* Hooks called once per event; defaults in speed_sensor_user.c only print.
 * Connect them to the event logger, NMS, DMI and mode manager. */
void SpeedSensor_HookChannelFailure(uint8_t channel);
void SpeedSensor_HookSystemFailure(void);
void SpeedSensor_HookSlipSlideUndetectable(void);
void SpeedSensor_HookSlipSlideDetected(uint8_t state, uint8_t source, uint8_t pg);
void SpeedSensor_HookSlipSlideTimeout(uint8_t state);
void SpeedSensor_HookDirectionMismatch(int8_t pg1_direction, int8_t pg2_direction);

#endif /* SPEED_SENSOR_USER_H */
