/*
 * speed_decision.c
 *
 * RDSO SIF-0533 test case 33: speed determination and slip/slide.
 *
 * -----------------------------------------------------------------------
 * DECISION ORDER (why this order)
 * -----------------------------------------------------------------------
 * Step 1  Are the channels healthy?
 *   a) Both comparators agree (RH-a~LH-a and RH-b~LH-b)       -> healthy
 *   b) Both PGs agree internally (RH-a~RH-b and LH-a~LH-b),
 *      but RH and LH differ from each other                   -> healthy,
 *      this is a PG-to-PG difference (slip/slide or normal wheel wear),
 *      NOT a sensor failure (33.9 - 33.13).
 *   c) Only one comparator agrees                             -> one channel
 *      is bad: use the good comparator, name the bad channel, log it after
 *      the timeout, slip/slide cannot be detected (33.4, 33.5, 33.14, 33.15)
 *   c2) Both comparators fail, one PG agrees internally, and one channel
 *      of the other PG is within the PG-difference limit of it (worn
 *      wheels: RH and LH differ by 1-3 km/h, so neither comparator can
 *      agree, and then one channel fails). Treated like c): the far
 *      channel is suspect. Not in the RDSO tables; without it a single
 *      channel failure on a loco with worn wheels would end in SF.
 *   d) Nothing agrees                                         -> speed
 *      determination malfunction; after the timeout: System Failure (33.6)
 *
 *   Case b) MUST be checked before c) and d): RH and LH wheels never have
 *   exactly the same diameter, so 1 km/h between PGs is normal at speed.
 *   Treating it as a sensor failure would drive a healthy loco to SF.
 *
 * Step 2  Train speed = highest usable speed (33.3: "highest of the four
 *         speeds"; requirement 4: "higher of the speeds reported by both PG").
 *
 * Step 3  Slip/slide, only when every channel is healthy (a or b):
 *   - PG difference: |RH - LH| > min(5 km/h, 5 % of speed)
 *   - acceleration of train speed over 1 s beyond +-1 m/s^2
 *   Slip  = the deviating wheel reads too fast, Slide = too slow.
 *   Persisting longer than the slip/slide timeout -> SR request.
 *
 * Timers are "leaky": a condition adds dt while present and removes dt
 * while absent, so a channel that flickers between agree and disagree is
 * still declared failed, and a failed channel is cleared only after it has
 * agreed again for as long as the timeout.
 */

#include <string.h>
#include "speed_decision.h"

/* ==========================================================================
 * PRIVATE DATA
 * ========================================================================== */

typedef struct
{
    SPEED_DEC_CONFIG config;

    double  suspect_time_s[SPEED_DEC_NUM_CHANNELS];
    uint8_t failed_channel_mask;

    double  malfunction_time_s;
    bool    system_failure_latched;

    double  undetectable_time_s;
    bool    undetectable_reported;

    /* slip/slide */
    bool    has_reference;
    double  reference_speed_kmph;    /* train speed before a PG difference   */
    uint8_t pg_slip_state;           /* classification held during an episode */
    uint8_t pg_slipping_pg;

    double  accel_elapsed_s;
    double  accel_start_speed_kmph;
    bool    accel_has_start;
    double  last_acceleration_mps2;

    uint8_t last_slip_state;
    double  slip_time_s;
    bool    sr_requested;
} SPEED_DEC_STATE;

static SPEED_DEC_STATE gSpeedDec;

/* Sums of dt (0.1 + 0.1 + ...) are not exact in floating point. */
#define SPEED_DEC_TIME_EPSILON_S    (0.0001)

/* ==========================================================================
 * PRIVATE HELPERS
 * ========================================================================== */

static double SpeedDec_Abs(double value)
{
    double result = value;

    if(value < 0.0)
    {
        result = -value;
    }

    return result;
}

static double SpeedDec_Max(double value_1, double value_2)
{
    double result = value_1;

    if(value_2 > value_1)
    {
        result = value_2;
    }

    return result;
}

/* Two channels agree if both are usable and differ by <= 1 km/h. */
static bool SpeedDec_Agree(const SPEED_DEC_INPUT *input, uint32_t channel_1, uint32_t channel_2)
{
    bool agree = false;

    if((input->channel_usable[channel_1] == true) && (input->channel_usable[channel_2] == true))
    {
        if(SpeedDec_Abs(input->channel_kmph[channel_1] - input->channel_kmph[channel_2]) <=
           (SPEED_DEC_CHANNEL_TOLERANCE_KMPH + SPEED_DEC_MEASUREMENT_MARGIN_KMPH))
        {
            agree = true;
        }
    }

    return agree;
}

/* Highest speed among the channels in the mask that are usable. */
static double SpeedDec_HighestOf(const SPEED_DEC_INPUT *input, uint8_t channel_mask)
{
    double   highest = 0.0;
    uint32_t channel;

    for(channel = 0U; channel < SPEED_DEC_NUM_CHANNELS; channel++)
    {
        if(((channel_mask & SPEED_DEC_MASK(channel)) != 0U) && (input->channel_usable[channel] == true))
        {
            highest = SpeedDec_Max(highest, input->channel_kmph[channel]);
        }
    }

    return highest;
}

/* PG-difference limit: min(5 km/h, 5 % of speed), not below
 * SPEED_DEC_SLIP_MIN_KMPH. */
static double SpeedDec_PgThreshold(double speed_kmph)
{
    double threshold_kmph = (speed_kmph * SPEED_DEC_SLIP_PERCENT) / 100.0;

    if(threshold_kmph > SPEED_DEC_SLIP_MAX_KMPH)
    {
        threshold_kmph = SPEED_DEC_SLIP_MAX_KMPH;
    }
    if(threshold_kmph < SPEED_DEC_SLIP_MIN_KMPH)
    {
        threshold_kmph = SPEED_DEC_SLIP_MIN_KMPH;
    }

    return threshold_kmph;
}

/*
 * One comparator is good, the other is not. The bad channel is the one of
 * the bad comparator that is further away from the good comparator's speed
 * (an unusable channel is always the bad one).
 */
static uint8_t SpeedDec_FindBadChannel(const SPEED_DEC_INPUT *input,
                                       uint32_t bad_channel_1, uint32_t bad_channel_2,
                                       double good_speed_kmph)
{
    uint8_t bad_mask;

    if(input->channel_usable[bad_channel_1] == false)
    {
        bad_mask = SPEED_DEC_MASK(bad_channel_1);
    }
    else if(input->channel_usable[bad_channel_2] == false)
    {
        bad_mask = SPEED_DEC_MASK(bad_channel_2);
    }
    else if(SpeedDec_Abs(input->channel_kmph[bad_channel_1] - good_speed_kmph) >=
            SpeedDec_Abs(input->channel_kmph[bad_channel_2] - good_speed_kmph))
    {
        bad_mask = SPEED_DEC_MASK(bad_channel_1);
    }
    else
    {
        bad_mask = SPEED_DEC_MASK(bad_channel_2);
    }

    return bad_mask;
}

/* ==========================================================================
 * STEP 1 + 2: speed determination
 * ========================================================================== */

static void SpeedDec_DetermineSpeed(const SPEED_DEC_INPUT *input, SPEED_DEC_OUTPUT *output)
{
    const uint8_t all_channels = (uint8_t)(SPEED_DEC_MASK(SPEED_DEC_CH_RH_A) | SPEED_DEC_MASK(SPEED_DEC_CH_RH_B) |
                                           SPEED_DEC_MASK(SPEED_DEC_CH_LH_A) | SPEED_DEC_MASK(SPEED_DEC_CH_LH_B));
    const uint8_t comparator_1 = (uint8_t)(SPEED_DEC_MASK(SPEED_DEC_CH_RH_A) | SPEED_DEC_MASK(SPEED_DEC_CH_LH_A));
    const uint8_t comparator_2 = (uint8_t)(SPEED_DEC_MASK(SPEED_DEC_CH_RH_B) | SPEED_DEC_MASK(SPEED_DEC_CH_LH_B));

    output->comparator_1_ok  = SpeedDec_Agree(input, SPEED_DEC_CH_RH_A, SPEED_DEC_CH_LH_A);
    output->comparator_2_ok  = SpeedDec_Agree(input, SPEED_DEC_CH_RH_B, SPEED_DEC_CH_LH_B);
    output->rh_pg_consistent = SpeedDec_Agree(input, SPEED_DEC_CH_RH_A, SPEED_DEC_CH_RH_B);
    output->lh_pg_consistent = SpeedDec_Agree(input, SPEED_DEC_CH_LH_A, SPEED_DEC_CH_LH_B);

    output->suspect_channel_mask  = 0U;
    output->speed_malfunction     = false;
    output->slip_slide_detectable = false;

    if(((output->comparator_1_ok == true) && (output->comparator_2_ok == true)) ||
       ((output->rh_pg_consistent == true) && (output->lh_pg_consistent == true)))
    {
        /* (a) or (b): all four channels healthy */
        output->decision_case         = (uint8_t)(((output->comparator_1_ok == true) && (output->comparator_2_ok == true)) ?
                                                  SPEED_DEC_CASE_A_COMPARATORS : SPEED_DEC_CASE_B_PG_DIFFERENCE);
        output->train_speed_kmph      = SpeedDec_HighestOf(input, all_channels);
        output->slip_slide_detectable = true;
    }
    else if(output->comparator_1_ok == true)
    {
        /* (c) comparator 1 good, comparator 2 has a bad channel */
        output->decision_case        = SPEED_DEC_CASE_C_ONE_COMPARATOR;
        output->train_speed_kmph     = SpeedDec_HighestOf(input, comparator_1);
        output->suspect_channel_mask = SpeedDec_FindBadChannel(input, SPEED_DEC_CH_RH_B, SPEED_DEC_CH_LH_B,
                                                               output->train_speed_kmph);
    }
    else if(output->comparator_2_ok == true)
    {
        /* (c) comparator 2 good, comparator 1 has a bad channel */
        output->decision_case        = SPEED_DEC_CASE_C_ONE_COMPARATOR;
        output->train_speed_kmph     = SpeedDec_HighestOf(input, comparator_2);
        output->suspect_channel_mask = SpeedDec_FindBadChannel(input, SPEED_DEC_CH_RH_A, SPEED_DEC_CH_LH_A,
                                                               output->train_speed_kmph);
    }
    else if(output->rh_pg_consistent != output->lh_pg_consistent)
    {
        /* Both comparators fail and exactly one PG agrees with itself.
         * (c2) if one channel of the other PG is within the PG-difference
         * limit of the good PG, that channel is fine and the other one is
         * suspect; otherwise (d). */
        uint32_t good_1  = SPEED_DEC_CH_RH_A;
        uint32_t good_2  = SPEED_DEC_CH_RH_B;
        uint32_t other_1 = SPEED_DEC_CH_LH_A;
        uint32_t other_2 = SPEED_DEC_CH_LH_B;
        double   good_kmph;
        double   limit_kmph;
        bool     other_1_ok;
        bool     other_2_ok;

        if(output->lh_pg_consistent == true)
        {
            good_1  = SPEED_DEC_CH_LH_A;
            good_2  = SPEED_DEC_CH_LH_B;
            other_1 = SPEED_DEC_CH_RH_A;
            other_2 = SPEED_DEC_CH_RH_B;
        }

        good_kmph  = (input->channel_kmph[good_1] + input->channel_kmph[good_2]) / 2.0;
        limit_kmph = SpeedDec_PgThreshold(good_kmph);
        other_1_ok = (input->channel_usable[other_1] == true) &&
                     (SpeedDec_Abs(input->channel_kmph[other_1] - good_kmph) <= limit_kmph);
        other_2_ok = (input->channel_usable[other_2] == true) &&
                     (SpeedDec_Abs(input->channel_kmph[other_2] - good_kmph) <= limit_kmph);

        if((other_1_ok == true) || (other_2_ok == true))
        {
            uint8_t bad_mask  = SpeedDec_FindBadChannel(input, other_1, other_2, good_kmph);
            uint8_t used_mask = (uint8_t)((SPEED_DEC_MASK(good_1) | SPEED_DEC_MASK(good_2) |
                                           SPEED_DEC_MASK(other_1) | SPEED_DEC_MASK(other_2)) &
                                          (uint8_t)~bad_mask);

            output->decision_case        = SPEED_DEC_CASE_C2_WORN_WHEEL;
            output->train_speed_kmph     = SpeedDec_HighestOf(input, used_mask);
            output->suspect_channel_mask = bad_mask;
        }
        else
        {
            output->decision_case        = SPEED_DEC_CASE_D_MALFUNCTION;
            output->train_speed_kmph     = SpeedDec_HighestOf(input, all_channels);
            output->suspect_channel_mask = all_channels;
            output->speed_malfunction    = true;
        }
    }
    else
    {
        /* (d) nothing agrees: keep the highest speed (safe side for
         * supervision) until System Failure is declared */
        output->decision_case        = SPEED_DEC_CASE_D_MALFUNCTION;
        output->train_speed_kmph     = SpeedDec_HighestOf(input, all_channels);
        output->suspect_channel_mask = all_channels;
        output->speed_malfunction    = true;
    }
}

/* Leaky timer: +dt while the condition is present, -dt while it is
 * absent, kept between 0 and limit. */
static double SpeedDec_Leaky(double timer_s, bool present, double dt_s, double limit_s)
{
    double result = present ? (timer_s + dt_s) : (timer_s - dt_s);

    if(result < 0.0)
    {
        result = 0.0;
    }
    if(result > limit_s)
    {
        result = limit_s;
    }

    return result;
}

static void SpeedDec_UpdateTimers(const SPEED_DEC_INPUT *input, SPEED_DEC_OUTPUT *output)
{
    uint32_t channel;
    uint8_t  previous_failed = gSpeedDec.failed_channel_mask;
    double   timeout_s       = gSpeedDec.config.speed_sense_timeout_s;

    /* ---- per-channel failure (33.4, 33.5, 33.14, 33.15) ----
     * During a malfunction (d) the per-channel state is frozen: that
     * situation is handled as a whole. */
    if(output->speed_malfunction == false)
    {
        for(channel = 0U; channel < SPEED_DEC_NUM_CHANNELS; channel++)
        {
            bool suspect = ((output->suspect_channel_mask & SPEED_DEC_MASK(channel)) != 0U);

            gSpeedDec.suspect_time_s[channel] = SpeedDec_Leaky(gSpeedDec.suspect_time_s[channel], suspect,
                                                               input->dt_s, timeout_s);

            if(gSpeedDec.suspect_time_s[channel] >= (timeout_s - SPEED_DEC_TIME_EPSILON_S))
            {
                gSpeedDec.failed_channel_mask |= SPEED_DEC_MASK(channel);
            }
            else if(gSpeedDec.suspect_time_s[channel] <= 0.0)
            {
                gSpeedDec.failed_channel_mask &= (uint8_t)~SPEED_DEC_MASK(channel);
            }
            else
            {
                ;   /* in between: keep the current failed state (hysteresis) */
            }
        }
    }

    output->failed_channel_mask     = gSpeedDec.failed_channel_mask;
    output->new_failed_channel_mask = (uint8_t)(gSpeedDec.failed_channel_mask & (uint8_t)~previous_failed);

    /* ---- speed determination malfunction -> System Failure (33.6) ---- */
    output->system_failure_event = false;
    gSpeedDec.malfunction_time_s = SpeedDec_Leaky(gSpeedDec.malfunction_time_s, output->speed_malfunction,
                                                  input->dt_s, timeout_s);

    if((gSpeedDec.malfunction_time_s >= (timeout_s - SPEED_DEC_TIME_EPSILON_S)) &&
       (gSpeedDec.system_failure_latched == false))
    {
        gSpeedDec.system_failure_latched = true;
        output->system_failure_event     = true;
    }

    output->system_failure_request = gSpeedDec.system_failure_latched;
}

/* ==========================================================================
 * STEP 3: slip / slide
 * ========================================================================== */

/*
 * PG difference (33.7 - 33.15). Both PGs are internally consistent here.
 * Which wheel is wrong? The one that moved away from the train speed seen
 * before the difference appeared. Moved up = slip, moved down = slide.
 */
static void SpeedDec_CheckPgDifference(const SPEED_DEC_INPUT *input, double train_speed_kmph,
                                       uint8_t *state, uint8_t *slipping_pg)
{
    double rh_kmph = (input->channel_kmph[SPEED_DEC_CH_RH_A] + input->channel_kmph[SPEED_DEC_CH_RH_B]) / 2.0;
    double lh_kmph = (input->channel_kmph[SPEED_DEC_CH_LH_A] + input->channel_kmph[SPEED_DEC_CH_LH_B]) / 2.0;
    double difference_kmph = SpeedDec_Abs(rh_kmph - lh_kmph);
    double threshold_kmph  = SpeedDec_PgThreshold(SpeedDec_Max(rh_kmph, lh_kmph));

    *state       = SPEED_DEC_SLIP_NONE;
    *slipping_pg = 0U;

    if(difference_kmph <= threshold_kmph)
    {
        /* no difference: this is the reference for the next episode */
        gSpeedDec.has_reference        = true;
        gSpeedDec.reference_speed_kmph = train_speed_kmph;
        gSpeedDec.pg_slip_state        = SPEED_DEC_SLIP_NONE;
        return;
    }

    if(gSpeedDec.pg_slip_state == SPEED_DEC_SLIP_NONE)
    {
        /* new episode: classify once, keep it until the difference ends */
        double  rh_deviation = SpeedDec_Abs(rh_kmph - gSpeedDec.reference_speed_kmph);
        double  lh_deviation = SpeedDec_Abs(lh_kmph - gSpeedDec.reference_speed_kmph);
        double  deviating_kmph;
        double  other_kmph;

        if((gSpeedDec.has_reference == false) || (rh_deviation >= lh_deviation))
        {
            gSpeedDec.pg_slipping_pg = 1U;
            deviating_kmph = rh_kmph;
            other_kmph     = lh_kmph;
        }
        else
        {
            gSpeedDec.pg_slipping_pg = 2U;
            deviating_kmph = lh_kmph;
            other_kmph     = rh_kmph;
        }

        if(gSpeedDec.has_reference == false)
        {
            /* No history (started already different): fall back on the
             * train acceleration sign. */
            if(gSpeedDec.last_acceleration_mps2 >= 0.0)
            {
                gSpeedDec.pg_slip_state = SPEED_DEC_SLIP_SLIP;
            }
            else
            {
                gSpeedDec.pg_slip_state = SPEED_DEC_SLIP_SLIDE;
            }
        }
        else if(deviating_kmph > other_kmph)
        {
            gSpeedDec.pg_slip_state = SPEED_DEC_SLIP_SLIP;
        }
        else
        {
            gSpeedDec.pg_slip_state = SPEED_DEC_SLIP_SLIDE;
        }
    }

    *state       = gSpeedDec.pg_slip_state;
    *slipping_pg = gSpeedDec.pg_slipping_pg;
}

/* Acceleration of the train speed over each 1 s (33.16). */
static void SpeedDec_CheckAcceleration(const SPEED_DEC_INPUT *input, double train_speed_kmph, uint8_t *state)
{
    *state = SPEED_DEC_SLIP_NONE;

    if(gSpeedDec.accel_has_start == false)
    {
        gSpeedDec.accel_has_start        = true;
        gSpeedDec.accel_start_speed_kmph = train_speed_kmph;
        gSpeedDec.accel_elapsed_s        = 0.0;
    }
    else
    {
        gSpeedDec.accel_elapsed_s += input->dt_s;

        if(gSpeedDec.accel_elapsed_s >= (SPEED_DEC_ACCEL_WINDOW_S - 0.0001))
        {
            gSpeedDec.last_acceleration_mps2 = ((train_speed_kmph - gSpeedDec.accel_start_speed_kmph) / 3.6) /
                                               gSpeedDec.accel_elapsed_s;
            gSpeedDec.accel_start_speed_kmph = train_speed_kmph;
            gSpeedDec.accel_elapsed_s        = 0.0;
        }
    }

    if(gSpeedDec.last_acceleration_mps2 > SPEED_DEC_ACCEL_THRESHOLD_MPS2)
    {
        *state = SPEED_DEC_SLIP_SLIP;
    }
    else if(gSpeedDec.last_acceleration_mps2 < -SPEED_DEC_ACCEL_THRESHOLD_MPS2)
    {
        *state = SPEED_DEC_SLIP_SLIDE;
    }
    else
    {
        ;
    }
}

static void SpeedDec_SlipSlide(const SPEED_DEC_INPUT *input, SPEED_DEC_OUTPUT *output)
{
    uint8_t pg_state    = SPEED_DEC_SLIP_NONE;
    uint8_t accel_state = SPEED_DEC_SLIP_NONE;
    uint8_t slipping_pg = 0U;

    /* acceleration is always tracked so it is valid when needed */
    SpeedDec_CheckAcceleration(input, output->train_speed_kmph, &accel_state);
    output->acceleration_mps2 = gSpeedDec.last_acceleration_mps2;

    output->slip_slide_undetectable_event = false;

    if(output->slip_slide_detectable == true)
    {
        gSpeedDec.undetectable_time_s   = 0.0;
        gSpeedDec.undetectable_reported = false;

        if((output->rh_pg_consistent == true) && (output->lh_pg_consistent == true))
        {
            SpeedDec_CheckPgDifference(input, output->train_speed_kmph, &pg_state, &slipping_pg);
        }
    }
    else
    {
        /* 33.14 / 33.15: "Slip/Slide cannot be detected". Reported once,
         * after it has lasted SPEED_DEC_UNDETECTABLE_CONFIRM_S. */
        accel_state = SPEED_DEC_SLIP_NONE;
        gSpeedDec.pg_slip_state = SPEED_DEC_SLIP_NONE;

        gSpeedDec.undetectable_time_s += input->dt_s;

        if((gSpeedDec.undetectable_time_s >= (SPEED_DEC_UNDETECTABLE_CONFIRM_S - SPEED_DEC_TIME_EPSILON_S)) &&
           (gSpeedDec.undetectable_reported == false))
        {
            gSpeedDec.undetectable_reported       = true;
            output->slip_slide_undetectable_event = true;
        }
    }

    if(pg_state != SPEED_DEC_SLIP_NONE)
    {
        output->slip_state  = pg_state;
        output->slip_source = SPEED_DEC_SOURCE_PG_DIFFERENCE;
        output->slipping_pg = slipping_pg;
    }
    else if(accel_state != SPEED_DEC_SLIP_NONE)
    {
        output->slip_state  = accel_state;
        output->slip_source = SPEED_DEC_SOURCE_ACCELERATION;
        output->slipping_pg = 0U;
    }
    else
    {
        output->slip_state  = SPEED_DEC_SLIP_NONE;
        output->slip_source = SPEED_DEC_SOURCE_NONE;
        output->slipping_pg = 0U;
    }

    /* ---- events and time-out ---- */
    output->slip_detected_event = false;
    output->sr_request_event    = false;

    if(output->slip_state != SPEED_DEC_SLIP_NONE)
    {
        if(gSpeedDec.last_slip_state == SPEED_DEC_SLIP_NONE)
        {
            output->slip_detected_event = true;
            gSpeedDec.slip_time_s       = 0.0;
        }
        else
        {
            gSpeedDec.slip_time_s += input->dt_s;
        }

        if((gSpeedDec.slip_time_s >= (gSpeedDec.config.slip_slide_timeout_s - SPEED_DEC_TIME_EPSILON_S)) &&
           (gSpeedDec.sr_requested == false))
        {
            gSpeedDec.sr_requested   = true;
            output->sr_request_event = true;
        }
    }
    else
    {
        gSpeedDec.slip_time_s  = 0.0;
        gSpeedDec.sr_requested = false;
    }

    output->sr_request        = gSpeedDec.sr_requested;
    gSpeedDec.last_slip_state = output->slip_state;
}

/* ==========================================================================
 * PUBLIC
 * ========================================================================== */

void SpeedDecision_Init(const SPEED_DEC_CONFIG *config)
{
    (void)memset(&gSpeedDec, 0, sizeof(gSpeedDec));
    gSpeedDec.config = *config;
}

void SpeedDecision_Update(const SPEED_DEC_INPUT *input, SPEED_DEC_OUTPUT *output)
{
    (void)memset(output, 0, sizeof(SPEED_DEC_OUTPUT));

    SpeedDec_DetermineSpeed(input, output);
    SpeedDec_UpdateTimers(input, output);
    SpeedDec_SlipSlide(input, output);
}
