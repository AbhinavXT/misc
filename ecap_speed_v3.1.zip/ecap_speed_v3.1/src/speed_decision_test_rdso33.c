#include <stdio.h>
#include <string.h>
#include "speed_decision.h"

static int g_fail=0, g_pass=0;
#define CHECK(cond, ...) do{ if(cond){g_pass++;} else {g_fail++; printf("   FAIL: "); printf(__VA_ARGS__); printf("\n");} }while(0)

static SPEED_DEC_CONFIG cfg = { 3.0, 5.0 };   /* placeholder timeouts */
static SPEED_DEC_OUTPUT out;

static void run(double rha,double lha,double rhb,double lhb,double secs,double dt){
    SPEED_DEC_INPUT in; memset(&in,0,sizeof in);
    in.channel_kmph[SPEED_DEC_CH_RH_A]=rha; in.channel_kmph[SPEED_DEC_CH_LH_A]=lha;
    in.channel_kmph[SPEED_DEC_CH_RH_B]=rhb; in.channel_kmph[SPEED_DEC_CH_LH_B]=lhb;
    for(int i=0;i<4;i++){ in.channel_usable[i]=true; }
    in.dt_s=dt;
    int n=(int)(secs/dt+0.5); for(int i=0;i<n;i++) SpeedDecision_Update(&in,&out);
}
/* table order of 33.1-33.6: a(RH) a(LH) b(RH) b(LH) */
static void speed_case(const char*id,double rha,double lha,double rhb,double lhb,double exp_speed,int exp_fail_mask,int exp_sf){
    printf("%s  a(RH)=%g a(LH)=%g b(RH)=%g b(LH)=%g\n",id,rha,lha,rhb,lhb);
    SpeedDecision_Init(&cfg);
    run(rha,lha,rhb,lhb,1.0,0.1);             /* within timeout */
    CHECK(out.train_speed_kmph==exp_speed, "%s speed %.1f expected %.1f",id,out.train_speed_kmph,exp_speed);
    CHECK(out.system_failure_request==0, "%s SF before timeout",id);
    CHECK(out.failed_channel_mask==0, "%s channel failure before timeout",id);
    run(rha,lha,rhb,lhb,3.0,0.1);             /* past timeout */
    CHECK(out.failed_channel_mask==(exp_sf?0:exp_fail_mask), "%s failed mask 0x%x expected 0x%x",id,out.failed_channel_mask,exp_fail_mask);
    CHECK(out.system_failure_request==exp_sf, "%s SF=%d expected %d",id,out.system_failure_request,exp_sf);
    if(!exp_sf) CHECK(out.train_speed_kmph==exp_speed, "%s speed after timeout %.1f",id,out.train_speed_kmph);
    printf("   -> speed %.0f, comp1 %s comp2 %s, failed 0x%x, SF %d\n",out.train_speed_kmph,out.comparator_1_ok?"OK":"BAD",out.comparator_2_ok?"OK":"BAD",out.failed_channel_mask,out.system_failure_request);
}
/* table order of 33.7-33.15: a(RH) b(RH) a(LH) b(LH) */
static void slip_case(const char*id,double base,double rha,double rhb,double lha,double lhb,int exp_state,int exp_pg,int check_sr,int exp_detectable,int exp_fail_mask){
    printf("%s  base %g, a(RH)=%g b(RH)=%g a(LH)=%g b(LH)=%g\n",id,base,rha,rhb,lha,lhb);
    SpeedDecision_Init(&cfg);
    run(base,base,base,base,3.0,0.1);          /* all equal first */
    int seen_state=0, seen_pg=0, sr_before=0, detect_event=0, undet_event=0;
    SPEED_DEC_INPUT in; memset(&in,0,sizeof in);
    in.channel_kmph[SPEED_DEC_CH_RH_A]=rha; in.channel_kmph[SPEED_DEC_CH_RH_B]=rhb;
    in.channel_kmph[SPEED_DEC_CH_LH_A]=lha; in.channel_kmph[SPEED_DEC_CH_LH_B]=lhb;
    for(int i=0;i<4;i++){ in.channel_usable[i]=true; }
    in.dt_s=0.1;
    for(int i=0;i<40;i++){ SpeedDecision_Update(&in,&out);           /* 4 s < slip timeout */
        if(out.slip_state) {seen_state=out.slip_state; seen_pg=out.slipping_pg;}
        if(out.sr_request){ sr_before=1; }
        if(out.slip_detected_event){ detect_event=1; }
        if(out.slip_slide_undetectable_event) undet_event=1; }
    CHECK(seen_state==exp_state, "%s slip state %d expected %d",id,seen_state,exp_state);
    if(exp_state) { CHECK(seen_pg==exp_pg, "%s slipping pg %d expected %d",id,seen_pg,exp_pg); CHECK(detect_event,"%s no detect event",id); }
    CHECK(sr_before==0, "%s SR before timeout",id);
    CHECK(out.slip_slide_detectable==exp_detectable, "%s detectable %d expected %d",id,out.slip_slide_detectable,exp_detectable);
    if(!exp_detectable) CHECK(undet_event,"%s no 'cannot be detected' event",id);
    int sr_after=0;
    if(check_sr){  /* the "persists for more than time out" variants: 33.11, 33.13 */
        for(int i=0;i<30;i++){ SpeedDecision_Update(&in,&out); if(out.sr_request_event){ sr_after=1; } }
        CHECK(sr_after==(exp_state?1:0), "%s SR after timeout %d",id,sr_after);
    }
    CHECK(out.system_failure_request==0, "%s unexpected SF",id);
    CHECK(out.failed_channel_mask==exp_fail_mask, "%s failed mask 0x%x expected 0x%x",id,out.failed_channel_mask,exp_fail_mask);
    printf("   -> speed %.1f, slip %s (pg %d), detectable %d, SR %d, failed 0x%x\n",out.train_speed_kmph,
        seen_state==1?"SLIP":seen_state==2?"SLIDE":"none",seen_pg,out.slip_slide_detectable,sr_after,out.failed_channel_mask);
}

int main(void){
    const int RHA=1<<SPEED_DEC_CH_RH_A, LHA=1<<SPEED_DEC_CH_LH_A;
    printf("RDSO SIF-0533 v4.22 test 33 (timeouts: speed sense %.0f s, slip/slide %.0f s - placeholders)\n\n",cfg.speed_sense_timeout_s,cfg.slip_slide_timeout_s);
    speed_case("33.1", 80, 80, 80, 80,   80, 0, 0);
    speed_case("33.2",100,100, 99,100,  100, 0, 0);
    speed_case("33.3",112,113,113,112,  113, 0, 0);
    speed_case("33.4",115, 98,115,115,  115, LHA, 0);
    speed_case("33.5",112,125,125,125,  125, RHA, 0);
    speed_case("33.6",160,125,150,125,  160, 0, 1);
    slip_case("33.7", 100,100,100,100,100, 0,0, 0,1,0);
    slip_case("33.8",  50, 50, 50, 50, 50, 0,0, 0,1,0);
    slip_case("33.9", 100,102,102,100,100, 0,0, 0,1,0);
    slip_case("33.10", 50, 50, 50, 53, 53, SPEED_DEC_SLIP_SLIP,2, 0,1,0);
    slip_case("33.11", 50, 50, 50, 53, 53, SPEED_DEC_SLIP_SLIP,2, 1,1,0);
    slip_case("33.12", 50, 50, 50, 47, 47, SPEED_DEC_SLIP_SLIDE,2, 0,1,0);
    slip_case("33.13", 50, 50, 50, 47, 47, SPEED_DEC_SLIP_SLIDE,2, 1,1,0);
    slip_case("33.14",100,105,100,100,100, 0,0, 0,0,RHA);
    slip_case("33.15", 50, 50, 52, 53, 53, 0,0, 0,0,RHA);

    printf("33.16  acceleration ramp, 1 s steps\n");
    SpeedDecision_Init(&cfg);
    run(65,65,65,65,3.0,1.0);
    double ramp[]={65,67,72,77,82,87,92,97}; const char*t[]={"12:24:00","12:24:01","12:24:02","12:24:03","12:24:04","12:24:05","12:24:06","12:24:07"};
    int first_slip=-1, sr_at=-1;
    for(int i=0;i<8;i++){ run(ramp[i],ramp[i],ramp[i],ramp[i],1.0,1.0);
        printf("   %s %2.0f km/h accel %.2f m/s2 slip %d src %d SR %d\n",t[i],ramp[i],out.acceleration_mps2,out.slip_state,out.slip_source,out.sr_request);
        if(out.slip_state && first_slip<0){ first_slip=i; }
        if(out.sr_request_event){ sr_at=i; } }
    CHECK(first_slip==2,"33.16 slip first at index %d expected 2 (12:24:02)",first_slip);
    CHECK(sr_at==7,"33.16 SR at index %d expected 7 (5 s after 12:24:02)",sr_at);

    /* ---- timing: failure / SF exactly at the timeout, not one window early ---- */
    printf("\nTiming (timeout %.1f s, 0.1 s windows)\n", cfg.speed_sense_timeout_s);
    SpeedDecision_Init(&cfg);
    run(115,98,115,115,2.9,0.1);
    CHECK(out.failed_channel_mask==0, "33.4 failed already at 2.9 s");
    run(115,98,115,115,0.1,0.1);
    CHECK(out.failed_channel_mask==LHA && out.new_failed_channel_mask==LHA, "33.4 not failed at 3.0 s (mask 0x%x new 0x%x)",out.failed_channel_mask,out.new_failed_channel_mask);
    run(115,98,115,115,0.1,0.1);
    CHECK(out.new_failed_channel_mask==0, "33.4 failure event repeated");
    printf("   33.4 channel failure raised at 3.0 s, event once\n");
    SpeedDecision_Init(&cfg);
    run(160,125,150,125,2.9,0.1);
    CHECK(out.system_failure_request==0, "33.6 SF already at 2.9 s");
    run(160,125,150,125,0.1,0.1);
    CHECK(out.system_failure_request==1 && out.system_failure_event==1, "33.6 SF not raised at 3.0 s");
    run(80,80,80,80,5.0,0.1);
    CHECK(out.system_failure_request==1, "33.6 SF must stay latched");
    printf("   33.6 System Failure raised at 3.0 s and latched\n");

    /* ---- regression cases outside the RDSO tables ---- */
    printf("\nRegression (not in the RDSO tables)\n");
    /* R1: worn wheels (RH 1.5 %% bigger) then LH-a dies: channel failure, not SF */
    SpeedDecision_Init(&cfg);
    run(101.5,100,101.5,100,3.0,0.1);
    CHECK(out.system_failure_request==0 && out.failed_channel_mask==0, "R1 worn wheels alone must be healthy");
    run(101.5,0,101.5,100,5.0,0.1);
    CHECK(out.system_failure_request==0, "R1 worn wheels + dead LH-a went to SF");
    CHECK(out.failed_channel_mask==LHA, "R1 LH-a not failed (0x%x)", out.failed_channel_mask);
    CHECK(out.decision_case==SPEED_DEC_CASE_C2_WORN_WHEEL, "R1 case %d", out.decision_case);
    CHECK(out.train_speed_kmph==101.5, "R1 speed %.1f", out.train_speed_kmph);
    printf("   R1 worn wheels + dead channel: speed %.1f, failed 0x%x, SF %d\n", out.train_speed_kmph, out.failed_channel_mask, out.system_failure_request);
    /* R2: a channel flickering around the 1 km/h limit is still declared failed */
    SpeedDecision_Init(&cfg);
    { int failed_seen=0; for(int k=0;k<10;k++){ run(100,101.3,100,100,0.5,0.1); if(out.failed_channel_mask) failed_seen=1; run(100,100.9,100,100,0.1,0.1); }
      CHECK(failed_seen, "R2 flickering channel never failed"); }
    printf("   R2 flickering channel (0.5 s bad / 0.1 s good): failed 0x%x\n", out.failed_channel_mask);
    /* R3: a failed channel is cleared only after agreeing for the timeout */
    run(100,100,100,100,2.0,0.1);
    CHECK(out.failed_channel_mask!=0, "R3 failure cleared too early");
    run(100,100,100,100,2.0,0.1);
    CHECK(out.failed_channel_mask==0, "R3 failure never cleared");
    printf("   R3 failure cleared after agreeing again for the timeout\n");
    /* R4: low speed, PGs 0.9 km/h apart (within channel tolerance): no slip */
    SpeedDecision_Init(&cfg);
    run(10,10,10,10,3.0,0.1);
    { int slip=0; for(int k=0;k<20;k++){ run(10.9,10,10.9,10,0.1,0.1); if(out.slip_state) slip=1; }
      CHECK(slip==0, "R4 slip flagged at 10.9 vs 10.0 km/h"); }
    printf("   R4 10.9 vs 10.0 km/h: no slip\n");
    /* R5: one window of disagreement at a start: no 'cannot be detected' event */
    SpeedDecision_Init(&cfg);
    run(0,0,0,0,1.0,0.1);
    { int ev=0; run(5,5,0,5,0.1,0.1); if(out.slip_slide_undetectable_event) ev=1; for(int k=0;k<10;k++){ run(5,5,5,5,0.1,0.1); if(out.slip_slide_undetectable_event) ev=1; }
      CHECK(ev==0, "R5 undetectable event on a start transient"); }
    printf("   R5 start transient: no 'slip/slide cannot be detected' event\n");
    /* R6: alternating (c)/(d) windows still reach System Failure */
    SpeedDecision_Init(&cfg);
    { for(int k=0;k<100;k++){ if(k%3==2) run(160,125,125,125,0.1,0.1); else run(160,125,150,125,0.1,0.1); } }
    CHECK(out.system_failure_request==1, "R6 alternating malfunction never reached SF");
    printf("   R6 malfunction interrupted every 3rd window for 10 s: SF %d\n", out.system_failure_request);

    printf("\nchecks passed %d, failed %d\n",g_pass,g_fail);
    return g_fail?1:0;
}
