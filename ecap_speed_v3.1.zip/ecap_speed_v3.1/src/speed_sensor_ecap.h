/*
 * speed_sensor_ecap.h   (v3.1)
 *
 * Speed, direction and pulse counting for two quadrature pulse generators
 * (PG1 and PG2, each with channel A and channel B) using four ECAP modules
 * on the TI AM263x. One ECAP module per channel: PG1-A, PG1-B, PG2-A, PG2-B.
 *
 * Per channel:  frequency (Hz), speed (m/s), pulses in the window.
 * Per PG:       confirmed direction, net movement in the window (signed,
 *               x4 quadrature decoded), signal-quality counters.
 *
 * No dependency on Kavach globals. The Kavach glue is speed_sensor_user.c.
 *
 * v3 changes (see ECAP_Speed_Code_Explained_updated.md):
 *   1. Both edges are captured (CAP1/CAP3 rising, CAP2/CAP4 falling).
 *      Direction comes from a quadrature state decoder (levels of A and B),
 *      which does not depend on duty cycle and ignores bounce on one channel.
 *   2. Spurious edges are removed by pulse width (a rising edge whose high
 *      time is shorter than a minimum width is a glitch). No "too early"
 *      ratio filter any more, so the filter can never lock.
 *   3. Harvest reads all flagged CAP registers, sorts them by time, and
 *      detects every kind of loss (including exactly 4 lost events).
 *   4. By default NO ECAP interrupts: timestamps are collected by
 *      SpeedEcap_Tick(), called from an existing periodic interrupt or
 *      timer (e.g. the 1 ms RTI / ClockP tick). ECAP interrupts are switched
 *      on automatically only if the tick is too slow for the PPR/max speed.
 *
 * v3.1 (first v3 bench test):
 *   - Glitch filter could lock after a sudden speed step from low speed
 *     (1-3 km/h -> 250 km/h: channels stuck at 0). The minimum width now
 *     follows the actual edge spacing, can never reject twice in a row, and
 *     forgets the old period at a stop.
 *   - Lost-edge check: robust to glitch pairs inside a batch, and only
 *     looks for losses after the previous harvest (ECAP time recorded at
 *     every tick), not since the last (possibly slow) edge.
 */

#ifndef SPEED_SENSOR_ECAP_H
#define SPEED_SENSOR_ECAP_H

#include <stdint.h>
#include <stdbool.h>
#include <kernel/dpl/HwiP.h>
#include <drivers/ecap.h>

/* ==========================================================================
 * TUNABLE PARAMETERS
 * ========================================================================== */

/* ECAP time-base clock: every timestamp tick = 1 / this. AM263x: 200 MHz. */
#define SPEED_ECAP_CLOCK_HZ                     (200000000U)

/* No accepted edge for this long -> channel stopped, speed exactly 0, and
 * no period is ever measured across a longer gap. Lowest visible speed =
 * distance per pulse / timeout (30 PPR, 0.95 m: 0.18 km/h). Max 8000 ms.
 * Why 2 s: see ECAP_Speed_Code_Explained_updated.md, A7. */
#define SPEED_ECAP_STOP_TIMEOUT_MS              (2000U)

/* Direction changes only after this many consecutive quadrature steps in
 * the same direction. One step = 1/4 pulse. 6 steps = 1.5 pulses. */
#define SPEED_ECAP_DIR_CONFIRM_STEPS            (6U)

/* Highest real speed. Used for the glitch limit (x GLITCH_MARGIN) and to
 * check that SpeedEcap_Tick() is called often enough. */
#define SPEED_ECAP_MAX_PLAUSIBLE_SPEED_KMPH     (250.0)
#define SPEED_ECAP_GLITCH_MARGIN                (1.5)

/* ---- Harvesting ---------------------------------------------------------
 * How often the integrator calls SpeedEcap_Tick(), in microseconds.
 * The 4-entry ECAP buffer holds 2 pulse periods (4 edges). The tick must
 * come well within that: required  TICK x HARVEST_MARGIN < 2 x T_min,
 * T_min = pulse period at MAX_PLAUSIBLE_SPEED.
 *   0.95 m wheel, 250 km/h:  1 ms tick is enough up to ~57 PPR,
 *                            0.5 ms tick up to ~115 PPR.            */
#define SPEED_ECAP_TICK_PERIOD_US               (1000U)
#define SPEED_ECAP_HARVEST_MARGIN               (1.5)

/* ECAP capture interrupts:
 *   SPEED_ECAP_IRQ_OFF    never (tick only). If the tick is too slow for
 *                         the PPR, the PG reports fault_harvest.
 *   SPEED_ECAP_IRQ_AUTO   on only if the tick is too slow (default).
 *   SPEED_ECAP_IRQ_ALWAYS always on (about 1 interrupt per pulse period
 *                         per PG), tick still harvests too.
 * For high PPR a faster tick (e.g. 250 us) is usually cheaper than ECAP
 * interrupts: its rate does not grow with speed.                      */
#define SPEED_ECAP_IRQ_OFF                      (0U)
#define SPEED_ECAP_IRQ_AUTO                     (1U)
#define SPEED_ECAP_IRQ_ALWAYS                   (2U)
#define SPEED_ECAP_IRQ_MODE                     (SPEED_ECAP_IRQ_AUTO)

/* Software buffer of events per channel (2 events per pulse). It must hold
 * all events between two SpeedEcap_Service() calls:
 *   30 PPR, 250 km/h -> 1400 events/s -> 512 = 365 ms.
 *   120 PPR, 250 km/h -> 5600 events/s -> 512 = 91 ms.
 * Must be a power of 2. RAM: 5 bytes x size x 4 channels. */
#define SPEED_ECAP_RING_SIZE                    (512U)

/* ---- Glitch (spurious edge) filter --------------------------------------
 * A rising edge is only a real pulse if the signal then stays HIGH for at
 * least the minimum width. Minimum width =
 *   larger of  MIN_PULSE_ABS_PERCENT  of the period at the glitch limit
 *              (30 PPR/0.95 m: 15 % of 0.955 ms = 143 us)
 *   and        MIN_PULSE_PERIOD_PERCENT of the last real period
 *              (only above ADAPTIVE_FILTER_MIN_KMPH).
 * Real pulses are 30..70 % of the period, so neither limit can reject
 * a real pulse. */
#define SPEED_ECAP_MIN_PULSE_ABS_PERCENT        (15U)
#define SPEED_ECAP_MIN_PULSE_PERIOD_PERCENT     (10U)
#define SPEED_ECAP_ADAPTIVE_FILTER_MIN_KMPH     (2.0)

/* Silent-loss check: when all 4 CAP registers are full, the gap before the
 * oldest one is compared with the average spacing of the 4. A gap larger
 * than this many average spacings means 4 (or 8, ...) events were lost. */
#define SPEED_ECAP_SILENT_LOSS_RATIO            (3U)

/* Maximum allowed skew between the ECAP counters right after start. */
#define SPEED_ECAP_MAX_START_SKEW_TICKS         (2000U)

#define SPEED_ECAP_MAX_PG                       (2U)

/* 1 = measure the worst-case CPU cycles of SpeedEcap_Tick() and of the
 * ECAP ISR with CycleCounterP (see SpeedEcap_GetStats()). */
#define SPEED_ECAP_PROFILE                      (0U)

/* ==========================================================================
 * DIRECTION VALUES
 * ========================================================================== */
#define SPEED_ECAP_DIR_UNKNOWN                  ((int8_t)0)
#define SPEED_ECAP_DIR_FORWARD                  ((int8_t)1)
#define SPEED_ECAP_DIR_REVERSE                  ((int8_t)-1)

/* ==========================================================================
 * TYPES
 * ========================================================================== */

/* Hardware wiring of one PG. */
typedef struct
{
    uint32_t                 ecap_base_a;     /* ECAP module for channel A     */
    uint32_t                 ecap_base_b;     /* ECAP module for channel B     */
    ECAP_InputCaptureSignals xbar_input_a;    /* ECAP_INPUT_INPUTXBARn for A   */
    ECAP_InputCaptureSignals xbar_input_b;    /* ECAP_INPUT_INPUTXBARn for B   */
    uint32_t                 int_num_a;       /* R5F interrupt number for A    */
    uint32_t                 int_num_b;       /* R5F interrupt number for B    */
    bool                     invert_direction;/* true if "A leads B" means
                                                 reverse for this PG (mounting) */
} SPEED_ECAP_PG_HW_CONFIG;

/* Result for one channel, once per evaluation window. */
typedef struct
{
    double   frequency_hz;        /* pulse frequency, 0 when stopped          */
    double   speed_mps;           /* wheel surface speed in m/s               */
    uint32_t pulses_in_window;    /* real rising edges (incl. estimated lost) */
    uint32_t glitches_in_window;  /* rising edges rejected as glitches        */
    uint32_t overruns_in_window;  /* times events were lost this window       */
} SPEED_ECAP_CHANNEL_RESULT;

/* Result for one PG, once per evaluation window. */
typedef struct
{
    SPEED_ECAP_CHANNEL_RESULT channel_a;
    SPEED_ECAP_CHANNEL_RESULT channel_b;

    int8_t   direction;               /* confirmed direction, after inversion.
                                         UNKNOWN in a window where A and B do
                                         not behave as a quadrature pair     */

    /* Net movement in this window from the x4 quadrature position counter,
     * in whole pulses (the 1/4-pulse remainder is carried to the next
     * window, so the sum over windows is exact). Use this for distance. */
    uint32_t net_pulses_in_window;
    int8_t   net_direction_in_window; /* sign of the net movement            */

    /* Signal quality of the A/B pair in this window */
    uint32_t quad_errors_in_window;   /* edge with no level change (lost edge)*/
    uint32_t quad_reversals_in_window;/* step direction flipped: bounce on one
                                         channel, a real reversal, or A/B not
                                         a quadrature pair                   */

    bool     fault_config;            /* PPR or wheel diameter invalid       */
    bool     fault_harvest;           /* SpeedEcap_Tick() not called, or too
                                         slow for this PPR with IRQs off     */
    bool     irq_enabled;             /* ECAP interrupts in use for this PG  */
} SPEED_ECAP_PG_RESULT;

/* Diagnostics */
typedef struct
{
    uint32_t tick_calls;              /* SpeedEcap_Tick() calls              */
    uint32_t irq_calls;               /* ECAP interrupts taken               */
    uint32_t events_harvested;        /* timestamps copied (all channels)    */
    uint32_t max_tick_cycles;         /* worst Tick() duration, CPU cycles
                                         (only with SPEED_ECAP_PROFILE = 1)  */
    uint32_t max_irq_cycles;          /* worst ISR duration, CPU cycles      */
} SPEED_ECAP_STATS;

/* ==========================================================================
 * API
 * ========================================================================== */

/*
 * Configure the ECAPs, register (but do not enable) the capture interrupts,
 * zero and start all counters together. Call ONCE after Drivers_open().
 */
int32_t SpeedEcap_Init(const SPEED_ECAP_PG_HW_CONFIG hw_config[], uint32_t num_pg);

/*
 * Copy new timestamps from the ECAP registers into the software buffers.
 * Call every SPEED_ECAP_TICK_PERIOD_US from a periodic context: an existing
 * timer ISR (RTI) or a ClockP callback. Short (a few register reads per
 * channel), safe in ISR context, takes its own short critical section.
 */
void SpeedEcap_Tick(void);

/*
 * Process buffered edges (filters, quadrature decoder, speed chain).
 * Call from the main loop / speed task, at least every 50 ms. MUST run in
 * the same task as SpeedEcap_Evaluate().
 */
void SpeedEcap_Service(void);

/*
 * Evaluate one PG: speeds, pulses, direction, net movement, quality.
 * Call once per PG per window, at a fixed rate, from the same task as
 * SpeedEcap_Service().
 */
void SpeedEcap_Evaluate(uint32_t pg_index,
                        uint16_t pulses_per_rev,
                        double   wheel_dia_m,
                        SPEED_ECAP_PG_RESULT *result);

void SpeedEcap_GetStats(SPEED_ECAP_STATS *stats);

#endif /* SPEED_SENSOR_ECAP_H */
