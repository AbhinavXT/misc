/*
 * speed_sensor_user.c   (v3)
 *
 * Kavach glue: turns the ECAP module results (speed_sensor_ecap.c) and the
 * RDSO test-33 decisions (speed_decision.c) into the loco_params /
 * loco_mode_transition_conditions fields the rest of the firmware uses,
 * then hands the pulse counts to CalculateTrainSpeedEQEP() so distance,
 * rollback, TLM and location logic keep working.
 *
 * Integration: KAVACH_ECAP_Integration_Guide.md.
 */

#include "common_include.h"
#include "ti_drivers_config.h"
#include "speed_sensor_ecap.h"
#include "speed_decision.h"
#include "speed_sensor_user.h"

/* ==========================================================================
 * WIRING
 * ========================================================================== */

#define SPEED_SENSOR_PG1_INDEX      (0U)
#define SPEED_SENSOR_PG2_INDEX      (1U)
#define SPEED_SENSOR_NUM_PG         (2U)

/*
 * invert_direction: the ECAP module reports FORWARD when channel A leads
 * channel B. If on a PG "A leads B" happens when the loco moves in the
 * REVERSE direction, set invert_direction = true for that PG. RH and LH
 * PGs sit on opposite sides of the loco, so one of them is often mirrored.
 * Decide on the loco (integration guide, "Calibration").
 */
static const SPEED_ECAP_PG_HW_CONFIG gSpeedSensorPgConfig[SPEED_SENSOR_NUM_PG] =
{
    /* PG1 (RH) */
    {
        .ecap_base_a      = CONFIG_ECAP0_BASE_ADDR,
        .ecap_base_b      = CONFIG_ECAP1_BASE_ADDR,
        .xbar_input_a     = ECAP_INPUT_INPUTXBAR0,
        .xbar_input_b     = ECAP_INPUT_INPUTXBAR1,
        .int_num_a        = CSLR_R5FSS0_CORE0_CONTROLSS_INTRXBAR0_OUT_22,
        .int_num_b        = CSLR_R5FSS0_CORE0_CONTROLSS_INTRXBAR0_OUT_23,
        .invert_direction = false
    },
    /* PG2 (LH) */
    {
        .ecap_base_a      = CONFIG_ECAP2_BASE_ADDR,
        .ecap_base_b      = CONFIG_ECAP3_BASE_ADDR,
        .xbar_input_a     = ECAP_INPUT_INPUTXBAR2,
        .xbar_input_b     = ECAP_INPUT_INPUTXBAR3,
        .int_num_a        = CSLR_R5FSS0_CORE0_CONTROLSS_INTRXBAR0_OUT_24,
        .int_num_b        = CSLR_R5FSS0_CORE0_CONTROLSS_INTRXBAR0_OUT_25,
        .invert_direction = false
    }
};

/* ==========================================================================
 * PRIVATE DATA / PROTOTYPES
 * ========================================================================== */

static volatile bool    gSpeedSensorInitDone = false;
static double           gSpeedSensorTrainSpeedKmph = 0.0;
static SPEED_DEC_OUTPUT gSpeedSensorDecision;
static uint32_t         gSpeedSensorDirMismatchWindows = 0U;

static void     SpeedSensor_RunDecision(const SPEED_ECAP_PG_RESULT *pg1_result,
                                        const SPEED_ECAP_PG_RESULT *pg2_result);
static bool     SpeedSensor_PgHasSuspectChannel(uint32_t pg_index);
static int8_t   SpeedSensor_SelectDirection(const SPEED_ECAP_PG_RESULT *pg1_result,
                                            const SPEED_ECAP_PG_RESULT *pg2_result);
static void     SpeedSensor_ApplyDirection(int8_t direction);
static uint32_t SpeedSensor_RawPulses(const SPEED_ECAP_PG_RESULT *pg_result);
static void     SpeedSensor_PublishHealth(const SPEED_ECAP_PG_RESULT *pg1_result,
                                          const SPEED_ECAP_PG_RESULT *pg2_result);
static void     SpeedSensor_ReportDecisionEvents(void);
static void     SpeedSensor_LogPg(const char *label, const SPEED_ECAP_PG_RESULT *pg_result);

/* ==========================================================================
 * PUBLIC
 * ========================================================================== */

int32_t SpeedSensor_Init(void)
{
    int32_t status;

    status = SpeedEcap_Init(gSpeedSensorPgConfig, SPEED_SENSOR_NUM_PG);

    if(status == SystemP_SUCCESS)
    {
        SPEED_ECAP_PG_RESULT discard_result;
        SPEED_DEC_CONFIG     decision_config;

        /* One evaluation right away so the filters know PPR and wheel
         * diameter (loco_info must already be loaded). */
        SpeedEcap_Evaluate(SPEED_SENSOR_PG1_INDEX, loco_info.tacho_output_pulse_per_rev1,
                           ((double)loco_info.loco_wheel_dia1) / 1000.0, &discard_result);
        SpeedEcap_Evaluate(SPEED_SENSOR_PG2_INDEX, loco_info.tacho_output_pulse_per_rev2,
                           ((double)loco_info.loco_wheel_dia2) / 1000.0, &discard_result);

        decision_config.speed_sense_timeout_s = SPEED_SENSOR_SPEED_SENSE_TIMEOUT_S;
        decision_config.slip_slide_timeout_s  = SPEED_SENSOR_SLIP_SLIDE_TIMEOUT_S;
        SpeedDecision_Init(&decision_config);

        gSpeedSensorInitDone = true;
        EQEP_PRINTF("SPEED ECAP INIT OK\n");
    }
    else
    {
        gSpeedSensorInitDone = false;
        EQEP_PRINTF("SPEED ECAP INIT FAILED\n");
    }

    return status;
}

/* From the 1 ms tick (RTI ISR or ClockP callback). A few register reads. */
void SpeedSensor_Tick(void)
{
    if(gSpeedSensorInitDone == true)
    {
        SpeedEcap_Tick();
    }
}

void SpeedSensor_Service(void)
{
    if(gSpeedSensorInitDone == true)
    {
        SpeedEcap_Service();
    }
}

void CalculateWheelSpeed_ECAP(void)
{
    SPEED_ECAP_PG_RESULT pg1_result;
    SPEED_ECAP_PG_RESULT pg2_result;
    uint32_t pg1_pulses;
    uint32_t pg2_pulses;

    if(gSpeedSensorInitDone == false)
    {
        loco_mode_transition_conditions.is_speed_sensor_fail = 1;
        return;
    }

    /* ---- 1. Measure both PGs ---- */
    SpeedEcap_Evaluate(SPEED_SENSOR_PG1_INDEX, loco_info.tacho_output_pulse_per_rev1,
                       ((double)loco_info.loco_wheel_dia1) / 1000.0, &pg1_result);
    SpeedEcap_Evaluate(SPEED_SENSOR_PG2_INDEX, loco_info.tacho_output_pulse_per_rev2,
                       ((double)loco_info.loco_wheel_dia2) / 1000.0, &pg2_result);

    /* ---- 2. Per channel speeds (m/s) ---- */
    loco_params.speed_sensor1_1 = pg1_result.channel_a.speed_mps;
    loco_params.speed_sensor1_2 = pg1_result.channel_b.speed_mps;
    loco_params.speed_sensor2_1 = pg2_result.channel_a.speed_mps;
    loco_params.speed_sensor2_2 = pg2_result.channel_b.speed_mps;

    /* ---- 3. RDSO test 33 decisions ---- */
    SpeedSensor_RunDecision(&pg1_result, &pg2_result);

    /* ---- 4. Direction ---- */
    SpeedSensor_ApplyDirection(SpeedSensor_SelectDirection(&pg1_result, &pg2_result));

    /* ---- 5. Distance pulses: net quadrature movement of each PG. A PG
     *         with a suspect channel has no valid A/B pair, so it takes the
     *         other PG's count. ---- */
    pg1_pulses = pg1_result.net_pulses_in_window;
    pg2_pulses = pg2_result.net_pulses_in_window;

    if((SpeedSensor_PgHasSuspectChannel(SPEED_SENSOR_PG1_INDEX) == true) &&
       (SpeedSensor_PgHasSuspectChannel(SPEED_SENSOR_PG2_INDEX) == false))
    {
        pg1_pulses = pg2_pulses;
    }
    else if((SpeedSensor_PgHasSuspectChannel(SPEED_SENSOR_PG2_INDEX) == true) &&
            (SpeedSensor_PgHasSuspectChannel(SPEED_SENSOR_PG1_INDEX) == false))
    {
        pg2_pulses = pg1_pulses;
    }
    else
    {
        ;
    }

    /* Pulse-zero flags from the RAW channel pulses (a turning wheel always
     * produces them, even when its A/B pair cannot be decoded). */
    loco_mode_transition_conditions.is_pg1_pulse_zero = (SpeedSensor_RawPulses(&pg1_result) == 0U) ? 1 : 0;
    loco_mode_transition_conditions.is_pg2_pulse_zero = (SpeedSensor_RawPulses(&pg2_result) == 0U) ? 1 : 0;

    SpeedSensor_LogPg("PG1", &pg1_result);
    SpeedSensor_LogPg("PG2", &pg2_result);

    /* ---- 6. Existing distance / rollback / TLM chain ----
     * Its own PG1-vs-PG2 ">= 5 km/h -> sensor fail" rule and its own
     * slip/skid rule must be removed (integration guide, step 6). */
    CalculateTrainSpeedEQEP((double)pg1_pulses, (double)pg2_pulses);

    /* ---- 7. Health and events. AFTER CalculateTrainSpeedEQEP(), which
     *         resets is_speed_sensor_fail. ---- */
    SpeedSensor_PublishHealth(&pg1_result, &pg2_result);
    SpeedSensor_ReportDecisionEvents();
}

double SpeedSensor_GetTrainSpeedKmph(void)
{
    return gSpeedSensorTrainSpeedKmph;
}

const SPEED_DEC_OUTPUT *SpeedSensor_GetDecision(void)
{
    return &gSpeedSensorDecision;
}

/* ==========================================================================
 * PRIVATE
 * ========================================================================== */

/*
 * A channel is unusable for the decision when its PG has a config fault,
 * timestamps are not being collected (fault_harvest), or it lost edges in
 * this window (its speed for this window is then a fallback value).
 */
static void SpeedSensor_RunDecision(const SPEED_ECAP_PG_RESULT *pg1_result,
                                    const SPEED_ECAP_PG_RESULT *pg2_result)
{
    SPEED_DEC_INPUT input;
    bool pg1_ok = (pg1_result->fault_config == false) && (pg1_result->fault_harvest == false);
    bool pg2_ok = (pg2_result->fault_config == false) && (pg2_result->fault_harvest == false);

    input.channel_kmph[SPEED_DEC_CH_RH_A] = pg1_result->channel_a.speed_mps * MPS_TO_KMPH;
    input.channel_kmph[SPEED_DEC_CH_RH_B] = pg1_result->channel_b.speed_mps * MPS_TO_KMPH;
    input.channel_kmph[SPEED_DEC_CH_LH_A] = pg2_result->channel_a.speed_mps * MPS_TO_KMPH;
    input.channel_kmph[SPEED_DEC_CH_LH_B] = pg2_result->channel_b.speed_mps * MPS_TO_KMPH;

    input.channel_usable[SPEED_DEC_CH_RH_A] = pg1_ok && (pg1_result->channel_a.overruns_in_window == 0U);
    input.channel_usable[SPEED_DEC_CH_RH_B] = pg1_ok && (pg1_result->channel_b.overruns_in_window == 0U);
    input.channel_usable[SPEED_DEC_CH_LH_A] = pg2_ok && (pg2_result->channel_a.overruns_in_window == 0U);
    input.channel_usable[SPEED_DEC_CH_LH_B] = pg2_ok && (pg2_result->channel_b.overruns_in_window == 0U);

    input.dt_s = (double)SPEED_SAMPLING_TIME;

    SpeedDecision_Update(&input, &gSpeedSensorDecision);

    gSpeedSensorTrainSpeedKmph = gSpeedSensorDecision.train_speed_kmph;
}

static bool SpeedSensor_PgHasSuspectChannel(uint32_t pg_index)
{
    uint8_t pg_mask;

    if(pg_index == SPEED_SENSOR_PG1_INDEX)
    {
        pg_mask = (uint8_t)(SPEED_DEC_MASK(SPEED_DEC_CH_RH_A) | SPEED_DEC_MASK(SPEED_DEC_CH_RH_B));
    }
    else
    {
        pg_mask = (uint8_t)(SPEED_DEC_MASK(SPEED_DEC_CH_LH_A) | SPEED_DEC_MASK(SPEED_DEC_CH_LH_B));
    }

    return ((gSpeedSensorDecision.suspect_channel_mask & pg_mask) != 0U);
}

static uint32_t SpeedSensor_RawPulses(const SPEED_ECAP_PG_RESULT *pg_result)
{
    uint32_t pulses = pg_result->channel_a.pulses_in_window;

    if(pg_result->channel_b.pulses_in_window > pulses)
    {
        pulses = pg_result->channel_b.pulses_in_window;
    }

    return pulses;
}

/*
 * Both PGs sit on the same loco, so they must agree on direction.
 * A PG does not vote when it has a suspect channel (RDSO 33.4/33.5/33.14/
 * 33.15: A and B at different frequencies) or when its own A/B pair did not
 * behave as quadrature this window (the ECAP module then reports UNKNOWN).
 *   - both known and equal     -> use it
 *   - both known and different -> keep the previous direction, count the
 *                                 mismatch, hook after N windows
 *   - one known                -> use it
 *   - none known               -> keep the previous direction (as EQEP)
 */
static int8_t SpeedSensor_SelectDirection(const SPEED_ECAP_PG_RESULT *pg1_result,
                                          const SPEED_ECAP_PG_RESULT *pg2_result)
{
    int8_t pg1_direction = pg1_result->direction;
    int8_t pg2_direction = pg2_result->direction;
    int8_t selected      = SPEED_ECAP_DIR_UNKNOWN;

    if(SpeedSensor_PgHasSuspectChannel(SPEED_SENSOR_PG1_INDEX) == true)
    {
        pg1_direction = SPEED_ECAP_DIR_UNKNOWN;
    }
    if(SpeedSensor_PgHasSuspectChannel(SPEED_SENSOR_PG2_INDEX) == true)
    {
        pg2_direction = SPEED_ECAP_DIR_UNKNOWN;
    }

    if((pg1_direction != SPEED_ECAP_DIR_UNKNOWN) && (pg2_direction != SPEED_ECAP_DIR_UNKNOWN) &&
       (pg1_direction != pg2_direction))
    {
        if(gSpeedSensorDirMismatchWindows < 0xFFFFU)
        {
            gSpeedSensorDirMismatchWindows++;
        }
        if(gSpeedSensorDirMismatchWindows == SPEED_SENSOR_DIR_MISMATCH_WINDOWS)
        {
            SpeedSensor_HookDirectionMismatch(pg1_direction, pg2_direction);
        }
    }
    else
    {
        gSpeedSensorDirMismatchWindows = 0U;
        selected = (pg1_direction != SPEED_ECAP_DIR_UNKNOWN) ? pg1_direction : pg2_direction;
    }

    return selected;
}

/* UNKNOWN leaves loco_params.sensor_direction as it was (last known). */
static void SpeedSensor_ApplyDirection(int8_t direction)
{
    if(direction == SPEED_ECAP_DIR_FORWARD)
    {
        loco_params.sensor_direction = NOMINAL_DIR;
    }
    else if(direction == SPEED_ECAP_DIR_REVERSE)
    {
        loco_params.sensor_direction = REVERSE_DIR;
    }
    else
    {
        ;
    }
}

/*
 * PG health for loco_health: a PG is unhealthy when one of its channels has
 * FAILED (disagreed longer than the speed-sense timeout), or its
 * configuration is invalid, or its timestamps are not being collected.
 * System Failure is raised only by the RDSO decision (33.6).
 */
static void SpeedSensor_PublishHealth(const SPEED_ECAP_PG_RESULT *pg1_result,
                                      const SPEED_ECAP_PG_RESULT *pg2_result)
{
    const uint8_t rh_mask = (uint8_t)(SPEED_DEC_MASK(SPEED_DEC_CH_RH_A) | SPEED_DEC_MASK(SPEED_DEC_CH_RH_B));
    const uint8_t lh_mask = (uint8_t)(SPEED_DEC_MASK(SPEED_DEC_CH_LH_A) | SPEED_DEC_MASK(SPEED_DEC_CH_LH_B));

    loco_params.loco_health.speed_sensor1_health =
        (((gSpeedSensorDecision.failed_channel_mask & rh_mask) == 0U) &&
         (pg1_result->fault_config == false) && (pg1_result->fault_harvest == false)) ? 1 : 0;

    loco_params.loco_health.speed_sensor2_health =
        (((gSpeedSensorDecision.failed_channel_mask & lh_mask) == 0U) &&
         (pg2_result->fault_config == false) && (pg2_result->fault_harvest == false)) ? 1 : 0;
}

/*
 * Decision events -> application actions, each once per event. System
 * Failure is re-asserted every window because CalculateTrainSpeedEQEP()
 * clears is_speed_sensor_fail.
 */
static void SpeedSensor_ReportDecisionEvents(void)
{
    uint32_t channel;

    for(channel = 0U; channel < SPEED_DEC_NUM_CHANNELS; channel++)
    {
        if((gSpeedSensorDecision.new_failed_channel_mask & SPEED_DEC_MASK(channel)) != 0U)
        {
            SpeedSensor_HookChannelFailure((uint8_t)channel);
        }
    }

    if(gSpeedSensorDecision.system_failure_request == true)
    {
        loco_mode_transition_conditions.is_speed_sensor_fail = 1;
        data_logger_conditions.is_both_speed_sensor_fail     = 1;

        if(gSpeedSensorDecision.system_failure_event == true)
        {
            SpeedSensor_HookSystemFailure();
        }
    }

    if(gSpeedSensorDecision.slip_slide_undetectable_event == true)
    {
        SpeedSensor_HookSlipSlideUndetectable();
    }

    if(gSpeedSensorDecision.slip_detected_event == true)
    {
        SpeedSensor_HookSlipSlideDetected(gSpeedSensorDecision.slip_state,
                                          gSpeedSensorDecision.slip_source,
                                          gSpeedSensorDecision.slipping_pg);
    }

    if(gSpeedSensorDecision.sr_request_event == true)
    {
        SpeedSensor_HookSlipSlideTimeout(gSpeedSensorDecision.slip_state);
    }
}

/* ==========================================================================
 * DEFAULT HOOKS - connect to event logger, NMS, DMI and mode manager.
 * ========================================================================== */

static const char *SpeedSensor_ChannelName(uint8_t channel)
{
    static const char *const names[SPEED_DEC_NUM_CHANNELS] =
    {
        "Channel a (RH PG)", "Channel b (RH PG)", "Channel a (LH PG)", "Channel b (LH PG)"
    };

    return (channel < SPEED_DEC_NUM_CHANNELS) ? names[channel] : "?";
}

static const char *SpeedSensor_SlipName(uint8_t state)
{
    return (state == SPEED_DEC_SLIP_SLIP) ? "SLIP" : "SLIDE";
}

/* 33.4, 33.5, 33.14, 33.15. TODO: event logger entry + NMS message. */
void SpeedSensor_HookChannelFailure(uint8_t channel)
{
    MISC_PRINTF("SPEED CHANNEL FAILURE: %s\n", SpeedSensor_ChannelName(channel));
}

/* 33.6. is_speed_sensor_fail is already set by the caller.
 * TODO: event logger entry + NMS message. */
void SpeedSensor_HookSystemFailure(void)
{
    MISC_PRINTF("SPEED DETERMINATION MALFUNCTION -> SYSTEM FAILURE\n");
}

/* 33.15. TODO: event logger entry + NMS message. */
void SpeedSensor_HookSlipSlideUndetectable(void)
{
    MISC_PRINTF("SLIP/SLIDE CANNOT BE DETECTED\n");
}

/* 33.10, 33.12, 33.16. TODO: show on DMI; for slide also event logger + NMS. */
void SpeedSensor_HookSlipSlideDetected(uint8_t state, uint8_t source, uint8_t pg)
{
    MISC_PRINTF("%s DETECTED source:[%u] pg:[%u]\n", SpeedSensor_SlipName(state), source, pg);
}

/* 33.11, 33.13, 33.16. TODO: prompt SR mode erasing direction, event
 * logger + NMS. */
void SpeedSensor_HookSlipSlideTimeout(uint8_t state)
{
    MISC_PRINTF("%s TIMEOUT -> SR MODE PROMPT (ERASE DIRECTION)\n", SpeedSensor_SlipName(state));
}

/* Not part of test 33: both usable PGs report opposite directions for
 * SPEED_SENSOR_DIR_MISMATCH_WINDOWS windows. System team to decide the
 * action (log, NMS, erase direction). */
void SpeedSensor_HookDirectionMismatch(int8_t pg1_direction, int8_t pg2_direction)
{
    MISC_PRINTF("PG DIRECTION MISMATCH PG1:[%d] PG2:[%d]\n", pg1_direction, pg2_direction);
}

/*
 * One line per PG and window:
 * PG1 A:[f Hz v kmph n p] B:[...] NET:[n p dir d] DIR:[d] QE:[e] QR:[r] GL:[a/b] OVR:[a/b] H:[h] IRQ:[i] CASE:[c]
 */
static void SpeedSensor_LogPg(const char *label, const SPEED_ECAP_PG_RESULT *pg_result)
{
    EQEP_PRINTF("%s A:[%.2f Hz %.2f kmph %u p] B:[%.2f Hz %.2f kmph %u p] NET:[%u p dir %d] DIR:[%d] "
                "QE:[%u] QR:[%u] GL:[%u/%u] OVR:[%u/%u] H:[%d] IRQ:[%d] CASE:[%u]\n",
                label,
                pg_result->channel_a.frequency_hz,
                pg_result->channel_a.speed_mps * MPS_TO_KMPH,
                pg_result->channel_a.pulses_in_window,
                pg_result->channel_b.frequency_hz,
                pg_result->channel_b.speed_mps * MPS_TO_KMPH,
                pg_result->channel_b.pulses_in_window,
                pg_result->net_pulses_in_window,
                pg_result->net_direction_in_window,
                pg_result->direction,
                pg_result->quad_errors_in_window,
                pg_result->quad_reversals_in_window,
                pg_result->channel_a.glitches_in_window,
                pg_result->channel_b.glitches_in_window,
                pg_result->channel_a.overruns_in_window,
                pg_result->channel_b.overruns_in_window,
                (pg_result->fault_harvest == true) ? 1 : 0,
                (pg_result->irq_enabled == true) ? 1 : 0,
                gSpeedSensorDecision.decision_case);
}
