/*
 * speed_decision.h
 *
 * Train speed determination, channel failure, speed-sensor malfunction and
 * slip/slide detection from the 4 PG channel speeds, as required by
 * RDSO SIF-0533 v4.22, test case 33 (Processing of Train Speed), 33.1-33.16.
 *
 * Pure logic: no hardware, no Kavach globals. Input = 4 channel speeds in
 * km/h (from speed_sensor_ecap.c), output = decisions. The Kavach glue
 * (speed_sensor_user.c) maps the outputs to modes, DMI, event logger, NMS.
 *
 * Channel naming follows the RDSO tables:
 *      Channel a (RH PG) = PG1 channel A      Channel b (RH PG) = PG1 channel B
 *      Channel a (LH PG) = PG2 channel A      Channel b (LH PG) = PG2 channel B
 *      Comparator 1 = Channel a (RH PG) vs Channel a (LH PG)
 *      Comparator 2 = Channel b (RH PG) vs Channel b (LH PG)
 */

#ifndef SPEED_DECISION_H
#define SPEED_DECISION_H

#include <stdint.h>
#include <stdbool.h>

/* ==========================================================================
 * FIXED BY THE SPECIFICATION
 * ========================================================================== */

/* Two inputs agree if they differ by NOT more than 1 km/h (33.1-33.6:
 * "threshold difference is greater than 1 kmph"). */
#define SPEED_DEC_CHANNEL_TOLERANCE_KMPH    (1.0)

/* Measurement margin added to the 1 km/h tolerance. The ECAP speed of a
 * channel is exact to about 0.001 km/h, but not to 0.000: on the bench,
 * channels set exactly 1 km/h apart (33.2, 33.3) measure e.g. 1.0006 km/h
 * apart and would "disagree". 0.05 km/h is far below anything that matters
 * for supervision. */
#define SPEED_DEC_MEASUREMENT_MARGIN_KMPH   (0.05)

/* Slip/slide from PG difference: more than 5 km/h or 5 % of speed,
 * whichever is lower (requirement 4). */
#define SPEED_DEC_SLIP_MAX_KMPH             (5.0)
#define SPEED_DEC_SLIP_PERCENT              (5.0)

/* Lower limit for the PG-difference slip/slide threshold. Below 20 km/h,
 * 5 % of speed is smaller than the 1 km/h the channels themselves are
 * allowed to differ by, so two PGs that "agree" could already be "slip".
 * 1.0 = never flag slip/slide for a difference the comparators accept.
 * Set to 0.0 to follow requirement 4 literally. CONFIRM WITH RDSO. */
#define SPEED_DEC_SLIP_MIN_KMPH             (1.0)

/* The "slip/slide cannot be detected" event (33.15, log + NMS) is raised
 * only when the condition lasts this long, so that the one or two windows
 * of disagreement at every start and stop do not send an NMS message. */
#define SPEED_DEC_UNDETECTABLE_CONFIRM_S    (1.0)

/* Slip/slide from acceleration (33.16: threshold acceleration 1 m/s^2),
 * evaluated over 1 s of train speed. */
#define SPEED_DEC_ACCEL_THRESHOLD_MPS2      (1.0)
#define SPEED_DEC_ACCEL_WINDOW_S            (1.0)

/* ==========================================================================
 * TYPES
 * ========================================================================== */

#define SPEED_DEC_CH_RH_A       (0U)
#define SPEED_DEC_CH_RH_B       (1U)
#define SPEED_DEC_CH_LH_A       (2U)
#define SPEED_DEC_CH_LH_B       (3U)
#define SPEED_DEC_NUM_CHANNELS  (4U)

#define SPEED_DEC_MASK(ch)      ((uint8_t)(1U << (ch)))

#define SPEED_DEC_SLIP_NONE     (0U)
#define SPEED_DEC_SLIP_SLIP     (1U)    /* a wheel reads too fast (spin)  */
#define SPEED_DEC_SLIP_SLIDE    (2U)    /* a wheel reads too slow (lock)  */

/* Which rule decided the speed (for the log) */
#define SPEED_DEC_CASE_A_COMPARATORS    (0U)    /* both comparators agree        */
#define SPEED_DEC_CASE_B_PG_DIFFERENCE  (1U)    /* both PGs agree internally     */
#define SPEED_DEC_CASE_C_ONE_COMPARATOR (2U)    /* one comparator agrees         */
#define SPEED_DEC_CASE_C2_WORN_WHEEL    (3U)    /* one PG agrees + one channel of
                                                   the other PG within the PG
                                                   difference limit              */
#define SPEED_DEC_CASE_D_MALFUNCTION    (4U)    /* nothing agrees                */

#define SPEED_DEC_SOURCE_NONE           (0U)
#define SPEED_DEC_SOURCE_PG_DIFFERENCE  (1U)    /* 33.10 - 33.13 */
#define SPEED_DEC_SOURCE_ACCELERATION   (2U)    /* 33.16         */

/* Time-outs are system parameters from the FRS / loco configuration.
 * The spec pages only say "time out"; take the values from your
 * configuration, do not hard-code them. */
typedef struct
{
    double speed_sense_timeout_s;   /* channel failure log and System Failure */
    double slip_slide_timeout_s;    /* slip/slide -> SR mode prompt           */
} SPEED_DEC_CONFIG;

typedef struct
{
    double channel_kmph[SPEED_DEC_NUM_CHANNELS];
    bool   channel_usable[SPEED_DEC_NUM_CHANNELS];  /* false = treat as failed
                                                       (e.g. ECAP config fault) */
    double dt_s;                                    /* time since last call     */
} SPEED_DEC_INPUT;

typedef struct
{
    /* ---- speed determination (33.1 - 33.6) ---- */
    double  train_speed_kmph;           /* speed to use and send to stationary  */
    uint8_t decision_case;              /* SPEED_DEC_CASE_xxx                   */
    bool    comparator_1_ok;            /* RH-a vs LH-a within 1 km/h           */
    bool    comparator_2_ok;            /* RH-b vs LH-b within 1 km/h           */
    bool    rh_pg_consistent;           /* RH-a vs RH-b within 1 km/h           */
    bool    lh_pg_consistent;           /* LH-a vs LH-b within 1 km/h           */

    uint8_t suspect_channel_mask;       /* channels disagreeing right now       */
    uint8_t failed_channel_mask;        /* disagreeing longer than the timeout
                                           (cleared again only after the channel
                                           has agreed for as long as it had
                                           disagreed: leaky timer)              */
    uint8_t new_failed_channel_mask;    /* became failed in THIS call:
                                           log in event logger + NMS message    */

    bool    speed_malfunction;          /* no valid speed determination now     */
    bool    system_failure_request;     /* malfunction longer than timeout:
                                           go to System Failure, log, NMS
                                           (latched until SpeedDecision_Init)   */
    bool    system_failure_event;       /* true only in the call it latched     */

    /* ---- slip / slide (33.7 - 33.16) ---- */
    bool    slip_slide_detectable;      /* false when a channel is suspect
                                           (33.14, 33.15)                       */
    bool    slip_slide_undetectable_event; /* undetectable for
                                              SPEED_DEC_UNDETECTABLE_CONFIRM_S,
                                              raised once: log + NMS (33.15)    */
    uint8_t slip_state;                 /* SPEED_DEC_SLIP_xxx                   */
    uint8_t slip_source;                /* SPEED_DEC_SOURCE_xxx                 */
    uint8_t slipping_pg;                /* 0 none, 1 RH, 2 LH (PG difference)   */
    bool    slip_detected_event;        /* started in THIS call: show on DMI
                                           (slide: also log + NMS, 33.12)       */
    bool    sr_request;                 /* slip/slide lasted longer than the
                                           timeout: prompt SR erasing direction,
                                           log, NMS (stays true while it lasts) */
    bool    sr_request_event;           /* true only in the call it started     */
    double  acceleration_mps2;          /* last 1 s acceleration of train speed */
} SPEED_DEC_OUTPUT;

/* ==========================================================================
 * API
 * ========================================================================== */

void SpeedDecision_Init(const SPEED_DEC_CONFIG *config);

/* Call once per speed window, after SpeedEcap_Evaluate() for both PGs. */
void SpeedDecision_Update(const SPEED_DEC_INPUT *input, SPEED_DEC_OUTPUT *output);

#endif /* SPEED_DECISION_H */
