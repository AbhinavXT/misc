/*
 * ecap_speed_test.c   (v3)
 *
 * Bench test for speed_sensor_ecap.c on the CCS project
 * "ECAP_4ch_4intr_ok_Meadin_in_Test".
 *
 *   1. Exclude ecap_capture_pwm.c from the build.
 *   2. Add speed_sensor_ecap.c / .h and this file.
 *   3. main.c keeps calling ecap_capture_pwm_main(NULL).
 *   4. syscfg unchanged (4 ECAP instances, Input XBAR on GPIO33/34/119/120,
 *      Interrupt XBAR 22..25). SpeedEcap_Init() reconfigures the ECAPs.
 *
 * Feed: PG1-A -> GPIO33, PG1-B -> GPIO34, PG2-A -> GPIO119, PG2-B -> GPIO120.
 *
 * Timestamps are collected by SpeedEcap_Tick() from a 1 ms ClockP callback
 * (no ECAP interrupts at 30 PPR). Every TEST_PRINT_PERIOD_MS one line per PG
 * and one line of statistics are printed.
 */

#include <stdint.h>
#include <stdbool.h>
#include <kernel/dpl/DebugP.h>
#include <kernel/dpl/ClockP.h>
#include <kernel/dpl/SystemP.h>
#include "ti_drivers_config.h"
#include "ti_drivers_open_close.h"
#include "ti_board_open_close.h"
#include "speed_sensor_ecap.h"

/* MUST match the PG / generator. Your board logs (14.0 Hz = 5.00 km/h)
 * are 30 PPR with a 0.95 m wheel. */
#define TEST_PULSES_PER_REV        (30U)
#define TEST_WHEEL_DIAMETER_M      (0.95)
#define TEST_PRINT_PERIOD_MS       (1000U)
#define TEST_MPS_TO_KMPH           (3.6)

static const SPEED_ECAP_PG_HW_CONFIG gTestPgConfig[2] =
{
    {
        .ecap_base_a      = CONFIG_ECAP0_BASE_ADDR,
        .ecap_base_b      = CONFIG_ECAP1_BASE_ADDR,
        .xbar_input_a     = ECAP_INPUT_INPUTXBAR0,
        .xbar_input_b     = ECAP_INPUT_INPUTXBAR1,
        .int_num_a        = CSLR_R5FSS0_CORE0_CONTROLSS_INTRXBAR0_OUT_22,
        .int_num_b        = CSLR_R5FSS0_CORE0_CONTROLSS_INTRXBAR0_OUT_23,
        .invert_direction = false
    },
    {
        .ecap_base_a      = CONFIG_ECAP2_BASE_ADDR,
        .ecap_base_b      = CONFIG_ECAP3_BASE_ADDR,
        .xbar_input_a     = ECAP_INPUT_INPUTXBAR2,
        .xbar_input_b     = ECAP_INPUT_INPUTXBAR3,
        .int_num_a        = CSLR_R5FSS0_CORE0_CONTROLSS_INTRXBAR0_OUT_24,
        .int_num_b        = CSLR_R5FSS0_CORE0_CONTROLSS_INTRXBAR0_OUT_25,
        .invert_direction = false
    }
};

static ClockP_Object gTestTickClock;

/* 1 ms tick: only copies timestamps (a few register reads). */
static void Test_TickCallback(ClockP_Object *obj, void *args)
{
    (void)obj;
    (void)args;
    SpeedEcap_Tick();
}

static const char *Test_DirectionText(int8_t direction)
{
    const char *text = "UNKNOWN";

    if(direction == SPEED_ECAP_DIR_FORWARD)
    {
        text = "FORWARD";
    }
    else if(direction == SPEED_ECAP_DIR_REVERSE)
    {
        text = "REVERSE";
    }
    else
    {
        ;
    }

    return text;
}

static void Test_PrintPg(const char *label, const SPEED_ECAP_PG_RESULT *result)
{
    DebugP_log("%s | A: %9.3f Hz %8.3f km/h %5u p | B: %9.3f Hz %8.3f km/h %5u p | %s | "
               "net %u (%s) | qerr %u qrev %u glitch %u/%u ovr %u/%u | cfg%d harvest%d irq%d\r\n",
               label,
               result->channel_a.frequency_hz,
               result->channel_a.speed_mps * TEST_MPS_TO_KMPH,
               result->channel_a.pulses_in_window,
               result->channel_b.frequency_hz,
               result->channel_b.speed_mps * TEST_MPS_TO_KMPH,
               result->channel_b.pulses_in_window,
               Test_DirectionText(result->direction),
               result->net_pulses_in_window,
               Test_DirectionText(result->net_direction_in_window),
               result->quad_errors_in_window,
               result->quad_reversals_in_window,
               result->channel_a.glitches_in_window,
               result->channel_b.glitches_in_window,
               result->channel_a.overruns_in_window,
               result->channel_b.overruns_in_window,
               (result->fault_config == true) ? 1 : 0,
               (result->fault_harvest == true) ? 1 : 0,
               (result->irq_enabled == true) ? 1 : 0);
}

void ecap_capture_pwm_main(void *args)
{
    int32_t              status;
    uint64_t             next_run_us;
    SPEED_ECAP_PG_RESULT pg1_result;
    SPEED_ECAP_PG_RESULT pg2_result;
    SPEED_ECAP_STATS     stats;
    SPEED_ECAP_STATS     prev_stats = {0};
    ClockP_Params        clock_params;

    (void)args;

    Drivers_open();
    Board_driversOpen();

    DebugP_log("\r\nECAP speed + direction test (v3)\r\n");

    status = SpeedEcap_Init(gTestPgConfig, 2U);
    if(status != SystemP_SUCCESS)
    {
        DebugP_log("SpeedEcap_Init FAILED\r\n");
        DebugP_assert(false);
    }

    /* PPR and diameter for the filters before the first window */
    SpeedEcap_Evaluate(0U, TEST_PULSES_PER_REV, TEST_WHEEL_DIAMETER_M, &pg1_result);
    SpeedEcap_Evaluate(1U, TEST_PULSES_PER_REV, TEST_WHEEL_DIAMETER_M, &pg2_result);

    /* 1 ms periodic tick for SpeedEcap_Tick() */
    ClockP_Params_init(&clock_params);
    clock_params.callback = Test_TickCallback;
    clock_params.args     = NULL;
    clock_params.timeout  = ClockP_usecToTicks(SPEED_ECAP_TICK_PERIOD_US);
    clock_params.period   = ClockP_usecToTicks(SPEED_ECAP_TICK_PERIOD_US);
    clock_params.start    = 1;
    status = ClockP_construct(&gTestTickClock, &clock_params);
    DebugP_assert(status == SystemP_SUCCESS);

    next_run_us = ClockP_getTimeUsec() + ((uint64_t)TEST_PRINT_PERIOD_MS * 1000U);

    while(1)
    {
        while(ClockP_getTimeUsec() < next_run_us)
        {
            SpeedEcap_Service();
        }
        next_run_us = next_run_us + ((uint64_t)TEST_PRINT_PERIOD_MS * 1000U);

        SpeedEcap_Evaluate(0U, TEST_PULSES_PER_REV, TEST_WHEEL_DIAMETER_M, &pg1_result);
        SpeedEcap_Evaluate(1U, TEST_PULSES_PER_REV, TEST_WHEEL_DIAMETER_M, &pg2_result);
        SpeedEcap_GetStats(&stats);

        Test_PrintPg("PG1", &pg1_result);
        Test_PrintPg("PG2", &pg2_result);
        DebugP_log("STATS | ticks %u ecap_irqs %u events %u (this window) | max tick %u cycles, max isr %u cycles\r\n\r\n",
                   stats.tick_calls - prev_stats.tick_calls,
                   stats.irq_calls - prev_stats.irq_calls,
                   stats.events_harvested - prev_stats.events_harvested,
                   stats.max_tick_cycles,
                   stats.max_irq_cycles);
        prev_stats = stats;
    }
}
