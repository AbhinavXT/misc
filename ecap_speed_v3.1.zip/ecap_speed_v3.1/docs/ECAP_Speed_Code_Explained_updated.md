# The ECAP Speed & Direction Code (v3) — Explained From Zero

**Covers:** `speed_sensor_ecap.c/.h` (v3), `speed_decision.c/.h`, `speed_sensor_user.c/.h`, `ecap_speed_test.c`, `speed_decision_test_rdso33.c`
**Board numbers used in every example:** 30 pulses per revolution (PPR), 0.95 m wheel, 200 MHz ECAP clock. These match your board logs (14.0 Hz → 5.00 km/h, 279.4 Hz → 100.08 km/h).
**Companion document:** `KAVACH_ECAP_Integration_Guide.md` (how to put this into the Kavach code).

This document is meant to be read top to bottom without knowing anything about ECAP or speed measurement.

- **Part A** builds up every idea and formula with numbers. It includes the "why" behind every limit: why the stop timeout is 2 s, why 10.7 s, why M/T is exact, and why one fake edge moves the speed.
- **Part B** explains the ECAP hardware and how timestamps are collected without interrupts.
- **Parts C, D and E** go through the code function by function.
- **Part F** follows real pulses through the system.
- **Part G** explains where the 1–2 km/h difference came from and why it is gone.
- **Part H** is the reference: limits, settings, removed variables, test results and glossary.

---

## What changed from v2 to v3, and why

| # | Problem in v2 | What v3 does | Result (host simulation, same signals for both) |
|---|---|---|---|
| 1 | Direction came from "where B's rising edge sits in A's period". In reverse, the rising edges are the forward *falling* edges, so the phase moves with the duty cycles of A and B. With 55/45 duty, 38 % of reverse edges were "phase errors"; with a larger mismatch the loco reported **FORWARD while reversing**. | Both edges are captured. Direction comes from a **quadrature state decoder** (the levels of A and B), which does not depend on duty cycle or exact phase. | Reverse at 30 km/h, 55/45 duty: v2 lost 95 pulses of distance in 3 s; v3 is exact. |
| 2 | The spurious filter rejected edges that came "too early". One missing real edge made the reference period 2T, then every real edge looked early: the filter locked, the speed read half, and the locked edges counted as **reverse** (false REVERSE for ~40 ms). | Spurious edges are removed by **pulse width** (a rising edge whose high time is shorter than a minimum is a glitch). There is no "too early" rule any more, so nothing can lock. | One missing pulse at 100 km/h: v2 had 4 wrong-direction windows and −22 pulses; v3 has 0 and −1 (the pulse that was really missing). |
| 3 | When the 4 capture registers were overwritten, the newest timestamp went into the buffer ahead of older ones, the lost edge was not counted, and losing exactly 4 edges left no trace at all. | The harvest reads all flagged registers, **sorts** them by time, detects every loss (including 4k lost), estimates how many were lost, and adds the lost steps back to the distance. | All interrupts blocked 1–30 ms at 250 km/h: v2 missed losses from 24.5 ms on (14 pulses gone, no flag); v3 flags every one and the pulse count and NET stay exact. |
| 4 | One ECAP interrupt per 4 edges per channel (≈280/s at 100 km/h, ≈700/s at 250 km/h), competing with 10–12 other interrupts. | **No ECAP interrupts** at 30 PPR. Timestamps are copied by `SpeedEcap_Tick()`, called from the existing 1 ms timer (RTI / ClockP). ECAP interrupts switch on automatically only if the tick is too slow for the PPR. | 0 ECAP interrupts per second at any speed (30 PPR). |
| 5 | Unused / log-only fields, and a health check (`is_healthy`) that looked like a safety check but did nothing. | Removed; replaced by signal-quality counters (`QE`, `QR`) and `fault_harvest`, which are used. | See H5. |

The decision logic (`speed_decision.c`) also changed. All 16 RDSO 33 cases still pass, and a few real-loco problems are fixed (D0 has the list):

- worn wheels + one dead channel no longer goes to System Failure;
- a flickering channel is still declared failed;
- no slip is flagged for differences the comparators accept;
- no NMS message is sent at every start;
- a 0.05 km/h measurement margin makes bench tests with channels set exactly 1 km/h apart pass.

### v3.1 (after the first v3 bench test)

| Bench symptom | Cause | Fix |
|---|---|---|
| Step from 1 km/h to 250 km/h: one channel (a or b) shows 0 Hz / 0 km/h. Step from 2–3 km/h: all four channels show 0. Step from 0: fine | The glitch filter's minimum high time was 10 % of the **last accepted period**. At 2–3 km/h that is 12–18 ms. At 250 km/h a real pulse is high for 0.7 ms, so every pulse was rejected, the reference never updated, and the channel stayed locked. At 1 km/h the period (358 ms) was above the 179 ms "adaptive" limit, but the first partial period after the step often was not, so it depended on the channel. From 0 there was no reference | The reference is now the **shorter** of the last accepted period and the time since the previous rising edge (accepted or rejected), so it follows a speed step at once. Directly after a rejection only the absolute limit is used, so two rejections in a row are impossible. On a stop the old period is forgotten (C13) |
| (found while testing the above) At 250 km/h with glitches on the input: false overruns, a few phantom pulses, 0.2–0.4 km/h errors, channels briefly "unusable" | A glitch pair inside a full 4-entry batch made the average edge spacing tiny, so a normal gap looked like 4 lost edges. At a bench speed step, the gap since the last *slow* edge looked like lost edges too | The spacing ignores glitch pairs (largest spacing used when one is tiny), and lost edges are only searched for **after the previous harvest** (the ECAP time is now recorded at every tick), not since the last edge (C7) |

Simulation after the fix: steps from every speed between 0 and 200 km/h up to 250 km/h, and from 250 down to every speed, with glitches on 3 % of the edges and 2 µs jitter. Every channel is exact from the first full window after the step, there are no false overruns, and the distance is within the normal 1–2 pulse start-up offset (H6).

---

## Contents

- **Part A — The ideas and the mathematics**
  A1 Pulses and the wheel · A2 Frequency to speed · A3 Time, clocks and ticks · A4 Two channels, quadrature and direction · A5 The 32-bit counter and unsigned subtraction · A6 Signed differences and the 10.7 s limit · A7 Why the stop timeout is 2 s · A8 Measuring frequency: M, T and M/T · A9 Why one fake edge moves the speed by 1/N · A10 Slowing down: decay · A11 Acceleration · A12 What goes wrong, and what the code does
- **Part B — The ECAP hardware and how timestamps are collected**
- **Part C — `speed_sensor_ecap.c`, function by function**
- **Part D — `speed_decision.c`, function by function (RDSO test 33)**
- **Part E — `speed_sensor_user.c` and `ecap_speed_test.c`**
- **Part F — Following pulses through the system**
- **Part G — The 1–2 km/h difference: where it came from, why it is gone**
- **Part H — Limits, settings, removed variables, test results, glossary**

---

# PART A — THE IDEAS AND THE MATHEMATICS

## A1. Pulses and the wheel

A **pulse generator (PG)** is mounted on an axle. Inside it a toothed disc turns with the wheel. A sensor outputs **high** while a tooth is in front of it and **low** while a gap is. So as the wheel turns, the output is a square wave: one high part plus one low part per tooth.

```
tooth   gap   tooth   gap   tooth
 ____        ____        ____
|    |      |    |      |    |
|    |______|    |______|    |______      <- PG output
^    ^      ^    ^      ^
rise fall   rise fall   rise
```

One full tooth (one rise + one fall) is one **pulse**. Your PG gives **30 pulses per revolution** (**PPR**).

One revolution moves the train by the wheel's circumference:

```
circumference     = π × D   = 3.14159 × 0.95 m = 2.9845 m
distance / pulse  = 2.9845 / 30 = 0.09948 m ≈ 9.95 cm
pulses per metre  = 30 / 2.9845 = 10.052
```

## A2. From frequency to speed

**Frequency** f = pulses per second (Hz). Each pulse is 0.09948 m, so:

```
speed (m/s)  = f × (π × D / PPR)          = f / 10.052
speed (km/h) = speed (m/s) × 3.6
f            = speed (m/s) × PPR / (π × D)
```

| Speed | f | Period T (time per pulse) | T in 5 ns ticks |
|---|---|---|---|
| 1 km/h | 2.79 Hz | 358 ms | 71,628,312 |
| 2 km/h | 5.58 Hz | 179 ms | 35,814,156 |
| 5 km/h | 13.96 Hz | 71.6 ms | 14,325,662 |
| 15 km/h | 41.88 Hz | 23.9 ms | 4,775,220 |
| 30 km/h | 83.77 Hz | 11.9 ms | 2,387,610 |
| 100 km/h | 279.22 Hz | 3.58 ms | 716,283 |
| 160 km/h | 446.75 Hz | 2.24 ms | 447,676 |
| 250 km/h | 698.05 Hz | 1.43 ms | 286,513 |
| 375 km/h (glitch limit) | 1047.07 Hz | 0.955 ms | 191,008 |

Check with your log: 279.4 Hz → 279.4 / 10.052 × 3.6 = 100.07 km/h ✔.

## A3. Time, clocks and ticks

Each ECAP has a 32-bit counter (`TSCTR`) that counts the 200 MHz clock:

```
1 tick = 1 / 200,000,000 s = 5 ns
```

When an edge arrives, the ECAP copies the counter value into a capture register. That value is the edge's **timestamp**. The time between two edges is the difference of their timestamps:

```
T (ticks) = ts2 − ts1
f (Hz)    = 200,000,000 / T (ticks)
```

At 100 km/h, T = 716,283 ticks. One tick is 1/716,283 = 0.00014 % of that: the clock itself is never the source of a speed error. Errors can only come from the **signal** (extra, missing or jittery edges) or from **how the edges are counted**.

## A4. Two channels, quadrature, and how direction is known

Each PG has two sensors, channel **A** and channel **B**, placed so that B is shifted by about a quarter tooth. Two square waves a quarter period apart are called **quadrature** signals.

### The four states

At any moment, A and B are each high (1) or low (0), so the pair (A, B) has four possible states. Moving **forward** (A leads B), the states follow one fixed order:

```
position:  0        ¼        ½        ¾        1 (next tooth)
A        ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾|__________________|‾‾‾‾
B        ________|‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾|__________|‾‾‾‾
state (A,B):  10       11       01       00      10 ...

forward:  00 → 10 → 11 → 01 → 00      (A rises, B rises, A falls, B falls)
reverse:  00 → 01 → 11 → 10 → 00      (exactly the opposite order)
```

Every edge changes **exactly one** of the two levels. So each edge is one **step** of a quarter pulse, either forward (+1) or reverse (−1). The rule that decides which:

```
edge on A:  step = +1 if new A ≠ B,   −1 if new A = B
edge on B:  step = +1 if new B = A,   −1 if new B ≠ A
```

Check with the forward order: A rises from 00 → new A = 1, B = 0 → 1 ≠ 0 → +1 ✔. B rises from 10 → new B = 1, A = 1 → equal → +1 ✔. A falls from 11 → new A = 0, B = 1 → +1 ✔. B falls from 01 → new B = 0, A = 0 → +1 ✔. Each of the reverse transitions gives −1.

This is exactly what the EQEP hardware did ("x4 quadrature decoding"). 4 steps = 1 pulse.

### Why v2's method failed in reverse (and v3's does not)

v2 used **rising edges only** and asked "where is B's last rising edge inside A's period?" Forward: 25 %. Reverse: 75 %.

But a square wave does not look the same played backwards. The rising edges seen in reverse are the positions where the signal **fell** when going forward. Say forward B rises φ after A (φ = the forward phase), A is high for a fraction dA of the tooth, and B is high for dB. Then in reverse:

```
reverse phase = 100 % − φ + (dA − dB)
```

With equal duty cycles (dA = dB) this is 100 % − 25 % = 75 % ✔. But your PG1 reads φ ≈ 20 % going forward. If A is high 55 % and B 45 % of the tooth, then reverse phase = 100 − 20 + 10 = **90 %**, right on the edge of the 60–90 % "reverse" window. Half the edges become "phase errors". With a bigger duty difference it crosses 100 % → wraps to 0–10 % → **classified as forward**. The simulation showed exactly that (H6), and your first board log shows PG1 in reverse with ~30 phase errors per second and the direction flipping.

The state decoder does not look at timing at all, only at **which level changed and what the other level was**. As long as the four states occur, it counts correctly, whatever the duty cycles and whatever the exact phase. If a signal is so distorted that the four states do not all occur (for example B's high part lies completely inside A's high part), then *no* method can tell direction. The decoder then counts +1, −1, +1, −1… (net 0) and the code reports **UNKNOWN** instead of a wrong direction.

### Bounce on one channel cancels

A glitch on A (A falls, jumps high for a microsecond, falls again) gives three A edges: fall (+1), rise (−1), fall (+1). Net = +1, which is exactly the one real fall. Quadrature counting is naturally immune to bounce on a single channel. The same is true for chatter when the wheel stands exactly on a tooth edge and vibrates: +1 −1 +1 −1 … → net 0, no false movement.

### Direction confirmation

The **confirmed direction** changes only after **6 consecutive steps in the same direction** (1.5 pulses = 15 cm at 30 PPR). A glitch (2 opposite steps) resets the run, but the next clean steps confirm again.

## A5. The 32-bit counter and unsigned subtraction

The counter is 32 bits: it counts 0, 1, 2 … 4,294,967,295 and then **wraps** to 0. At 200 MHz that takes:

```
2³² ticks × 5 ns = 4,294,967,296 × 5 ns = 21.47 s
```

So timestamps are only "clock positions on a 21.47 s dial". An edge at 4,294,900,000 followed, after the wrap, by one at 200,000 looks like it went backwards. The real gap is 267,296 ticks.

**Unsigned subtraction solves it.** A `uint32_t` in C can only hold 0 … 2³² − 1. When a subtraction would go below 0, the result is taken **modulo 2³²**, which means 2³² is added automatically:

```
200,000 − 4,294,900,000 = −4,294,700,000   (true arithmetic)
−4,294,700,000 + 4,294,967,296 = 267,296    (what uint32_t gives)   ✔ the real gap
```

This works for **any** pair of timestamps, as long as the real gap is **shorter than one full turn of the dial (21.47 s)**. A gap of 21.47 s + 1 ms would look like 1 ms. That is why nothing may ever measure a period across a gap that long (A7).

## A6. Signed differences and the 10.7 s limit

Sometimes the code must know **which of two timestamps is earlier**:

- merging A and B events in time order;
- sorting the four capture registers;
- "is the waiting rising edge newer than the last accepted one?".

An unsigned difference cannot tell: `later − earlier` = small number, but `earlier − later` = 2³² − small = huge number. Both are "valid" dial readings.

**The trick:** subtract as unsigned, then read the same 32 bits as a **signed** number (`int32_t`):

```
(int32_t)(X − Y)
```

A signed 32-bit number holds −2,147,483,648 … +2,147,483,647 (that is −2³¹ … 2³¹ − 1). The bit pattern of a "huge" unsigned result (above 2³¹) is the same bit pattern as a negative signed number (two's complement). So:

- X a little **after** Y → small positive number;
- X a little **before** Y → the unsigned result is 2³² − small, which reads as signed **−small**.

**How far apart may X and Y be?** The answer is correct as long as the real difference fits in the signed range, i.e. is less than 2³¹ ticks:

```
2³¹ ticks × 5 ns = 2,147,483,648 × 5 ns = 10.737 s     ← the "10.7 s", half the wrap time
```

**Example at the limit.** Y = 0. X = 2,147,483,647 (10.737 s later): signed result +2,147,483,647 → "later" ✔. X = 2,147,483,648 (1 tick more): the bit pattern reads as −2,147,483,648 → "earlier" ✘. Beyond half the dial, "later" and "earlier" swap. So every signed comparison in the code must only ever compare timestamps **less than 10.7 s apart**. v3 guarantees this:

| Comparison | Why the two timestamps are always < 10.7 s apart |
|---|---|
| A vs B event (merge) | Both are in the buffers only a few ms before `Service()` consumes them (Service runs at least every 50 ms) |
| Sorting the 4 capture registers | They were captured within a few pulses of each other |
| Oldest new timestamp vs last harvested | `has_harvested_ts` is forgotten after `STOP_TIMEOUT` (2 s) with no events, counted by the 1 ms tick |
| Oldest new timestamp vs time of the last harvest (`last_check_ts`) | Refreshed at every tick (1 ms) |
| Waiting rising edge vs last accepted edge | A waiting rising edge older than `STOP_TIMEOUT` is dropped at the next window |

This is also why `SPEED_ECAP_STOP_TIMEOUT_MS` is limited to 8 s. The "forget old timestamps" checks run once per window (≤ 1 s) after the timeout, so timeout + window must stay under 10.7 s.

## A7. Why the stop timeout is 2 s

Rule: **if a channel gets no accepted edge for 2 s, it is declared stopped. Its speed becomes exactly 0, and the next edge starts a fresh chain (no period is measured across the gap).** There are five reasons behind the number.

**1. It must be well below 21.47 s (the wrap, A5).** A "period" of 22 s would look like 0.5 s after the wrap: a train standing still for 22 s would suddenly read 0.36 km/h. Declaring "stopped" long before the wrap, and never measuring across a stop, makes this impossible.

**2. It must be below 10.7 s minus one window (A6),** because the waiting and last-harvested timestamps are retired using signed comparisons. That is the hard maximum of 8 s.

**3. It sets the lowest speed that can be seen.** A wheel is only "moving" if at least one pulse comes within the timeout:

```
lowest speed = distance per pulse / timeout = 0.0995 m / 2 s = 0.0497 m/s = 0.18 km/h
```

Anything slower reads 0. With 1 s it would be 0.36 km/h, with 5 s 0.07 km/h.

**4. It sets how long a stopped train keeps showing a small speed.** After the last pulse, the speed slides down (A10): 1/(time since last edge). At 1 s after the last pulse the display shows 0.36 km/h; at 2 s it becomes exactly 0. With a 5 s timeout the display would show 0.07–0.36 km/h for 5 s after every stop, which delays standstill detection. With 0.5 s, a train creeping at 0.5 km/h would flicker between 0 and 0.7 km/h.

**5. It must be longer than the slowest period that still matters.** Rollaway protection is distance based (NET pulses), so pulses are counted even below 0.18 km/h. Only the *speed value* reads 0.

2 s is the balance: 0.18 km/h resolution (below any meaningful creep speed), 0 shown 2 s after a stop, and far from both wrap limits. It is a `#define`; if your FRS asks for a different "zero speed" delay, change it (max 8 s).

## A8. Measuring frequency: methods M, T and M/T

There are three ways to turn pulses into a frequency.

**Method M ("count pulses in a fixed window"):** f = N / window. Simple, but the window edges cut pulses: at 100 km/h a 1 s window contains 279 **or** 280 pulses, depending on where it starts. One pulse is 0.36 km/h at 1 s windows and **3.6 km/h at 0.1 s windows**. This is what the old EQEP code did.

**Method T ("time one period"):** f = 1 / (ts2 − ts1) of the last pulse. Very precise, but it sees only one pulse, so any unevenness of one tooth or any jitter of one edge goes straight into the result.

**Method M/T ("count pulses AND time them exactly"), used by the code:**

```
t₁ = timestamp of the last accepted rising edge of the PREVIOUS window
t₂ = timestamp of the last accepted rising edge of THIS window
N  = number of accepted rising edges after t₁ up to and including t₂

f  = N / (t₂ − t₁)         = N × 200,000,000 / (t₂ − t₁ in ticks)
```

**Why this is exact.** Between t₁ and t₂ there are exactly N complete periods, because both ends are real edges. No pulse is cut in half, because the "window" is not the software window but the time between two edges. The software window only decides which edges are included; it does not enter the formula.

**Worked example, 100 km/h, 1 s windows.** T = 716,283.1 ticks. Suppose this window contains N = 279 edges. Then t₂ − t₁ = 279 × 716,283.1 = 199,842,992 ticks, and:

```
f = 279 × 200,000,000 / 199,842,992 = 279.219 Hz   →   100.00 km/h
```

Next window N = 280: t₂ − t₁ = 280 × 716,283.1 = 200,559,275 ticks → f = 279.219 Hz again. The ±1 pulse jitter of method M disappears completely.

**How precise is it really?** The only error is the error of the two timestamps t₁ and t₂: one tick (5 ns) plus the electrical jitter of the edge (typically a few µs on a real sensor). With 2 µs of jitter:

```
relative error ≈ 2 µs / (t₂ − t₁) = 2 µs / 1 s = 0.0002 %      (1 s window)   → 0.0002 km/h at 100 km/h
                                  = 2 µs / 0.1 s = 0.002 %     (0.1 s window) → 0.002 km/h at 100 km/h
```

The simulation measured exactly this: 0.002 km/h with 2 µs jitter and 0.1 s windows (H6).

**What M/T needs:**
- *every counted edge must be real* (A9);
- *no edge may be missing between t₁ and t₂ without being known*. The code only uses M/T when nothing broke the chain: same `run_id` (no stop/restart) and no overrun in the window. Otherwise it falls back to method T for that window.

**Fallback cases:**
- no new edge this window (very low speed) → method T with the last period, then decay (A10);
- first edge after a start → no period yet → 0 for that window.

## A9. Why one fake edge moves the speed by exactly 1/N

M/T is exact **only if every counted edge is real**. Here is why one fake edge does so much damage.

The time span (t₂ − t₁) is fixed by the **first and last real edges**. A fake edge somewhere in between does not move t₁ or t₂, but it adds 1 to N:

```
real:    f      = N / span
with 1 fake edge inside:
         f_fake = (N + 1) / span = f × (N + 1) / N      →  error = f / N  (one pulse's worth)
```

So the error is **one pulse per window**, whatever the speed. Relative to the speed, that is 1/N: large when N is small (short windows, low speed).

| Window | Speed | Real N | With 1 fake edge | Error |
|---|---|---|---|---|
| 1 s | 100 km/h | 279 | 280/279 → 100.36 | +0.36 km/h |
| 0.1 s | 100 km/h | 28 | 29/28 → 103.57 | +3.6 km/h |
| 0.1 s | 15 km/h | 4 | 5/4 → 18.75 | +3.75 km/h |

This is exactly what your first board log shows: 15.01 → 18.76 km/h (5/4) and 100.08 → 103.66 km/h (29/28) in 0.1 s windows, and 100.08 → 101.87 km/h (≈ 5 fake edges in 285) in 1 s windows.

If the fake edge happens to be the **last** edge of the window, it becomes t₂ and moves the span too. The result is still wrong, by a similar amount. Either way, the only cure is to **never count a fake edge**. v3 does that with the glitch filter (C12): a rising edge counts only if the signal then stays high for a real pulse width.

## A10. Slowing down: decay

The train is stopping. The last pulse came 100 ms ago, and before that pulses were 23.9 ms apart (15 km/h). What is the speed *now*?

M/T and method T only know the **last complete** period (23.9 ms → 15 km/h). But we know one more fact: **the current period is at least 100 ms**, because 100 ms have passed with no new pulse. So the frequency now is at most:

```
f_now ≤ 1 / (time since last edge) = 1 / 0.1 s = 10 Hz   →   ≤ 3.58 km/h
```

The code applies this as a **cap**, and only once the next edge is **overdue by more than 1/8 of the last period**. In normal running the next edge is never that late, so the M/T value is untouched. The 1/8 margin makes sure that a few µs of edge jitter never nudges the result. When stopping, the speed slides down smoothly instead of freezing at the last value (simulated stop from 15 km/h, 0.1 s windows: 14.1 → 11.2 → 8.5 → 6.4 → 3.4 → 1.8 → 1.2 → … → 0.2 km/h) and becomes exactly 0 at the 2 s stop timeout.

**v3 detail — the waiting rising edge.** In v3 a rising edge is accepted only when its falling edge arrives (A12, glitch filter). So at evaluation time there may be a newer rising edge "waiting". The code then knows two things: the period that ends at the waiting edge is (waiting − last accepted), and the one after it is at least (now − waiting). The longer of the two is used for the cap. Without this, a wheel that stopped with its signal high, and later started again in the other direction, showed one stale value (3.6 km/h instead of 0.2 km/h) in the simulation.

## A11. Acceleration

```
a (m/s²) = Δspeed (m/s) / Δtime (s) = (Δspeed in km/h / 3.6) / Δtime
```

RDSO 33.16: 67 → 72 km/h in 1 s → a = (5 / 3.6) / 1 = **1.39 m/s²** > 1 m/s² → slip. 65 → 67 → 0.56 m/s² → no slip. A real loco with good adhesion cannot accelerate much above ~1 m/s²; a faster change means a wheel is spinning (or, on the bench, the generator was stepped, see D6).

## A12. What goes wrong, and what the code does

| Name | What it looks like | Why it happens | What v3 does |
|---|---|---|---|
| **Glitch pair** | A rising edge followed within microseconds by a falling edge (or the reverse) | Ringing or crosstalk at an edge. Your board showed extra rising edges at ~50 % of the period, i.e. at the falling edge | The rising edge is not accepted if the high time after it is shorter than the minimum width. Counted in `GL`. The quadrature decoder counts it as −1/+1 (cancels) |
| **Too fast** | Accepted rising edges closer than 0.955 ms (375 km/h) | Noise that survives the width filter | Rejected, counted in `GL` |
| **Lost events** | Capture registers overwritten before being read, or buffer full | Tick/interrupts blocked too long, or main loop too slow | Detected (C7), counted in `OVR`, pulse count and distance corrected by the estimated loss, chain broken (no period across), channel unusable for this window's decision |
| **Chatter** | Edges on one channel while the other does not move | Wheel standing on a tooth edge and vibrating | Quadrature steps +1 −1 … net 0, no direction change. The channel's own speed can show a small value; it goes to 0 after the stop timeout |
| **Not a quadrature pair** | A and B at different frequencies, or so distorted that the four states do not occur | RDSO 33.4/33.5/33.14/33.15 on the bench (generator drives A and B differently), or a broken sensor | At least every second step reverses → direction UNKNOWN for that window. Visible as a high `QR` |
| **Quadrature error** | The same channel gives two edges of the same polarity in a row | Only possible when an edge was lost | Counted in `QE`, level re-learned |
| **Channel failure** (test 33) | One channel's speed disagrees with the others by > 1 km/h for longer than the timeout | Broken sensor or wire | Logged + NMS; the others carry on |
| **Speed malfunction** (test 33) | No two channels agree | Several failures | System Failure after the timeout |
| **Slip / slide** | One PG's speed runs away from the other, or the train "accelerates" impossibly | Wheel spinning / locked | DMI; SR prompt after the timeout |

---

# PART B — THE ECAP HARDWARE AND HOW TIMESTAMPS ARE COLLECTED

## B1. The ECAP as a stopwatch with a four-page notebook

An **ECAP** (Enhanced Capture) module has:

- a **32-bit counter** (`TSCTR`) counting 200 MHz ticks: the stopwatch;
- **four capture registers** `CAP1`…`CAP4`: the notebook pages;
- **four event flags** `CEVT1`…`CEVT4`: "this page has a value nobody has read yet";
- a **modulo counter** (0…3): which page is written next.

When the selected edge arrives, the ECAP copies the counter into the next page, sets that page's flag, and moves the modulo counter on. After page 4 it wraps to page 1 and **overwrites** it, whether or not software has read it.

## B2. v3 setting: pages 1 and 3 on rising edges, pages 2 and 4 on falling edges

Each capture register has its own edge polarity. v3 sets:

```
CAP1 = rising   CAP2 = falling   CAP3 = rising   CAP4 = falling
```

The hardware fills them strictly in order 1 → 2 → 3 → 4 → 1… and waits, for each page, for an edge of **that page's polarity**. So:

- every entry's polarity is known from the page it came from (page 1/3 = rising, 2/4 = falling);
- the notebook holds **4 edges = 2 complete pulses**;
- a missing edge can never be mistaken for the other polarity: after a rising edge, the ECAP waits for a falling one.

| Setting | Value | Why |
|---|---|---|
| Capture mode | Continuous, wrap after CAP4 | Never stops, no re-arm gap |
| Polarity | CAP1/CAP3 rising, CAP2/CAP4 falling | Both edges → quadrature state decoder (A4) and glitch-pair filter (A12) |
| Counter reset on capture | Off (absolute time) | All four ECAPs share one time line, so A and B events can be merged in time order |
| Prescaler | Off | Every edge captured |
| Hardware pulse filter | 15 cycles = 75 ns | Removes very short spikes; longer glitches are handled in software |
| Emulation | Free run | Counters keep running when the debugger halts the CPU |
| Counters | Zeroed and started back to back, skew checked ≤ 2000 ticks | Same time line for all four (the attachment log shows 35–100 ticks between two ECAPs fed from the same generator) |
| Capture interrupts | **Off** unless needed (B4) | Timestamps are collected by the 1 ms tick |

## B3. Collecting timestamps without interrupts: the tick

The flags `CEVT1…4` are set on every capture whether or not an interrupt is enabled. So software can look at the flags at any time and copy whatever is new. v3 does this in `SpeedEcap_Tick()`, called from a timer that **already exists** in the system (the 1 ms RTI / ClockP tick). No new interrupt source is added.

**How often must the tick run?** The notebook holds 4 edges = 2 pulse periods. The 5th edge after the last read overwrites the oldest unread page. So the tick must come well within 2 periods at the highest speed:

```
required:  TICK × 1.5 (margin)  <  2 × T_min          T_min = period at 250 km/h

30 PPR, 0.95 m:  T_min = 1.43 ms  →  2 T_min = 2.87 ms  >  1.5 ms  ✔  (1 ms tick is enough)
```

| Tick period | Highest PPR without ECAP interrupts (0.95 m, 250 km/h) |
|---|---|
| 1 ms | 57 PPR |
| 0.5 ms | 114 PPR |
| 0.25 ms | 229 PPR |

**Cost of one tick.** For each of the 4 channels: 1 flag read. Only when something is new: up to 4 timestamp reads, 1 flag clear, a sort of at most 4 numbers, and up to 4 buffer writes. At 100 km/h (30 PPR) there are 0.56 new edges per channel per tick on average, so a typical tick is about 4 register reads plus 2 short copies: on the order of **1–2 µs** on the R5F. That is an estimate; switch on `SPEED_ECAP_PROFILE` and read `max_tick_cycles` from `SpeedEcap_GetStats()` to measure it on your board.

## B4. When ECAP interrupts are still used

`SPEED_ECAP_IRQ_MODE`:

- `SPEED_ECAP_IRQ_AUTO` (default): at the first `Evaluate()` the code computes the rule above from PPR and diameter. If the tick is fast enough, ECAP interrupts stay off. If not (e.g. 120 PPR with a 1 ms tick), CEVT4 interrupts are switched on for that PG: each channel interrupts every 4 edges (2 periods), and every interrupt empties both channels of the PG.
- `SPEED_ECAP_IRQ_OFF`: never. If the tick is too slow, the PG reports `fault_harvest` (the glue then treats its channels as unusable).
- `SPEED_ECAP_IRQ_ALWAYS`: always on (plus the tick).

For a high-PPR PG, a faster tick is usually cheaper than ECAP interrupts: a 0.25 ms tick is a fixed 4000 calls per second, while ECAP interrupts at 120 PPR / 250 km/h are about 5600 per second and grow with speed.

**Interrupt load, all four channels:**

| | 100 km/h | 250 km/h |
|---|---|---|
| v1 (1 interrupt per edge) | 1117 /s | 2792 /s |
| v2 (CEVT4, rising edges only) | 279 /s | 698 /s |
| **v3 at 30 PPR (tick)** | **0 /s** (the existing 1 ms tick does the work) | **0 /s** |

## B5. How the signals reach the ECAPs

```
PG1-A (RH a) -> GPIO -> Input XBAR 0 -> ECAP0      [INT XBAR 22 registered, off]
PG1-B (RH b) -> GPIO -> Input XBAR 1 -> ECAP1      [INT XBAR 23 registered, off]
PG2-A (LH a) -> GPIO -> Input XBAR 2 -> ECAP2      [INT XBAR 24 registered, off]
PG2-B (LH b) -> GPIO -> Input XBAR 3 -> ECAP3      [INT XBAR 25 registered, off]
```

syscfg routes the pins (Input XBAR) and interrupt lines (Interrupt XBAR). The code then programs the ECAPs itself (C4).

---

# PART C — `speed_sensor_ecap.c` (v3), FUNCTION BY FUNCTION

## C0. The data flow in one picture

```mermaid
flowchart TD
    HW["ECAP hardware: every rising and falling edge -> CAP1..CAP4"] --> T
    T["SpeedEcap_Tick() every 1 ms (existing timer)<br/>SpeedEcap_Harvest: copy + sort + detect loss -> ring buffer"] --> S
    I["ECAP ISR (only if the tick is too slow)"] -.-> S
    S["SpeedEcap_Service() main loop<br/>ConsumeEvents: A and B events in time order"] --> Q["QuadratureStep: position, direction"]
    S --> SP["SpeedEvent: glitch filter -> AcceptRise: period, count"]
    Q --> E["SpeedEcap_Evaluate() once per window<br/>M/T frequency, decay, net pulses, quality"]
    SP --> E
```

Three rules keep it safe:

1. **Harvest** (`Tick`, ISR, or the short critical sections in Service/Evaluate) only copies registers, always with interrupts disabled for a few µs. It is the only writer of the buffer head.
2. **Processing** (`Service`, `Evaluate`) runs with interrupts enabled and is the only reader of the buffer tail. **Service and Evaluate must run in the same task.**
3. Anything that can age (last harvested timestamp, waiting rising edge, last accepted edge) is retired after the stop timeout, so no comparison ever spans more than 10.7 s (A6).

## C1. Data structures

### `SPEED_ECAP_CHANNEL` (one ECAP)

**Set at init:** `ecap_base`, `xbar_input`, `int_num`, `index` (0 = A, 1 = B), `owner_pg`, `hwi_object`.

**Harvest state (interrupts disabled only):**

| Field | Meaning |
|---|---|
| `next_event_index` | Which CAP page the hardware fills next, as software believes |
| `has_harvested_ts`, `last_harvested_ts` | Newest timestamp copied so far (for loss checks); forgotten after a long standstill |
| `pending_mark` | BREAK to put on the next buffer entry after a loss |
| `ring_ts[]`, `ring_flags[]`, `ring_head` | The buffer: timestamp + flags (bit 0 = rising, bit 1 = BREAK) |
| `lost_rise_count`, `lost_event_count` | Rising edges / all edges lost (estimated) |
| `overrun_count` | Number of loss detections |
| `idle_ticks` | Ticks in a row with no new edge |
| `has_check_ts`, `last_check_ts` | ECAP time read at the start of the last harvest: every edge before it has been copied |

**Task state:**

| Field | Meaning |
|---|---|
| `ring_tail` | Entries consumed |
| `pending_rise_valid/_ts/_break` | A rising edge waiting for its falling edge (glitch filter) |
| `prev_rise_valid`, `prev_rise_ts`, `last_width_rejected` | The previous judged rising edge (accepted or rejected) and whether it was rejected; used by the minimum width (C13) |
| `chain_break` | A BREAK was seen; the next accepted rise starts a fresh chain |
| `has_edge`, `restart_pending`, `edge_count`, `last_edge_ts`, `last_period_ticks`, `run_id` | The speed chain of accepted rising edges |
| `glitch_count` | Rising edges rejected (width or too fast) |
| `min_period_ticks`, `min_width_abs_ticks`, `adaptive_max_period` | Filter limits from PPR/diameter |
| `prev_*` | Copies from the previous window for "in this window" values and M/T |

### `SPEED_ECAP_PG` (one pulse generator)

`channel[2]`, `invert_direction`, `filters_ready`, `irq_enabled`, `rate_fault`, and the quadrature decoder:

- `level_known[2]`, `level[2]`: current levels of A and B;
- `position_q`: signed position in quarter pulses;
- `last_step`, `step_streak`, `confirmed_direction`;
- `quad_error_count`, `quad_reversal_count`, `quad_step_count`, `break_step_count`;
- previous-window copies, including `reported_q` (quarter pulses already reported as whole pulses).

### The ring buffer

An array used as a queue that wraps around: the harvest writes at `head`, the task reads at `tail`. Number waiting = `head − tail` (unsigned, so it works after the counters wrap at 2³²). Full when that reaches 512. Size is a power of 2, so `index & 511` replaces a division (checked at compile time).

## C2. `SpeedEcap_Init(hw_config, num_pg)`

1. Checks the arguments; clears all state.
2. Per PG: stores `invert_direction`, sets up both channels (C3).
3. Configures all four ECAPs (C4). They are now configured, stopped, interrupts off.
4. Registers the four interrupt handlers (they are not enabled in the ECAP).
5. Zeroes and starts all counters together, checks the skew (C5).
6. `SpeedEcap_StartHarvest`: clears old flags and reads each hardware modulo counter into `next_event_index`, so software and hardware agree on the next page.

## C3. `SpeedEcap_SetupChannel`

Stores base address (via `AddrTranslateP_getLocalAddr`), XBAR input, interrupt number, index and owner.

## C4. `SpeedEcap_ConfigureModule`

Programs one ECAP as in B2, overwriting syscfg. Order: interrupts off and flags cleared → stop → capture mode, continuous, wrap after 4 → polarity per page (1/3 rising, 2/4 falling), no counter reset → input select, 75 ns filter → no sync → free-run emulation → reset modulo counter and flags → enable time-stamping.

## C5. `SpeedEcap_StartAllCounters` and `SpeedEcap_AbsDiff`

Writes 0 into all four counters (stopped), starts them one after another with interrupts off, reads them back and checks each is within 2000 ticks of the first. `AbsDiff(x, y)` returns the smaller of `x − y` and `y − x` (unsigned), which is the true distance for two readings taken close together, even across a wrap. The skew matters because A and B events from different ECAPs are merged by timestamp; a skew of a few ticks is 0.001 % of a period.

## C6. `SpeedEcap_Tick()`

For each PG, with interrupts disabled for a few µs: harvest A and B. Per channel: if something was harvested, `idle_ticks = 0`; otherwise count up, and after `STOP_TIMEOUT` (2000 ticks at 1 ms) forget `last_harvested_ts`. This retires the only harvest-side timestamp that could otherwise be compared across a long standstill (A6). Increments `tick_calls` (used by Evaluate to detect a missing tick).

## C7. `SpeedEcap_Harvest(channel)`: copy, sort, detect loss

Must run with interrupts disabled. Step by step:

**0. Time.** Read the ECAP counter **before** the flags (`check_ts`). Every edge captured before that moment is either in these flags or was read earlier, so after this harvest edges can only be lost *after* `check_ts`. It is stored as `last_check_ts`.

**1. Read.** Look at the flags. Starting at the page software expects next, read every flagged page's timestamp and remember its page index. Clear exactly those flags.

**2. Sort** the (at most 4) timestamps by time with `(int32_t)(a − b) < 0` (A6). Normally they are already in order. If a page was overwritten by a newer edge, reading order and time order differ, and sorting fixes it.

**3. Detect loss** (only if there is a previous timestamp to compare with):

- **a) Index gap.** The oldest entry should be in the page software expected. If it is k pages later, those k pages were overwritten: k events lost (and which of them were rising is known from the page numbers).
- **b) All 4 pages full.** When all four flags were set, whole rounds of 4 could have been lost without any trace in the order. The code:
  - measures the gap from the **later** of the last edge read and the previous harvest time (`last_check_ts`) up to the oldest new entry. Edges cannot have been lost before the previous harvest, because that harvest saw the flags. This matters at a sudden speed step: the last slow edge may be 100 ms old, but the previous tick was 1 ms ago;
  - compares that gap with the normal edge spacing. This is the average of the 3 spacings between the four entries, **unless** one spacing is 8× smaller than the largest (a glitch pair inside the batch), in which case the largest spacing is used; otherwise a microsecond glitch pair would make a normal gap look like lost edges;
  - if the gap is longer than 3 spacings, or a loss was already found in (a), estimates the events in the gap as round(gap / spacing) − 1 and picks the loss (index gap + 4k) closest to that estimate.
- **c) Impossible order.** The oldest new entry is not later than the last one read. This should never happen and is treated as a loss of unknown size.

Any loss: `overrun_count + 1`, lost rising edges and lost events added up, and the next buffer entry is marked **BREAK**.

**4. Push** the entries oldest first, each tagged rising (page 1/3) or falling (page 2/4). `next_event_index` = the page after the newest entry.

**Worked examples** (software expects page 1, all flags set when read):

```
5 events since the last read (e1 overwritten):
  page1 = e5, page2 = e2, page3 = e3, page4 = e4   → read order e5 e2 e3 e4
  sorted: e2 e3 e4 e5.  Oldest (e2) is in page 2, expected page 1  → 1 event lost (a rising one)

8 events (e1..e4 all overwritten):
  page1 = e5, page2 = e6, page3 = e7, page4 = e8   → order looks perfect, index gap 0
  gap before e5 (from the previous harvest) = 5 spacings, spacing = span / 3 → estimate 4 lost  → 4 lost
```

The simulation blocked all interrupts, the tick and the main loop for 1–30 ms at 250 km/h. Every loss was flagged, and both the pulse count and the net distance stayed exact (H6).

## C8. `SpeedEcap_RingPush` and the ISR

`RingPush` stores the entry with the pending mark, or, if the buffer is full, counts a lost event (and a lost rise if it was rising), an overrun, and sets BREAK for the next entry.

`SpeedEcap_Isr(pg)` is only used when ECAP interrupts are on (B4): it harvests both channels of the PG and counts `irq_calls`.

## C9. `SpeedEcap_UpdateFilters(pg, PPR, D)` — limits and the interrupt decision

```
pulses per metre       = PPR / (π D)                          = 10.052
max real frequency     = (250 / 3.6) × 10.052                 = 698.0 Hz
glitch limit           = 698.0 × 1.5                          = 1047 Hz  → min period 191,008 ticks (0.955 ms)
absolute min width     = 15 % × 191,008                       = 28,651 ticks (143 µs)
adaptive filter above  = 2 km/h → 5.58 Hz                     → max period 35,814,156 ticks (179 ms)
harvest time available = 2 / 698.0 Hz                         = 2.87 ms ;  tick 1 ms × 1.5 = 1.5 ms → OK, no interrupts
```

It sets `irq_enabled` according to `SPEED_ECAP_IRQ_MODE`, `rate_fault` if the tick is too slow and interrupts are not allowed, and `filters_ready = true`. Until this has run once, `Service` leaves events in the buffer (the filters would otherwise be "0 = off").

## C10. `SpeedEcap_Service()` / `SpeedEcap_ServicePg(pg)`

Harvest both channels (short critical section), note the two `head` values, then `ConsumeEvents` with interrupts enabled. Call it on every main-loop pass; at least every 50 ms (the 512-entry buffer holds 367 ms at 250 km/h / 30 PPR).

## C11. `SpeedEcap_ConsumeEvents(pg, head_a, head_b)`

Merges the A and B buffers in time order (each is already sorted): take whichever head is older, `(int32_t)(tsA − tsB) <= 0` → A. Each event goes to:

1. `SpeedEcap_QuadratureStep` (all events of both channels, in time order);
2. `SpeedEcap_SpeedEvent` (its own channel's speed chain).

## C12. `SpeedEcap_QuadratureStep(pg, ch, rising, break)`

- **BREAK, or this channel's level not yet known:** learn the level (= this edge's polarity), do not count. After a BREAK the uncounted step is remembered in `break_step_count` and added back later (C15).
- **Same polarity as the current level:** impossible unless an edge was lost → `quad_error_count + 1`.
- **Otherwise:** set the new level. If the other channel's level is known, compute the step with the rule of A4, add it to `position_q`, update the run of same-direction steps (a sign change is a **reversal**), and confirm the direction when the run reaches 6.

## C13. `SpeedEcap_SpeedEvent(channel, ts, rising, break)`: the glitch filter

```
BREAK:      forget any waiting rising edge; the next accepted rise starts fresh
rising:     remember it as "waiting" (with the break flag)
falling:    if a rising edge is waiting:
               high time = this falling − waiting rising
               high time < minimum width  →  glitch: drop both, glitch_count + 1
               otherwise                  →  AcceptRise(waiting rising)
```

**Minimum width** (`SpeedEcap_MinWidth`) = the larger of:
- 15 % of the period at the glitch limit (143 µs at 30 PPR), always;
- 10 % of a **reference period**, only above 2 km/h, and not directly after a rejection.

The reference period is the **shorter** of:
- the last accepted period;
- the time since the previous rising edge that was judged (accepted or rejected).

Real pulses are high for 30–70 % of the period, so neither limit can reject a real pulse. A ringing glitch lasts microseconds.

**Why it cannot lock.** A filter "locks" when it rejects a real pulse, and because the pulse was rejected its reference never changes, so it rejects the next one too, forever. The first v3 did exactly that after a sudden speed step (v3.1 table at the top):

```
2 km/h: last period 179 ms → min width 17.9 ms
step to 250 km/h: real pulses are high for 0.7 ms → rejected → period never updated → rejected ... forever
```

Three rules make this impossible now:
1. **The reference follows the edges, not only the accepted ones.** Right after the step, the next rising edge comes 1.4 ms after the rejected one, so the reference becomes 1.4 ms and the limit 0.14 ms. At most one pulse is rejected at a step.
2. **Never two adaptive rejections in a row.** After a rejection, only the 143 µs absolute limit applies to the next rising edge.
3. **A stop forgets the old period** (C16), so a wheel that stood still does not start with a stale reference.

A glitch pair is still caught. Its rising edge comes about half a period after the previous real one, so the reference is 0.5 T and the limit 0.05 T, and a 1 µs high time is far below that.

Two shapes of glitch are handled:

```
ringing at a falling edge:  ‾‾‾‾|_|‾|_______      rise' has a tiny high time → dropped
ringing at a rising edge:   ___|‾|_|‾‾‾‾‾‾‾      first rise has a tiny high time → dropped,
                                                 second rise (µs later) accepted
```

## C14. `SpeedEcap_AcceptRise(channel, ts, break)`: the speed chain

```
fresh start if: first edge ever, or restart_pending (stopped), or BREAK
otherwise:      period = ts − last_edge_ts  (unsigned, A5)
                period > 2 s          → fresh start
                period < 0.955 ms     → too fast: glitch_count + 1, ignore
fresh start:    run_id + 1, last_period = 0 (unknown)
else:           last_period = period
last_edge_ts = ts, edge_count + 1
```

`run_id` changes at every fresh start. M/T compares it with the previous window's value and never measures across a restart.

## C15. `SpeedEcap_Evaluate(pg, PPR, D, result)`: once per window

1. Clear the result; config fault if PPR = 0 or D ≤ 0.
2. `UpdateFilters` (C9).
3. **Critical section (µs):** harvest both channels, note heads, read each ECAP's counter as "now", copy overrun and lost counts, copy `tick_calls` and `irq_calls`.
4. `ConsumeEvents` up to the noted heads.
5. `EvaluateChannel` for A and B (C16).
6. Direction = confirmed direction, with mounting inversion.
7. **Lost steps added back:** every event lost in the hardware (or buffer) and every step skipped at a BREAK moved the wheel by a quarter pulse. The new ones since the last window are added to `position_q` in the confirmed direction (nothing is added if the direction is unknown).
8. **Net pulses:** Δ = position − already reported, in quarter pulses. Whole pulses = Δ / 4 (C truncates toward 0); the remainder (−3…+3 quarters) stays for the next window, so the sum over many windows is exact. Size → `net_pulses_in_window`, sign → `net_direction_in_window`.
9. **Quality:** `quad_errors_in_window`, `quad_reversals_in_window`. If there were at least 8 steps and at least every second one was a reversal, A and B are not behaving as a quadrature pair in this window → `direction = UNKNOWN`. A glitch costs 2 reversals in 4+ steps and a real reversal costs 1, so neither triggers this; RDSO 33.4-type signals (A and B at different frequencies) do.
10. **`fault_harvest`:** set when the tick is too slow with interrupts off (`rate_fault`), or when interrupts are off and `tick_calls` has not moved since the last window (the tick is not being called at all).

## C16. `SpeedEcap_EvaluateChannel`

1. A waiting rising edge older than the stop timeout is dropped (A6).
2. **Stopped?** Valid last edge and `now − last_edge_ts > 2 s` → `restart_pending`, speed 0, and the last period and previous-rise reference are forgotten (the glitch filter must not use them when the wheel starts again).
3. **Pulses in window** = (accepted + lost rising edges) − same at last window.
4. Glitches and overruns in the window.
5. If moving: `MeasureFrequency` (C17), then `ApplyDecay` (C18) with the open period: now − last accepted edge, or, if a newer rising edge is waiting, the longer of (waiting − last accepted) and (now − waiting) (A10).
6. `speed_mps = (f / PPR) × π × D`.
7. Save the previous-window copies.

## C17. `SpeedEcap_MeasureFrequency`: M/T in code

```
N = accepted edges now − accepted edges at last window
if N > 0 and the last window had an edge and same run_id and no new overrun:
      f = N × 200,000,000 / (last_edge_ts − prev_edge_ts)        ← M/T (A8)
else if last_period known:
      f = 200,000,000 / last_period                             ← method T
else  f = 0                                                     ← first edge after a start
```

## C18. `SpeedEcap_ApplyDecay`

```
if f > 0 and last_period known and open_period > last_period × 1.125:
      f = min(f, 200,000,000 / open_period)
```

## C19. `SpeedEcap_ApplyInversion`, `SpeedEcap_GetStats`

Inversion swaps FORWARD/REVERSE for a mirrored PG (UNKNOWN stays UNKNOWN). `GetStats` copies the counters `tick_calls`, `irq_calls`, `events_harvested` and, with `SPEED_ECAP_PROFILE = 1`, the worst-case cycles of one tick and one ISR.

---

# PART D — `speed_decision.c`, FUNCTION BY FUNCTION (RDSO TEST 33)

This file answers the RDSO questions: what is the train speed, is a channel broken, is it System Failure, is there slip or slide? It knows nothing about ECAP; every window it receives four speeds in km/h plus a "usable" flag per channel.

## D0. Names, and what changed in v3

| RDSO name | Code index | Physical |
|---|---|---|
| Channel a (RH PG) | `SPEED_DEC_CH_RH_A` (0) | PG1 A, ECAP0 |
| Channel b (RH PG) | `SPEED_DEC_CH_RH_B` (1) | PG1 B, ECAP1 |
| Channel a (LH PG) | `SPEED_DEC_CH_LH_A` (2) | PG2 A, ECAP2 |
| Channel b (LH PG) | `SPEED_DEC_CH_LH_B` (3) | PG2 B, ECAP3 |

Comparator 1 = a(RH) vs a(LH). Comparator 2 = b(RH) vs b(LH). Bit masks: RH-a = 0x1, RH-b = 0x2, LH-a = 0x4, LH-b = 0x8.

**Changes in v3** (all 16 RDSO cases still pass; D9 lists the tests):

| Change | Why |
|---|---|
| Agreement = difference ≤ 1 km/h **+ 0.05 km/h measurement margin** | On the bench, channels set exactly 1 km/h apart (33.2: 99/100, 33.3: 112/113) measure e.g. 1.0006 km/h apart. Without the margin, 33.3 fails end to end |
| New case **c2 (worn wheel)** | RH and LH wheels differ by 1–3 % on a real loco, so both comparators fail all the time. If then one channel dies, nothing agreed → SF. Now: if one PG agrees with itself and one channel of the other PG is within the PG-difference limit of it, the far channel is the failed one |
| **Leaky timers** | A channel flickering around 1 km/h never failed (the timer reset on every good window). Now: +dt while bad, −dt while good. A failed channel is cleared only after agreeing for the timeout |
| **Slip threshold floor 1 km/h** (`SPEED_DEC_SLIP_MIN_KMPH`) | Below 20 km/h, 5 % is less than 1 km/h, so two PGs the comparators accept as equal could be "slip". Set to 0.0 to follow requirement 4 literally. **Confirm with RDSO** |
| **"Cannot be detected" after 1 s** (`SPEED_DEC_UNDETECTABLE_CONFIRM_S`) | At every start, one channel lags for a window. This would send an NMS message at every start. Now the condition must last 1 s |
| `decision_case` output | For the log: which rule decided |

## D1. Small helpers

- `SpeedDec_Abs`, `SpeedDec_Max`.
- `SpeedDec_Agree(input, ch1, ch2)`: both usable and |speed1 − speed2| ≤ 1.05 km/h. An unusable channel (config fault, harvest fault, lost edges this window) never agrees with anything.
- `SpeedDec_HighestOf(input, mask)`: highest usable speed in the mask. RDSO wants the **highest** ("highest of the four speeds"). For supervision this is the safe side: a slightly high reading brakes a little early, never late.
- `SpeedDec_PgThreshold(speed)`: min(5 km/h, 5 % of speed), not below 1 km/h.

## D2. `SpeedDec_FindBadChannel(input, ch1, ch2, good_speed)`

Of two channels, the bad one is the unusable one, or the one further from the good speed. Example 33.5: comparator 2 good at 125. RH-a = 112 (13 away), LH-a = 125 (0 away) → **RH-a** is bad.

## D3. `SpeedDec_DetermineSpeed`: the heart of test 33

```
comparator_1_ok  = Agree(RH-a, LH-a)       comparator_2_ok  = Agree(RH-b, LH-b)
rh_pg_consistent = Agree(RH-a, RH-b)       lh_pg_consistent = Agree(LH-a, LH-b)
```

Cases, checked **in this order**:

| Case | Condition | Speed | Other outputs |
|---|---|---|---|
| a | both comparators OK | highest of 4 | slip/slide detectable |
| b | both PGs internally consistent | highest of 4 | slip/slide detectable (RH ≠ LH is slip/slide or wheel wear) |
| c | exactly one comparator OK | highest of the good comparator | far channel of the bad comparator suspect; slip/slide not detectable |
| c2 | one PG consistent, and one channel of the other PG within the PG limit of it | highest of the three good channels | the far channel suspect; not detectable |
| d | nothing else | highest of 4 (until SF) | malfunction; all suspect |

**Why b before c and d:** in 33.9 (RH 102, LH 100) both comparators fail, but each PG agrees with itself, so the sensors are fine and the axles just turn at slightly different rates. RDSO expects no fault. If b were checked later, a healthy loco would go to SF.

**Why c2 cannot break 33.6:** 33.6 is RH 160/150 (not consistent), LH 125/125 (consistent). RH's channels are 35 and 25 km/h away from 125; the limit is 5 → no channel qualifies → case d → SF, as required.

| Test | a(RH) b(RH) a(LH) b(LH) | Comp1 | Comp2 | RH | LH | Case | Speed |
|---|---|---|---|---|---|---|---|
| 33.2 | 100 99 100 100 | ✔ | ✔ | ✔ | ✔ | a | 100 |
| 33.3 | 112 113 113 112 | ✔ (1.0) | ✔ (1.0) | ✔ | ✔ | a | 113 |
| 33.4 | 115 115 98 115 | ✘ | ✔ | ✔ | ✘ | c | 115, LH-a suspect |
| 33.6 | 160 150 125 125 | ✘ | ✘ | ✘ | ✔ | d | malfunction |
| 33.9 | 102 102 100 100 | ✘ | ✘ | ✔ | ✔ | b | 102 |
| worn + dead | 101.5 101.5 0 100 | ✘ | ✘ (1.5) | ✔ | ✘ | c2 | 101.5, LH-a suspect |

## D4. `SpeedDec_UpdateTimers`: suspect → failed, malfunction → SF

`SpeedDec_Leaky(timer, present, dt, limit)` adds dt while the condition is present, removes dt while it is absent, and keeps the result between 0 and the timeout.

- **Per channel** (not during a malfunction): when its timer reaches the timeout → **failed** (bit in `failed_channel_mask`). When it falls back to 0 → cleared. `new_failed_channel_mask` = failed now but not before, which is the event for **one** log entry and **one** NMS message.
- **Malfunction:** when its timer reaches the timeout → `system_failure_request` latched until re-initialisation (leaving SF is a mode-manager decision), and `system_failure_event` true in that one call.

A tiny epsilon (0.0001 s) is used in the comparisons because 30 × 0.1 in floating point is not exactly 3.0.

```
33.6, timeout 3 s, 0.1 s windows:
t (s):          0.1 ... 2.9   3.0
malfunction:    yes     yes   yes
timer:          0.1     2.9   3.0
SF request:     no      no    YES (event) ... latched
```

## D5. `SpeedDec_CheckPgDifference`: slip/slide by PG difference (33.10–33.13)

Only when both PGs are internally consistent (cases a/b):

```
RH = (RH-a + RH-b) / 2        LH = (LH-a + LH-b) / 2
slip/slide when |RH − LH| > PgThreshold(max(RH, LH))
```

| Speed | 5 % | Limit (min 5, 5 %, floor 1) | Example | Result |
|---|---|---|---|---|
| 100 | 5.0 | 5.0 | 102 vs 100 (33.9) | no |
| 50 | 2.5 | 2.5 | 53 vs 50 (33.10) | slip/slide |
| 150 | 7.5 | 5.0 | 156 vs 150 | slip/slide |
| 10 | 0.5 | **1.0** | 10.9 vs 10.0 | no (was "slip" before v3) |

**Slip or slide, which wheel?** Two PGs can show *that* they differ, not *which* is wrong. The code uses history: while there is no difference, it keeps the train speed as `reference_speed_kmph`. When a difference appears, the PG that moved **away** from the reference is the faulty one: moved up → **SLIP**, moved down → **SLIDE**. 33.10: reference 50, LH goes to 53 → LH, up → SLIP. 33.12: LH to 47 → SLIDE. The classification is fixed at the start of an episode. Without a reference (the test started already unequal), the sign of the train acceleration decides.

**A dead PG looks like a slide.** A locked wheel and a dead PG both read 0 while the other PG reads the train speed. Speed alone cannot tell them apart, so both give SLIDE → SR after the timeout. That is the safe reaction for both.

## D6. `SpeedDec_CheckAcceleration`: slip/slide by acceleration (33.16)

Every window adds dt; once 1 s has passed, a = ((speed now − speed 1 s ago) / 3.6) / elapsed, and a new 1 s measurement starts. > +1 m/s² → SLIP, < −1 m/s² → SLIDE. Over 1 s, not per window: with 0.1 s windows a small step divided by 0.1 s would be magnified 10×.

**Bench note.** A generator switched from 0 to 80 km/h in one step is a 22 m/s² "acceleration". The code correctly reports SLIP for about 1 s (and SLIDE when the generator is switched off). It never lasts long enough for SR. The end-to-end simulation shows this at the start of every test (H6). To avoid it on the bench, ramp the generator at less than 3.6 km/h per second, or start it before the test.

## D7. `SpeedDec_SlipSlide`: combine, events, timeout

1. Always update the acceleration.
2. Detectable (a/b) and both PGs consistent → PG difference. Not detectable (c/c2/d) → no slip, and after 1 s continuously → `slip_slide_undetectable_event` once (33.15).
3. PG-difference result has priority (it names the wheel), otherwise acceleration.
4. State NONE → SLIP/SLIDE: `slip_detected_event` (DMI; slide also log + NMS). While it lasts, the timer runs. At the slip/slide timeout: `sr_request_event` once (SR prompt erasing direction, log, NMS). Back to NONE: everything reset.

**States and events.** A *state* ("slip is present") drives what the DMI shows. An *event* ("slip just started") drives one log line and one NMS message.

## D8. `SpeedDecision_Init` / `SpeedDecision_Update`

Init clears the state and stores the two timeouts. Update runs `DetermineSpeed` → `UpdateTimers` → `SlipSlide` (slip/slide needs to know whether the channels are healthy).

## D9. The test program `speed_decision_test_rdso33.c`

```
gcc -std=c99 -Wall speed_decision_test_rdso33.c speed_decision.c -o t33 && ./t33
```

It checks:
- **33.1–33.16** from the tables;
- **timing:** channel failure exactly at 3.0 s (not at 2.9 s) and the event only once; SF exactly at 3.0 s and latched;
- **regressions R1–R6:**
  - R1: worn wheels + dead channel → failure, not SF;
  - R2: a flickering channel fails;
  - R3: a failed channel clears only after agreeing for the timeout;
  - R4: no slip at 10.9 vs 10.0 km/h;
  - R5: no "cannot be detected" event on a start transient;
  - R6: an intermittent malfunction still reaches SF.

Result: **checks passed 111, failed 0**. Run it after any change.

---

# PART E — `speed_sensor_user.c` (KAVACH GLUE) AND THE BENCH TEST

## E1. Wiring table

PG1 (RH) = ECAP0/ECAP1, Input XBAR 0/1, INT XBAR 22/23. PG2 (LH) = ECAP2/ECAP3, XBAR 2/3, INT 24/25. `invert_direction` per PG, set after calibration on the loco (integration guide).

## E2. The four entry points

| Function | When | What |
|---|---|---|
| `SpeedSensor_Init()` | once, after `Drivers_open()` and after `loco_info` is loaded | `SpeedEcap_Init`, one `Evaluate` per PG so the filters know PPR/diameter, `SpeedDecision_Init` |
| `SpeedSensor_Tick()` | every 1 ms, from the RTI ISR or a ClockP callback | `SpeedEcap_Tick()` |
| `SpeedSensor_Service()` | every main-loop pass | `SpeedEcap_Service()` |
| `CalculateWheelSpeed_ECAP()` | every `SPEED_SAMPLING_TIME` | E3 |

Service and CalculateWheelSpeed_ECAP must run in the same task.

## E3. `CalculateWheelSpeed_ECAP()`

| Step | What | Why |
|---|---|---|
| 1 | `SpeedEcap_Evaluate` for PG1 and PG2 with each PG's PPR and diameter | Per-channel speed, net pulses, direction, quality |
| 2 | Channel speeds → `loco_params.speed_sensor1_1/1_2/2_1/2_2` (m/s) | Same fields as before |
| 3 | `SpeedSensor_RunDecision` | RDSO 33 (Part D) |
| 4 | `SpeedSensor_SelectDirection` → `loco_params.sensor_direction` | E5 |
| 5 | Net pulses per PG; a PG with a suspect channel takes the other PG's count | Distance from a trustworthy PG |
| 6 | Pulse-zero flags from the **raw** channel pulses | A turning wheel always gives raw pulses, even when its A/B pair cannot be decoded (v2 used NET, which is 0 in that case) |
| 7 | Log lines | E7 |
| 8 | `CalculateTrainSpeedEQEP(pg1, pg2)` | Existing distance/rollback/TLM chain |
| 9 | `PublishHealth`, then `ReportDecisionEvents` | After step 8, because step 8 resets `is_speed_sensor_fail` |

## E4. `SpeedSensor_RunDecision`

Speeds to km/h. A channel is **unusable** when its PG has a config fault, a harvest fault (tick missing or too slow), or the channel lost edges this window. `dt = SPEED_SAMPLING_TIME`. The decided speed is read with `SpeedSensor_GetTrainSpeedKmph()`, and the full decision with `SpeedSensor_GetDecision()`.

## E5. Direction selection

A PG does not vote if it has a suspect channel (33.4/33.5/33.14/33.15) or if its A/B pair did not behave as quadrature this window (the ECAP module reports UNKNOWN). Then:
- both known and equal → use it;
- both known and different → keep the previous direction, and after 2 windows call `SpeedSensor_HookDirectionMismatch`;
- one known → use it;
- none → keep the previous one (like EQEP at standstill).

## E6. Health and events

`speed_sensorN_health = 0` when a channel of that PG has **failed** (after the timeout), or the PG has a config or harvest fault. System Failure comes only from the decision (33.6) and is re-asserted every window. Hooks:

| Decision output | Hook | RDSO |
|---|---|---|
| bit in `new_failed_channel_mask` | `HookChannelFailure(ch)`: log + NMS "Channel x (PG) failure" | 33.4/5/14/15 |
| `system_failure_event` | `HookSystemFailure()` | 33.6 |
| `slip_slide_undetectable_event` | `HookSlipSlideUndetectable()` | 33.15 |
| `slip_detected_event` | `HookSlipSlideDetected(state, source, pg)`: DMI; slide also log + NMS | 33.10/12/16 |
| `sr_request_event` | `HookSlipSlideTimeout(state)`: SR prompt erasing direction, log, NMS | 33.11/13/16 |
| direction mismatch 2 windows | `HookDirectionMismatch(d1, d2)` | not in test 33 |

## E7. Reading the log line

```
PG1 A:[279.22 Hz 100.00 kmph 279 p] B:[279.22 Hz 100.00 kmph 279 p] NET:[279 p dir 1] DIR:[1] QE:[0] QR:[0] GL:[0/0] OVR:[0/0] H:[0] IRQ:[0] CASE:[0]
```

| Field | Meaning | Healthy |
|---|---|---|
| `A:[f Hz v kmph n p]` | Channel A frequency, speed, real pulses this window | A ≈ B |
| `NET:[n p dir d]` | Net movement in whole pulses and its sign | n ≈ pulses when moving one way |
| `DIR:[d]` | Confirmed direction (1 forward, −1 reverse, 0 unknown) | steady |
| `QE:[n]` | Quadrature errors (only after lost edges) | 0 |
| `QR:[n]` | Step reversals: 2 per glitch, 1 per real reversal | 0 in clean running |
| `GL:[a/b]` | Glitches rejected per channel | 0. Non-zero means a noisy input: check wiring / signal conditioning |
| `OVR:[a/b]` | Loss detections per channel | 0. Non-zero means the tick or main loop was blocked too long |
| `H:[h]` | Harvest fault (tick missing or too slow) | 0 |
| `IRQ:[i]` | ECAP interrupts in use for this PG | 0 at 30 PPR |
| `CASE:[c]` | Decision case: 0 a, 1 b, 2 c, 3 c2, 4 d | 0 or 1 |

## E8. `ecap_speed_test.c` (LaunchPad bench test)

Same entry name as the old test (`ecap_capture_pwm_main`). It:
- opens the drivers and runs `SpeedEcap_Init`;
- primes the filters with **30 PPR** / 0.95 m (it said 120 in v2, which would print every speed 4× too low on a 30 PPR generator);
- starts a **1 ms ClockP callback** that calls `SpeedEcap_Tick()`;
- calls `SpeedEcap_Service()` continuously, and every second prints one line per PG plus a STATS line: ticks, ECAP interrupts and events harvested in that window, and the worst tick/ISR cycles when profiling is on.

---

# PART F — FOLLOWING PULSES THROUGH THE SYSTEM

## F1. One normal pulse at 100 km/h

1. PG1-A rises. ECAP0 is waiting on page 3 (rising): the counter value, say **1,000,000**, goes into CAP3 and CEVT3 is set. No interrupt.
2. Half a period (1.79 ms = 358,142 ticks) later A falls: the ECAP is now waiting on page 4 (falling), which gets 1,358,142. CEVT4 set.
3. Within 1 ms the tick harvests: both flags set, read page 3 then page 4, already in time order, oldest entry is in the expected page → no loss. Push (1,000,000, rising), (…, falling).
4. The main loop's `Service` merges A and B events by time:
   - **Quadrature:** A rises while B is low (state 00 → 10): new A (1) ≠ B (0) → **+1**. The B rise 0.9 ms later (10 → 11): new B = A → **+1**. And so on: 4 steps per pulse.
   - **Speed chain:** the A rise waits. When the A fall arrives, high time = 1.79 ms ≫ 143 µs → accepted. Period = 1,000,000 − 283,717 = 716,283 ticks.
5. At the end of the 1 s window, `Evaluate`: N = 279 accepted rises over 199,842,992 ticks → 279.219 Hz → **100.00 km/h**. Position advanced 1116 quarters → NET 279 pulses, direction FORWARD.
6. The other three channels give the same. Both comparators agree → case a → train speed 100.00, no failure, no slip.

## F2. A glitch at a falling edge (your board's problem)

```
A:  ‾‾‾‾‾‾‾‾|_|‾|____________|‾‾‾‾
            F  R' F'          R (next real)
```

- Quadrature: F (+1), R' (−1), F' (+1) → net +1, which is the real fall. `QR` + 2.
- Speed chain: R' waits; F' arrives 1 µs later → high time 1 µs < 143 µs → R' and F' dropped, `GL` + 1. The next real R is measured from the last accepted rise: exactly one period. M/T unchanged, speed unchanged, pulse count unchanged.

## F3. A lost edge (tick blocked)

The tick and main loop are blocked for 5 ms at 250 km/h (7 edges on A). The hardware keeps capturing and overwrites 3 pages. The next harvest reads e5 (page 1), e6 (page 2), e7 (page 3), e4 (page 4); sorted e4 e5 e6 e7. The oldest (e4) is in page 4 but page 1 was expected → **3 events lost** (2 rising, 1 falling).
- `OVR` + 1;
- pulses + 2 (the lost rises);
- BREAK on e4, so no period is measured across the gap and M/T is not used this window (method T instead);
- the quadrature decoder re-learns A's level at e4, and the 3 lost events + 1 skipped step are added back in the confirmed direction;
- the decision layer treats this channel as unusable for this one window.

Pulse count and NET stay exact.

## F4. Reverse with a distorted PG1 (the problem in your first log)

PG1 forward phase 20 %, A high 55 %, B high 45 %. Going backwards the state sequence is 00 → 01 → 11 → 10 → 00. Each edge: e.g. B rises from 00 → new B (1) ≠ A (0) → **−1**. All four steps per pulse are −1, whatever the duty cycles. `DIR = −1` after 6 steps (1.5 pulses), NET = −84 pulses per second at 30 km/h, `QE = 0`, `QR = 0`. v2 on the same signal: 32 phase errors per second, NET −51.

## F5. RDSO 33.4 on the bench

The generator gives LH-a = 98, all others 115.
- **ECAP layer:** PG2's A and B run at different frequencies, so its quadrature steps flip sign constantly → `QR` high, PG2 direction UNKNOWN. Expected.
- **Decision:** comparator 1 (115 vs 98) fails, comparator 2 (115 vs 115) OK → case c, speed **115**, LH-a suspect. After 1 s: "slip/slide cannot be detected" (once).
- **Glue:** PG2 is ignored for direction; PG2's distance is replaced by PG1's.
- **After the timeout (3 s):** LH-a **failed**, one "Channel a (LH PG) failure" hook, `speed_sensor2_health = 0`. No System Failure.

The end-to-end simulation reproduces exactly this: failure event at 3.0 s after the step, speed 115.00 (H6).

## F6. Stop, then roll back

The train stops. Speed slides down (decay) and becomes 0 after 2 s. The direction stays FORWARD (last known, like EQEP). The loco starts rolling back at 2 km/h:
- the first edges re-learn the levels;
- from then on every step is −1: NET counts backwards from the first decodable edge;
- after 6 steps (1.5 pulses, 15 cm), DIR = −1.

Simulation: direction REVERSE about 0.5 s after the rollback started (v2: about 0.9 s, with wrong-direction windows before that). Distance error −0.6 pulses.

---

# PART G — THE 1–2 km/h DIFFERENCE: WHERE IT CAME FROM, WHY IT IS GONE

## G1. What the log shows

In your first board log (the older build, before the spurious filter), PG1 read 101.87 km/h while the generator gave 100.08 (1.8 km/h). The pulse count shows why: 285 pulses instead of 280. Five extra rising edges, i.e. glitches at the falling edges (A9: 5 fake edges × 0.36 km/h). In 0.1 s windows the same glitches gave 15.01 → 18.76 and 100.08 → 103.66 km/h. And because the train speed is the **highest** channel, one noisy channel is enough to raise the train speed.

## G2. Why v3 does not have it

1. **A fake edge is never counted.** The glitch filter accepts a rising edge only after its falling edge shows a real pulse width (C13). The quadrature decoder cancels glitches by itself (A4).
2. **M/T is exact** (A8): no ±1 pulse window quantisation. Only edge jitter remains, 0.002 km/h at 0.1 s windows with 2 µs jitter.
3. **The v2 failure modes are gone:** a missing edge or a fast speed change could lock v2's filter and read up to 50 % low for ~50 ms. v3 cannot lock (C13).

Simulation, 100 km/h, glitches on 5 % of falling edges plus 5 % bounce on rising edges, 2 µs jitter: **all four channels within 0.000 km/h** (1 s windows) and **0.002 km/h** (0.1 s windows) of the true speed.

## G3. Differences that are real and remain

| Cause | Size | What to do |
|---|---|---|
| RH and LH wheel diameters differ (wear) and `loco_wheel_dia1/2` are not set per wheel | 1 % diameter = 1 km/h at 100 km/h, between PG1 and PG2 | Enter the measured diameter per PG. The decision handles it (case b / c2) either way |
| Speed changing during the window | The four channels' spans are offset by fractions of a period | Physical; negligible at real accelerations |
| Start and stop transients | First window after a start (one period), decay at a stop | Physical; the decision layer debounces |
| **Any speed computed downstream from pulse counts** (method M), e.g. inside `CalculateTrainSpeedEQEP()` | ±1 pulse per window = **±0.36 km/h at 1 s, ±3.6 km/h at 0.1 s** | Use `SpeedSensor_GetTrainSpeedKmph()` (or the per-channel ECAP speeds) for display, supervision and the stationary packet. Use pulse counts only for distance (integration guide, step 6) |

If you still see 1–2 km/h after integrating v3, check the log line: `GL` > 0 means glitches (being removed correctly), `OVR` > 0 means lost edges, and a difference between the `PGx A:[… kmph]` values and the displayed speed means the displayed speed comes from somewhere else (last row of the table).

---

# PART H — REFERENCE

## H1. Numbers at 30 PPR, 0.95 m, 200 MHz

| Item | Value | From |
|---|---|---|
| Distance per pulse / per quadrature step | 9.95 cm / 2.49 cm | π × 0.95 / 30, ÷ 4 |
| Timestamp resolution | 5 ns | 1 / 200 MHz |
| Counter wrap / signed limit | 21.47 s / 10.74 s | 2³², 2³¹ ticks |
| Stop timeout | 2 s (max 8 s) | `SPEED_ECAP_STOP_TIMEOUT_MS` |
| Lowest visible speed | 0.18 km/h | 1 pulse per 2 s |
| Glitch limit | 0.955 ms (375 km/h) | 250 × 1.5 |
| Minimum pulse width | 143 µs, or 10 % of the period above 2 km/h | C13 |
| Direction confirmation | 6 steps = 1.5 pulses ≈ 15 cm | `SPEED_ECAP_DIR_CONFIRM_STEPS` |
| Tick / ECAP interrupts | 1 ms / 0 per second (up to 57 PPR) | B3 |
| ECAP buffer | 4 edges = 2 periods (2.87 ms at 250 km/h) | B2 |
| Software buffer | 512 events per channel = 367 ms at 250 km/h | `SPEED_ECAP_RING_SIZE` |
| Channel agreement | ≤ 1 km/h + 0.05 margin | D0 |
| PG-difference slip/slide | > min(5 km/h, 5 %), floor 1 km/h | D5 |
| Acceleration slip/slide | > 1 m/s² over 1 s | D6 |

## H2. Settings

| Setting | Raise it | Lower it |
|---|---|---|
| `SPEED_ECAP_STOP_TIMEOUT_MS` | Slower speeds visible; "0" later after a stop (max 8000) | "0" sooner; lowest visible speed rises |
| `SPEED_ECAP_TICK_PERIOD_US` | Must match how often you call Tick. Larger → ECAP interrupts needed at lower PPR | Smaller → higher PPR without ECAP interrupts |
| `SPEED_ECAP_IRQ_MODE` | ALWAYS: interrupts plus tick | OFF: never; `fault_harvest` if the tick is too slow |
| `SPEED_ECAP_RING_SIZE` | More RAM; tolerates a slower main loop | Less RAM; Service must run more often |
| `SPEED_ECAP_MIN_PULSE_ABS_PERCENT` | Rejects longer glitches | Keeps narrower real pulses (only needed below 15 % duty) |
| `SPEED_ECAP_DIR_CONFIRM_STEPS` | Steadier direction, slower rollback detection | Faster, more sensitive to noise |
| `SPEED_ECAP_PROFILE` | 1: measure tick/ISR cycles | 0: production |
| `SPEED_DEC_SLIP_MIN_KMPH` | Fewer low-speed slip reports | 0.0 = requirement 4 literally |
| `SPEED_DEC_UNDETECTABLE_CONFIRM_S` | Fewer NMS messages at starts/stops | Faster report |
| `SPEED_SENSOR_SPEED_SENSE_TIMEOUT_S`, `_SLIP_SLIDE_TIMEOUT_S` | From the FRS | From the FRS |

## H3. Files

| File | Role | Hardware? |
|---|---|---|
| `speed_sensor_ecap.c/.h` | ECAP capture, speed, direction, distance | yes |
| `speed_decision.c/.h` | RDSO test 33 logic | no (pure C) |
| `speed_decision_test_rdso33.c` | Host test, 111 checks | no |
| `speed_sensor_user.c/.h` | Kavach glue | uses Kavach globals |
| `ecap_speed_test.c` | LaunchPad bench test | yes |

## H4. API changes from v2 (for code that used v2)

| v2 | v3 |
|---|---|
| — | `SpeedEcap_Tick()` **new, must be called every 1 ms** |
| — | `SpeedEcap_GetStats()` new |
| `result->phase_errors_in_window` | `quad_errors_in_window` + `quad_reversals_in_window` |
| `channel_x.spurious_in_window` | merged into `glitches_in_window` |
| `channel_x.is_moving` | removed (never read) |
| `consecutive_fault_windows`, `fault_pulse_mismatch`, `fault_speed_mismatch`, `fault_phase`, `fault_overrun`, `is_healthy` | removed (the glue ignored them; see H5) |
| — | `fault_harvest`, `irq_enabled` new |
| glue `SpeedSensor_Tick()`, `SpeedSensor_GetDecision()`, `SpeedSensor_HookDirectionMismatch()` | new |
| decision `decision_case` | new output |

## H5. Removed variables (the "unused / log-only" review)

| Removed | Why |
|---|---|
| `is_moving` | Written every window, read by nobody |
| result `consecutive_fault_windows` | Copied into the result, read by nobody |
| `SpeedEcap_CheckHealth()`, `fault_pulse_mismatch`, `fault_speed_mismatch`, `fault_phase`, `fault_overrun`, `is_healthy`, and the 8 constants `PULSE_MISMATCH_*`, `SPEED_MISMATCH_*`, `SPEED_CHECK_MIN_KMPH`, `PHASE_ERROR_LIMIT`, `FAULT_CONFIRM_WINDOWS`, `PHASE_FAULT_ENABLE` | The glue deliberately ignored them (RDSO 33 decides what a failure is). Code that looks like a safety check but does nothing would be flagged in an assessment |
| `spurious_count`, `spurious_score`, `SPURIOUS_PERIOD_PERCENT` | The ratio filter is replaced by the width filter |
| phase constants `PHASE_*_PERCENT`, `last_raw_phase`, `agree_count`, `b_count_at_last_a` | Phase method replaced by the state decoder |
| glue `direction_fault` print-only path | Now calls `SpeedSensor_HookDirectionMismatch` |

**Kept on purpose** (used, or the only bench diagnostics): `frequency_hz` (log), `glitches_in_window`, `overruns_in_window` (makes a channel unusable), raw `pulses_in_window` (pulse-zero flags), `quad_*_in_window` (direction gating, log), `net_direction_in_window`, `sr_request` (state for the mode manager), `acceleration_mps2` and the comparator flags (test and log).

## H6. Test results

**Host simulation** (stubbed TI driver, simulated ECAP registers, synthetic PG signals; v2 and v3 on identical signals):

| Scenario | v2 | v3 |
|---|---|---|
| 100 km/h clean | 279 ECAP int/s, exact | **0 int/s**, exact |
| 100 km/h, 5 % glitches at falling + 5 % bounce at rising edges, 2 µs jitter | exact speed | exact speed, `GL` counts them |
| Reverse 30 km/h, PG1 duty 55/45 | 32 phase errors/s, −95 pulses in 3 s | 0 errors, exact |
| Reverse 30 km/h, PG1 duty 65/35 (not decodable) | **FORWARD**, +407 pulses | UNKNOWN, no false movement |
| One real pulse missing at 100 km/h | 4 windows wrong direction, −22 pulses | 0, −1 (the missing pulse) |
| Wheel spin 0 → 20 km/h in 0.5 s | one channel per PG half speed, PG2 REVERSE | correct |
| Step 50 → 100 km/h | −7 pulses | −1.8 (start-up only) |
| Stop, roll back at 2 km/h | 4 windows wrong direction | 0 |
| Interrupts, tick and main loop blocked 1–30 ms at 250 km/h | loss unflagged from 24.5 ms, up to 14 pulses lost | every loss flagged, pulses and NET exact |
| 25 s standstill (longer than the counter wrap), restart | — | no false overrun, correct speed |
| **Step 1 → 250 km/h** (your bench symptom) | — | first v3: PG2 both channels 0 km/h permanently. v3.1: 250.00 from the next window |
| **Step 3 → 250 km/h** | — | first v3: all four channels 0 km/h permanently. v3.1: 250.00 from the next window |
| Steps 0…200 → 250 and 250 → 0…200 km/h, glitches 3 %, 2 µs jitter | — | v3.1: every channel exact from the first full window after the step, 0 false overruns, distance −1/−2 pulses (start-up offset) |
| Constant 250 km/h with glitches 3 % | — | first v3: 2–6 false overruns per window, +25 pulses. v3.1: 0 overruns, exact |
| 120 PPR at 250 km/h with a 1 ms tick | 2792 int/s | 5584 int/s (auto fallback; use a 0.25 ms tick instead: 0 ECAP int) |

**End to end** (generator-like signals → v3 ECAP → decision, 0.1 s windows, timeouts 3 s / 5 s): all 16 RDSO cases give the expected speed, failed channel, SF, slip/slide state and PG, and SR timing:
- 33.4: LH-a failed exactly 3 s after the step;
- 33.6: SF at 3 s;
- 33.11/33.13: SR 5 s after the slip/slide;
- 33.16: SR 5 s after 12:24:02.

The only extra output is the 1 s start-up SLIP from the generator step (D6).

**Decision host test:** 111 checks, 0 failed.

The simulator (`sim3.c`, `e2e.c`, stub headers) is in the review package if you want to re-run any of this.

## H7. Glossary

| Word | Meaning |
|---|---|
| PG | Pulse generator: toothed disc + two sensors on an axle |
| PPR | Pulses per revolution (per channel) |
| Pulse | One tooth: one rise and one fall |
| Quadrature | Two signals about a quarter period apart |
| State (A,B) | The two levels; 00 → 10 → 11 → 01 forward |
| Step | One edge = a quarter pulse, +1 or −1 |
| Tick (timer) | The 1 ms call of `SpeedEcap_Tick()` |
| Tick (ECAP) | One count of the 200 MHz clock = 5 ns |
| Harvest | Copying capture registers into the buffer |
| BREAK | "Edges were lost here": no period measured across |
| Glitch pair | A rise and fall microseconds apart: not a pulse |
| M/T method | f = N edges / exact time those N periods took |
| Decay | Capping the speed at 1 / (time since last edge) when the next edge is overdue |
| run_id | Number of the current unbroken chain of accepted edges |
| Comparator (RDSO) | Same-letter channels of RH and LH PG |
| Suspect / failed | Disagreeing now / disagreeing longer than the timeout |
| SF / SR | System Failure mode / Staff Responsible mode |
| Slip / slide | Wheel spinning (reads fast) / locked (reads slow) |
