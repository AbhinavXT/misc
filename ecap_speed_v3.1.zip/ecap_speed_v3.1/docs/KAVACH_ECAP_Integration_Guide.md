# Integrating the ECAP Speed Module (v3) into the Kavach Onboard Code

**Goal:** replace the EQEP-based speed measurement with the ECAP module. It measures four independent channel speeds, direction from x4 quadrature decoding, and distance, and it makes the RDSO SIF-0533 test 33 decisions.

**Read with:** `ECAP_Speed_Code_Explained_updated.md` (how and why it works).

**Time needed:** about a day of integration and a day on the bench, plus calibration on the loco.

---

## 0. Before you start: three numbers to check

| Check | Where | Why it matters |
|---|---|---|
| **PPR of the loco's PG** (`loco_info.tacho_output_pulse_per_rev1/2`) | loco configuration | With a 1 ms tick, up to **57 PPR** needs no ECAP interrupts (0.95 m wheel, 250 km/h). Above that, either call the tick faster (0.5 ms → 114 PPR, 0.25 ms → 229 PPR) or the module switches ECAP interrupts on automatically (B4 of the explanation) |
| **Period of your fastest existing periodic interrupt or timer** (RTI tick, ClockP tick) | syscfg / RTI setup | It will call `SpeedSensor_Tick()`. It must be steady; 1 ms is the default assumption (`SPEED_ECAP_TICK_PERIOD_US`) |
| **`SPEED_SAMPLING_TIME`** | Kavach config | The window length. `CalculateWheelSpeed_ECAP()` must be called at exactly this period |

If the PPR is above 57 and you have no faster tick, you do not have to change anything else. The module turns on ECAP interrupts by itself, and `IRQ:[1]` appears in the log. Just make sure the four ECAP interrupts get a high priority (step 2).

---

## 1. Files

**Add to the Kavach project:**

| File | Notes |
|---|---|
| `speed_sensor_ecap.c`, `speed_sensor_ecap.h` | ECAP driver. No Kavach dependencies |
| `speed_decision.c`, `speed_decision.h` | RDSO 33 logic. Pure C |
| `speed_sensor_user.c`, `speed_sensor_user.h` | Kavach glue. Includes `common_include.h` and `ti_drivers_config.h` |

**Keep out of the target build:** `speed_decision_test_rdso33.c` (host test), `ecap_speed_test.c` (LaunchPad bench test only).

**Remove or stop calling:**
- `CalculateWheelRPM_EQEP()`, `CalculateWheelRPM_Generic()`, `DetermineTrainSpeed()` and the EQEP init code;
- any EQEP interrupt handlers for the speed sensors;
- the old ECAP test file (`ecap_capture_pwm.c`) if it is in the project.

**Globals the glue uses** (they must exist with these names, or adapt `speed_sensor_user.c`):

```
loco_info.tacho_output_pulse_per_rev1/2     loco_info.loco_wheel_dia1/2 (mm)
loco_params.speed_sensor1_1/1_2/2_1/2_2 (m/s) loco_params.sensor_direction (NOMINAL_DIR / REVERSE_DIR)
loco_params.loco_health.speed_sensor1_health / speed_sensor2_health
loco_mode_transition_conditions.is_speed_sensor_fail / is_pg1_pulse_zero / is_pg2_pulse_zero
data_logger_conditions.is_both_speed_sensor_fail
SPEED_SAMPLING_TIME, MPS_TO_KMPH, EQEP_PRINTF, MISC_PRINTF
CalculateTrainSpeedEQEP(double pg1_pulses, double pg2_pulses)
```

---

## 2. syscfg

| Item | Setting |
|---|---|
| ECAP instances | `CONFIG_ECAP0` … `CONFIG_ECAP3` enabled (names must give `CONFIG_ECAPn_BASE_ADDR`). Mode and polarity do not matter: `SpeedEcap_Init()` reprograms them |
| Input XBAR | XBAR 0 ← PG1-A pin, 1 ← PG1-B, 2 ← PG2-A, 3 ← PG2-B (on the LaunchPad: GPIO33/34/119/120) |
| Pins | GPIO input; pull-ups/downs as your PG interface circuit requires. The pins must not also be muxed to EQEP |
| Interrupt XBAR | 22 ← ECAP0 INT, 23 ← ECAP1, 24 ← ECAP2, 25 ← ECAP3. Keep them even if unused: the module registers the handlers and enables them only if needed |
| ECAP interrupt priority | If they can ever be used (PPR > 57 at 1 ms tick): the **same, high** priority for all four (the ISR is a few register reads). Set `hwi_params.priority` in `SpeedEcap_RegisterInterrupt()` if syscfg does not own it |
| ECAP clock | 200 MHz. If different, change `SPEED_ECAP_CLOCK_HZ` |
| EQEP | Disable the EQEP instances previously used for speed |

If your channel-to-ECAP wiring differs, change `gSpeedSensorPgConfig[]` in `speed_sensor_user.c` (base address, XBAR input, interrupt number per channel).

---

## 3. Initialisation

Order matters: drivers open → loco configuration loaded (PPR and wheel diameters) → `SpeedSensor_Init()` → start the tick.

```c
#include "speed_sensor_user.h"

/* after Drivers_open(), Board_driversOpen() and after loco_info is loaded */
if(SpeedSensor_Init() != SystemP_SUCCESS)
{
    /* No speed measurement. CalculateWheelSpeed_ECAP() will keep
     * is_speed_sensor_fail = 1. Log it. */
}
```

`SpeedSensor_Init()` runs one evaluation straight away so the filters know PPR and diameter. If `loco_info` is loaded later (e.g. from NVM after a delay), the first real `CalculateWheelSpeed_ECAP()` also updates them. In the meantime events are buffered, not lost.

---

## 4. The 1 ms tick: `SpeedSensor_Tick()`

This is what removes the ECAP interrupts. It must be called every `SPEED_ECAP_TICK_PERIOD_US` (default 1000 µs) from a periodic context. It is safe in ISR context, takes its own short critical section (a few µs), and does register reads only.

**Option A: an existing timer ISR (preferred when you have one).** If the Kavach code has a 1 ms RTI compare interrupt (for timekeeping, scheduling etc.), add one line at its end:

```c
void Rti1msIsr(void *args)          /* your existing handler */
{
    /* ... existing work ... */
    SpeedSensor_Tick();
}
```

**Option B: a ClockP callback.** No new interrupt source; it uses the DPL tick:

```c
#include <kernel/dpl/ClockP.h>

static ClockP_Object gSpeedTickClock;

static void SpeedTickCallback(ClockP_Object *obj, void *args)
{
    (void)obj; (void)args;
    SpeedSensor_Tick();
}

void SpeedTick_Start(void)
{
    ClockP_Params params;

    ClockP_Params_init(&params);
    params.callback = SpeedTickCallback;
    params.args     = NULL;
    params.timeout  = ClockP_usecToTicks(SPEED_ECAP_TICK_PERIOD_US);
    params.period   = ClockP_usecToTicks(SPEED_ECAP_TICK_PERIOD_US);
    params.start    = 1;
    (void)ClockP_construct(&gSpeedTickClock, &params);
}
```

- **NoRTOS:** ClockP callbacks run in the DPL tick interrupt, so the period is exact.
- **FreeRTOS:** ClockP callbacks run in the timer service task. Give that task a high priority so it is never delayed by more than ~1 ms. Check your SDK version's ClockP documentation for the exact field names.
- The DPL tick must be 1 ms (or change `SPEED_ECAP_TICK_PERIOD_US` to match).

**Option C: high PPR.** Use a dedicated RTI compare at 250 or 500 µs calling only `SpeedSensor_Tick()`, and set `SPEED_ECAP_TICK_PERIOD_US` accordingly.

**How you know it works:** `H:[0]` in the log line (see step 10). If the tick is not called, `H:[1]` appears within one window, the channels become unusable, and the RDSO logic goes to System Failure after the timeout. A missing tick can never go unnoticed.

---

## 5. Main loop / speed task

```c
/* every pass of the main loop (at least every 50 ms) */
SpeedSensor_Service();

/* every SPEED_SAMPLING_TIME, at a fixed rate (replaces CalculateWheelRPM_EQEP()) */
if(speed_window_elapsed)
{
    CalculateWheelSpeed_ECAP();
}
```

Rules:
- **`SpeedSensor_Service()` and `CalculateWheelSpeed_ECAP()` must run in the same task** (or the same main loop). Both process the same buffers without a lock.
- Call `CalculateWheelSpeed_ECAP()` at a fixed rate. The window is "time between two calls", and `dt = SPEED_SAMPLING_TIME` is used by the timers.
- `SpeedSensor_Service()` can be called as often as you like; with nothing new it costs a few register reads. The buffer holds 367 ms of edges at 250 km/h (30 PPR), so a pass that takes up to ~100 ms (flash write, long print) is fine.

---

## 6. Changes inside `CalculateTrainSpeedEQEP()` (and anything that computes speed)

The ECAP module now makes the speed, failure and slip/slide decisions. The old logic must not make them a second time with different rules.

| # | Change | Why |
|---|---|---|
| 6.1 | **Remove** the rule "PG1 speed vs PG2 speed ≥ 5 km/h → `is_speed_sensor_fail`" | A PG difference is slip/slide → SR (33.11/33.13), not SF. A real slip of > 5 km/h would otherwise force SF |
| 6.2 | **Remove or bypass** its own slip/skid (acceleration) detection | Slip/slide comes from `speed_decision.c`. Two detectors with different rules disagree; the first board log shows false slip/skid events from the old one |
| 6.3 | **Do not compute a speed from the pulse counts** for display or supervision. If it does (pulses / window × distance per pulse), replace it with `SpeedSensor_GetTrainSpeedKmph() / 3.6` | Pulse counts per window are method M: ±1 pulse = ±0.36 km/h at 1 s windows, ±3.6 km/h at 0.1 s. This is one source of "1–2 km/h difference" (explanation, Part G) |
| 6.4 | **Keep** distance from the pulse counts it receives (`pg1_pulses`, `pg2_pulses` = net quadrature pulses, one window, whole pulses) and direction from `loco_params.sensor_direction` | Distance per pulse = π D / PPR. The glue already swaps in the other PG's count when a PG has a suspect channel |
| 6.5 | If it resets `is_speed_sensor_fail`, leave the glue's call order as it is | The glue re-asserts SF after `CalculateTrainSpeedEQEP()` |

---

## 7. Speed for supervision and for stationary Kavach

Use **`SpeedSensor_GetTrainSpeedKmph()`** everywhere a train speed is needed:
- the "speed transmitted to stationary KAVACH" (33.1–33.5);
- speed supervision and brake curves;
- DMI speed.

It is the RDSO-33 speed: the highest usable channel of the valid comparator/PG set. The full decision (slip state, failed channels, case) is available through `SpeedSensor_GetDecision()`.

---

## 8. Connect the hooks

The defaults in `speed_sensor_user.c` only print. Replace their bodies (keep the names) with your event logger, NMS, DMI and mode-manager calls. Each is called **once per event**, not every window.

| Hook | Called when | Required action (RDSO) |
|---|---|---|
| `SpeedSensor_HookChannelFailure(ch)` | A channel disagreed longer than the speed-sense timeout | Event logger + NMS: "Channel a/b (RH/LH PG) failure" (33.4, 33.5, 33.14, 33.15) |
| `SpeedSensor_HookSystemFailure()` | No valid speed determination longer than the timeout | `is_speed_sensor_fail` is already set; event logger + NMS (33.6) |
| `SpeedSensor_HookSlipSlideUndetectable()` | A channel is suspect for ≥ 1 s | Event logger + NMS "Slip/Slide cannot be detected" (33.15) |
| `SpeedSensor_HookSlipSlideDetected(state, source, pg)` | Slip or slide starts | Show on DMI (33.10, 33.12, 33.16); for slide also event logger + NMS (33.12) |
| `SpeedSensor_HookSlipSlideTimeout(state)` | Slip/slide lasted longer than the slip/slide timeout | Prompt SR mode erasing direction; event logger + NMS (33.11, 33.13, 33.16). The mode transition then goes to stationary Kavach, which sends MA invalid until new direction and position are reported |
| `SpeedSensor_HookDirectionMismatch(d1, d2)` | Both PGs usable, opposite directions for 2 windows | Not in test 33: system team to decide (log, NMS, erase direction) |

For the DMI slip/slide indication (a state, not an event), read `SpeedSensor_GetDecision()->slip_state` every window.

**Leaving System Failure.** `system_failure_request` is latched until `SpeedDecision_Init()`, which only `SpeedSensor_Init()` calls. If your mode manager allows leaving SF without a restart (e.g. after a maintenance action), call `SpeedDecision_Init()` with the same configuration at that point.

---

## 9. Configuration

| Item | Where | Value |
|---|---|---|
| Speed-sense timeout | `SPEED_SENSOR_SPEED_SENSE_TIMEOUT_S` in `speed_sensor_user.h` | **From the FRS.** 3 s is a placeholder |
| Slip/slide timeout | `SPEED_SENSOR_SLIP_SLIDE_TIMEOUT_S` | **From the FRS.** 5 s is a placeholder |
| Wheel diameter per PG | `loco_info.loco_wheel_dia1/2` (mm) | The measured diameter of the wheel that PG sits on. A 1 % error = 1 km/h at 100 km/h between PGs |
| PPR per PG | `loco_info.tacho_output_pulse_per_rev1/2` | As fitted |
| Tick period | `SPEED_ECAP_TICK_PERIOD_US` in `speed_sensor_ecap.h` | Must equal how often step 4 calls the tick |
| Slip threshold floor | `SPEED_DEC_SLIP_MIN_KMPH` | 1.0 (0.0 = requirement 4 literally). **Confirm with RDSO** |
| Mounting | `invert_direction` in `gSpeedSensorPgConfig[]` | Calibrate on the loco (below) |

**Direction calibration on the loco** (once per loco type / PG mounting):

1. Set both `invert_direction = false`, build, and flash.
2. Move the loco slowly in the **nominal** direction for at least 2 m.
3. Read the log: `PG1 … DIR:[d]` and `PG2 … DIR:[d]`.
4. For each PG that shows `DIR:[-1]`, set its `invert_direction = true`.
5. Rebuild, repeat: both PGs must show `DIR:[1]` forward and `DIR:[-1]` in reverse, `NET` must count in both directions, and `QE:[0] QR:[0]`.

---

## 10. Verification

### 10.1 On the PC (before touching the board)

```
gcc -std=c99 -Wall speed_decision_test_rdso33.c speed_decision.c -o t33 && ./t33
```

Expected last line: `checks passed 111, failed 0`.

### 10.2 LaunchPad bench test (`ecap_speed_test.c`)

1. Set `TEST_PULSES_PER_REV` to your generator's PPR (30 for your logs).
2. Build, feed two quadrature signals per PG, and watch the prints.

| Check | Expected |
|---|---|
| STATS line | `ticks 1000` per second, `ecap_irqs 0`, `events` ≈ 2 × 4 × f |
| 5, 100, 250 km/h | A and B of both PGs equal to the generator within 0.01 km/h |
| `GL` | 0 on a clean generator. If your board still shows the falling-edge glitches: `GL` counts them and the speed stays exact |
| `OVR`, `QE` | 0 |
| Reverse (swap A/B or generator reverse) | `DIR:[-1]`, NET counting, `QE:[0] QR:[0]` on both PGs, including PG1 |
| `SPEED_ECAP_PROFILE 1` | `max tick` cycles: note it (expected a few hundred cycles; measure) |

### 10.3 Full Kavach build on the bench: RDSO test 33

Log to check: the `PG1`/`PG2` lines, `CASE`, and the hook prints.

**Generator procedure:** start the generator **before** the test step, or ramp it at < 3.6 km/h per second. A step from 0 to test speed is a > 1 m/s² "acceleration" and correctly shows SLIP for about 1 s (explanation D6).

| Test | Generator (a RH, b RH, a LH, b LH) | Expected in the log |
|---|---|---|
| 33.1 | 80 80 80 80 | speed 80, CASE 0 |
| 33.2 | 100 99 100 100 | speed 100, CASE 0 |
| 33.3 | 112 113 113 112 | speed 113, CASE 0 |
| 33.4 | 115 115 98 115 | speed 115, CASE 2; after 1 s "SLIP/SLIDE CANNOT BE DETECTED"; after the timeout "SPEED CHANNEL FAILURE: Channel a (LH PG)" once; no SF |
| 33.5 | 112 125 125 125 | speed 125; after the timeout "Channel a (RH PG)" failure; no SF |
| 33.6 | 160 150 125 125 | CASE 4; after the timeout "SPEED DETERMINATION MALFUNCTION -> SYSTEM FAILURE" |
| 33.7 / 33.8 | all 100 / all 50 | no slip/slide |
| 33.9 | all 100, then RH 102/102, LH 100/100 | speed 102, CASE 1, no slip |
| 33.10 / 33.11 | all 50, then LH 53/53 | "SLIP DETECTED source:[1] pg:[2]"; 33.11: after the slip timeout "SLIP TIMEOUT -> SR MODE PROMPT" |
| 33.12 / 33.13 | all 50, then LH 47/47 | "SLIDE DETECTED source:[1] pg:[2]"; 33.13: SR prompt after the timeout |
| 33.14 | all 100, then RH-a 105 | CASE 2, not detectable, RH-a failure after the timeout |
| 33.15 | all 50, then RH 50/52, LH 53/53 | CASE 2, "cannot be detected" once, RH-a failure after the timeout |
| 33.16 | 65, 67, 72, 77 … 97 in 1 s steps | "SLIP DETECTED source:[2]" from the 72 km/h step; SR prompt 5 s later |

For 33.10–33.13 start with all four equal, then change one PG: the code decides which wheel slips from the change (explanation D5).

### 10.4 On the loco

1. Calibration (step 9).
2. Drive forward and reverse at walking pace and at line speed: `QE:[0]`, `OVR:[0]`, `GL` near 0, PG1 and PG2 speeds within the wheel-diameter difference, `CASE:[0]` or `[1]`.
3. Stop and roll back: DIR changes within ~15 cm, NET counts backwards, the rollback logic sees it.
4. Compare the distance over a known length (e.g. between two RFID tags) with the NET pulse sum × π D / PPR.

---

## 11. Troubleshooting

| Symptom (log) | Likely cause | Action |
|---|---|---|
| `H:[1]`, channels unusable, SF after the timeout | `SpeedSensor_Tick()` not called, or the tick is too slow for the PPR with interrupts off | Step 4; check `SPEED_ECAP_TICK_PERIOD_US`; check `SPEED_ECAP_IRQ_MODE` |
| `IRQ:[1]` unexpectedly | PPR/diameter/tick combination needs interrupts (B3 table) | Faster tick, or accept (give the ECAP interrupts high priority) |
| `OVR` > 0 now and then | Tick delayed by more than ~2 pulse periods, or Service not called for > 367 ms | Find the long critical section / blocking call; raise the tick's priority |
| `GL` high on one channel | Noisy input (ringing, crosstalk) | Speed is still right. Fix the signal conditioning (RC filter, Schmitt trigger, shielding) |
| `DIR:[0]` while moving, `QR` high | A and B of that PG are not a quadrature pair (wiring, one channel noisy, generator driving different frequencies) | Scope A and B at the MCU pins |
| `DIR` opposite on PG1 and PG2, direction-mismatch hook | Mounting inversion not calibrated | Step 9 calibration |
| `NET` 0 on one PG while it turns | One channel of that PG dead (no quadrature possible) | Check that channel; the other PG supplies distance |
| Train speed differs 1–2 km/h from a reference | Wheel diameter setting, or a downstream speed computed from pulse counts | Explanation Part G, step 6.3 |
| Channel failure reported at every start | Should not happen (debounced). If it does, check that the four channels see the same generator | Log the four speeds of the first 1 s |
| After a sudden generator step from a low speed (1–3 km/h) to a high speed, one or all channels stay at 0 Hz / 0 km/h, `GL` counts every pulse | Glitch-filter lock in the first v3 | Fixed in v3.1 (explanation, v3.1 table). Make sure you have the v3.1 `speed_sensor_ecap.c` |
| All speeds 4× too low/high | PPR setting ≠ PG | `loco_info` / `TEST_PULSES_PER_REV` |
| Init fails | ECAP base addresses / XBAR / interrupt numbers in `gSpeedSensorPgConfig[]` do not match syscfg, or counter skew check failed | Compare with syscfg; check that all four ECAP instances are enabled |

---

## 12. Checklist

- [ ] PPR, tick period and window length checked (step 0)
- [ ] Files added, EQEP speed code removed (step 1)
- [ ] syscfg: 4 ECAPs, Input XBAR 0–3, INT XBAR 22–25, EQEP disabled on those pins (step 2)
- [ ] `SpeedSensor_Init()` after `loco_info` is loaded (step 3)
- [ ] `SpeedSensor_Tick()` every 1 ms; `H:[0]` in the log (step 4)
- [ ] `SpeedSensor_Service()` every main-loop pass; `CalculateWheelSpeed_ECAP()` every `SPEED_SAMPLING_TIME`; same task (step 5)
- [ ] `CalculateTrainSpeedEQEP()`: PG-difference SF rule removed, old slip/skid removed, no speed from pulse counts (step 6)
- [ ] Supervision, DMI and stationary packet use `SpeedSensor_GetTrainSpeedKmph()` (step 7)
- [ ] Six hooks connected to event logger / NMS / DMI / mode manager (step 8)
- [ ] Timeouts from the FRS; wheel diameters per PG; `invert_direction` calibrated (step 9)
- [ ] Host test 111/111; bench STATS `ecap_irqs 0`; RDSO 33.1–33.16 on the bench (step 10)
